# Nexus — Admin Cloud Functions (reference implementation)

These two callable functions implement the privileged operations the main
Nexus spec calls out as unsafe to do from the client SDK alone:

- `setAdminClaim` — grants/revokes the `admin` custom claim used by
  `firebase/firestore.rules` and the client's `AdminRoute`.
- `setUserAccountStatus` — suspends/restores a user's Firebase Auth account
  and mirrors the status onto their Firestore profile.

## Deploying

1. `cd functions-example && npm install`
2. From the project root, add a `functions` block to `firebase.json`
   pointing at this directory (or move this directory to `functions/`,
   the default Firebase CLI convention).
3. `firebase deploy --only functions`
4. Grant your own account the admin claim once, from a trusted environment
   (e.g. a one-off script using `firebase-admin`, or the Firebase console),
   since no user can be the first admin through the callable function above
   (it requires an existing admin to call it).

Both functions write an entry to `adminAuditLogs` for traceability, per the
spec's requirement to log meaningful privileged actions.
