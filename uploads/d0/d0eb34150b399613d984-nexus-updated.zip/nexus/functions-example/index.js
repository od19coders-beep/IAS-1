/**
 * Reference Cloud Functions for privileged Nexus admin operations.
 *
 * This is NOT part of the create-react-app client build. Deploy it
 * separately with the Firebase CLI (`firebase deploy --only functions`)
 * from a project that has these functions configured. It exists to show a
 * secure pattern for operations the client SDK must never perform directly:
 * granting admin rights and changing another user's account status.
 *
 * These are examples to adapt, not a drop-in production-ready service —
 * review auth checks, rate limiting, and logging for your own deployment.
 */

const { onCall, onRequest, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();

function assertIsAdmin(request) {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError(
      "permission-denied",
      "Only admins can perform this action."
    );
  }
}

/**
 * Grants or revokes the `admin` custom claim on a user's ID token.
 * This is the ONLY correct way to make someone an admin — a Firestore
 * `role` field alone is never sufficient, since a client could otherwise
 * write to it directly.
 */
exports.setAdminClaim = onCall(async (request) => {
  assertIsAdmin(request);
  const { targetUid, isAdmin } = request.data;
  if (!targetUid || typeof isAdmin !== "boolean") {
    throw new HttpsError("invalid-argument", "targetUid and isAdmin are required.");
  }

  await admin.auth().setCustomUserClaims(targetUid, { admin: isAdmin });

  await admin.firestore().collection("adminAuditLogs").add({
    actorUid: request.auth.uid,
    action: "admin_claim_changed",
    targetUid,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    metadata: { isAdmin },
  });

  return { success: true };
});

/**
 * Suspends or restores a user's account. Disables the Firebase Auth account
 * (blocking sign-in) and mirrors the status onto their Firestore profile so
 * the UI can reflect it.
 */
exports.setUserAccountStatus = onCall(async (request) => {
  assertIsAdmin(request);
  const { targetUid, status } = request.data;
  if (!targetUid || !["active", "suspended"].includes(status)) {
    throw new HttpsError(
      "invalid-argument",
      "targetUid and a valid status ('active' or 'suspended') are required."
    );
  }

  if (targetUid === request.auth.uid) {
    throw new HttpsError(
      "failed-precondition",
      "Admins cannot change their own account status through this operation."
    );
  }

  await admin.auth().updateUser(targetUid, { disabled: status === "suspended" });

  const userRef = admin.firestore().collection("users").doc(targetUid);
  const previous = await userRef.get();

  await userRef.update({
    accountStatus: status,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  await admin.firestore().collection("adminAuditLogs").add({
    actorUid: request.auth.uid,
    action: "user_status_changed",
    targetUid,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    metadata: {
      previousStatus: previous.exists ? previous.data().accountStatus : null,
      newStatus: status,
    },
  });

  return { success: true };
});

/**
 * Upload proxy for Nexus file/image/video QR codes. Keeps the GitHub token on
 * the server so it never ships in the browser bundle.
 *
 * Setup:
 *   firebase functions:secrets:set GITHUB_TOKEN   (fine-grained PAT, Contents: read/write on the storage repo only)
 *   set GITHUB_OWNER / GITHUB_REPO / GITHUB_BRANCH as function env vars
 * Then set REACT_APP_UPLOAD_PROXY_URL to this function's URL.
 * Only signed-in, email-verified users may upload; paths are confined to uploads/.
 */
const githubToken = defineSecret("GITHUB_TOKEN");

exports.uploadToGithub = onRequest(
  { secrets: [githubToken], cors: true, memory: "512MiB", timeoutSeconds: 300, maxInstances: 10 },
  async (req, res) => {
    if (req.method !== "POST") return res.status(405).end();
    try {
      const idToken = (req.headers.authorization || "").replace(/^Bearer /, "");
      const decoded = await admin.auth().verifyIdToken(idToken);
      if (!decoded.email_verified) return res.status(403).json({ error: "verify-email" });

      const { path, content, message } = req.body || {};
      if (typeof path !== "string" || !/^uploads\/[0-9a-f]{2}\/[\w.-]+$/.test(path) || typeof content !== "string") {
        return res.status(400).json({ error: "bad-request" });
      }
      const owner = process.env.GITHUB_OWNER;
      const repo = process.env.GITHUB_REPO;
      const branch = process.env.GITHUB_BRANCH || "main";
      const headers = {
        Authorization: `Bearer ${githubToken.value()}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type": "application/json",
      };
      const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
      const put = await fetch(url, {
        method: "PUT",
        headers,
        body: JSON.stringify({ message: String(message || "upload").slice(0, 100), content, branch }),
      });
      if (put.ok) {
        const data = await put.json();
        return res.json({ commitSha: data.commit.sha, existed: false });
      }
      if (put.status === 422) {
        const list = await fetch(`https://api.github.com/repos/${owner}/${repo}/commits?path=${encodeURIComponent(path)}&sha=${branch}&per_page=1`, { headers });
        const commits = list.ok ? await list.json() : [];
        return res.json({ commitSha: commits[0]?.sha || branch, existed: true });
      }
      return res.status(put.status === 403 ? 429 : 502).json({ error: "github" });
    } catch (error) {
      return res.status(401).json({ error: "unauthenticated" });
    }
  }
);
