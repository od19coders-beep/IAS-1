import { buildPublicUrl, buildRepoPath, isGithubStorageConfigured } from "../githubStorage";

describe("githubStorage helpers", () => {
  const original = { ...process.env };
  afterEach(() => {
    process.env = { ...original };
  });

  it("builds a content-addressed, sharded repo path", () => {
    process.env.REACT_APP_GITHUB_UPLOAD_PATH = "/files/";
    const path = buildRepoPath({ hash: "abcdef0123456789abcdef0123456789", fileName: "menu.pdf" });
    expect(path).toBe("files/ab/abcdef0123456789abcd-menu.pdf");
  });

  it("uses jsDelivr with a commit ref by default", () => {
    expect(
      buildPublicUrl({ owner: "acme", repo: "store", ref: "deadbeef", path: "uploads/ab/x y.png", sizeBytes: 1000 })
    ).toBe("https://cdn.jsdelivr.net/gh/acme/store@deadbeef/uploads/ab/x%20y.png");
  });

  it("falls back to raw.githubusercontent.com for raw style or files over 50 MB", () => {
    const base = { owner: "acme", repo: "store", ref: "deadbeef", path: "uploads/ab/video.mp4" };
    const expected = "https://raw.githubusercontent.com/acme/store/deadbeef/uploads/ab/video.mp4";
    expect(buildPublicUrl({ ...base, style: "raw" })).toBe(expected);
    expect(buildPublicUrl({ ...base, sizeBytes: 60 * 1024 * 1024 })).toBe(expected);
  });

  it("reports whether storage is configured", () => {
    process.env.REACT_APP_GITHUB_TOKEN = "";
    expect(isGithubStorageConfigured()).toBe(false);
    process.env.REACT_APP_GITHUB_TOKEN = "t";
    process.env.REACT_APP_GITHUB_OWNER = "o";
    process.env.REACT_APP_GITHUB_REPO = "r";
    expect(isGithubStorageConfigured()).toBe(true);
  });
});
