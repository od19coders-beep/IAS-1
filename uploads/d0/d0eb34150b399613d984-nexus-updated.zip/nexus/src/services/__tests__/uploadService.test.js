import { validateUploadFile, maxUploadBytes } from "../uploadService";

const makeFile = (name, type, size = 10) => {
  const file = new File(["x"], name, { type });
  Object.defineProperty(file, "size", { value: size });
  return file;
};

describe("validateUploadFile", () => {
  it("accepts normal files and rejects empty or oversized ones", () => {
    expect(validateUploadFile(makeFile("a.pdf", "application/pdf"))).toBeNull();
    expect(validateUploadFile(makeFile("a.pdf", "application/pdf", 0))).toMatch(/empty/);
    expect(validateUploadFile(makeFile("a.pdf", "application/pdf", maxUploadBytes() + 1))).toMatch(/limit/);
  });

  it("enforces image and video types", () => {
    expect(validateUploadFile(makeFile("a.pdf", "application/pdf"), "image")).toMatch(/image/);
    expect(validateUploadFile(makeFile("a.png", "image/png"), "image")).toBeNull();
    expect(validateUploadFile(makeFile("a.png", "image/png"), "video")).toMatch(/video/);
    expect(validateUploadFile(makeFile("a.mp4", "video/mp4"), "video")).toBeNull();
  });

  it("blocks executables", () => {
    expect(validateUploadFile(makeFile("setup.exe", "application/x-msdownload"))).toMatch(/Executable/);
  });
});
