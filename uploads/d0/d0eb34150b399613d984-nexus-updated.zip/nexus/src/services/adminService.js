import {
  collection,
  getCountFromServer,
  getDocs,
  limit,
  orderBy,
  query,
  startAfter,
  where,
} from "firebase/firestore";
import { httpsCallable, getFunctions } from "firebase/functions";
import { db } from "../lib/firebase";
import { app } from "../lib/firebase";
import { APP_CONFIG } from "../constants/appConfig";

const functions = getFunctions(app);

/**
 * Read-only aggregate counts. Safe for the client because Firestore Security
 * Rules restrict these reads to signed-in users holding the trusted
 * `admin` custom claim (see firebase/firestore.rules).
 */
export async function getPlatformStats() {
  const usersRef = collection(db, "users");

  const [totalUsersSnap, activeUsersSnap] = await Promise.all([
    getCountFromServer(usersRef),
    getCountFromServer(query(usersRef, where("accountStatus", "==", "active"))),
  ]);

  // Aggregate code counts across all users requires a collection-group query.
  // This still relies on Security Rules restricting collection-group reads on
  // `codes` to admins only.
  const { collectionGroup } = await import("firebase/firestore");
  const codesGroupRef = collectionGroup(db, "codes");
  const [totalCodesSnap, qrCodesSnap, barcodesSnap] = await Promise.all([
    getCountFromServer(codesGroupRef),
    getCountFromServer(query(codesGroupRef, where("codeType", "==", "qr"))),
    getCountFromServer(query(codesGroupRef, where("codeType", "==", "barcode"))),
  ]);

  return {
    totalUsers: totalUsersSnap.data().count,
    activeUsers: activeUsersSnap.data().count,
    totalCodes: totalCodesSnap.data().count,
    qrCodes: qrCodesSnap.data().count,
    barcodes: barcodesSnap.data().count,
  };
}

export async function fetchUsersPage({ cursor = null, pageSize = APP_CONFIG.codesPageSize } = {}) {
  const usersRef = collection(db, "users");
  const constraints = [orderBy("createdAt", "desc")];
  if (cursor) constraints.push(startAfter(cursor));
  constraints.push(limit(pageSize));

  const snapshot = await getDocs(query(usersRef, ...constraints));
  const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  const lastDoc = snapshot.docs[snapshot.docs.length - 1] || null;
  return { items, lastDoc, hasMore: snapshot.docs.length === pageSize };
}

/**
 * Privileged operations (suspend/restore, role changes) must NOT be done
 * with direct client Firestore writes — a client can never be trusted to
 * grant itself or anyone else admin rights. These call a trusted Cloud
 * Function instead. See /functions-example for a reference implementation
 * that must be deployed separately; it is not part of the CRA client build.
 */
export async function setUserAccountStatus(targetUid, status) {
  const callable = httpsCallable(functions, "setUserAccountStatus");
  const result = await callable({ targetUid, status });
  return result.data;
}

export default { getPlatformStats, fetchUsersPage, setUserAccountStatus };
