// Turns a user-selected file into a public URL, silently. The UI never shows
// upload mechanics — it only sees "working" then "ready" (or a friendly error).
import { APP_CONFIG } from "../constants/appConfig";
import { getUpload, putUpload } from "../lib/localDb";
import { blobToBase64, formatBytes, getExtension, safeFileName, sha256Hex } from "../utils/fileUtils";
import {
  UploadError,
  buildPublicUrl,
  buildRepoPath,
  getGithubConfig,
  getRepoKey,
  isGithubStorageConfigured,
  putFile,
} from "./githubStorage";

const BLOCKED_EXTENSIONS = ["exe", "msi", "bat", "cmd", "scr", "com", "pif", "vbs", "jar", "dll"];

export const maxUploadBytes = () => APP_CONFIG.maxUploadMb * 1024 * 1024;

export { isGithubStorageConfigured };

/** Returns an error message, or null if the file can be converted. */
export function validateUploadFile(file, kind = "file") {
  if (!file) return "Choose a file first.";
  if (file.size === 0) return "This file is empty.";
  if (file.size > maxUploadBytes()) {
    return `This file is ${formatBytes(file.size)}. The limit is ${APP_CONFIG.maxUploadMb} MB.`;
  }
  const ext = getExtension(file.name);
  if (kind === "image" && !(file.type || "").startsWith("image/")) {
    return "Please choose an image file (PNG, JPG, GIF, WebP, SVG…).";
  }
  if (kind === "video" && !(file.type || "").startsWith("video/")) {
    return "Please choose a video file (MP4, WebM, MOV…).";
  }
  if (BLOCKED_EXTENSIONS.includes(ext)) {
    return "Executable files can't be converted to a QR code.";
  }
  return null;
}

/**
 * Stores the file and resolves with
 * `{ url, name, size, type, hash, path }`.
 * Identical files (same SHA-256) reuse their earlier URL — checked first in
 * IndexedDB, then by GitHub itself (content-addressed path).
 */
export async function uploadForQr(file, kind = "file") {
  const problem = validateUploadFile(file, kind);
  if (problem) throw new UploadError(problem, "invalid-file");

  if (!isGithubStorageConfigured()) {
    throw new UploadError("File conversion is not set up yet. Please contact support.", "not-configured");
  }

  const hash = await sha256Hex(file);
  const repoKey = getRepoKey();

  const cached = await getUpload(hash);
  if (cached?.url && cached.repoKey === repoKey) {
    return { ...cached, name: file.name };
  }

  const { owner, repo, urlStyle } = getGithubConfig();
  const path = buildRepoPath({ hash, fileName: safeFileName(file.name) });
  const base64 = await blobToBase64(file);
  const { commitSha } = await putFile({
    path,
    base64,
    message: `upload ${hash.slice(0, 12)}`,
  });

  const record = {
    hash,
    repoKey,
    url: buildPublicUrl({ owner, repo, ref: commitSha, path, style: urlStyle, sizeBytes: file.size }),
    name: file.name,
    size: file.size,
    type: file.type || "application/octet-stream",
    path,
    createdAt: Date.now(),
  };
  await putUpload(record);
  return record;
}
