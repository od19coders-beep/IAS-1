import { getCountFromServer, query, where } from "firebase/firestore";
import { userCodesCollection } from "../lib/firestore";

/**
 * Real, per-user counts for the dashboard overview — never hardcoded.
 */
export async function getUserCodeCounts(uid) {
  const codesRef = userCodesCollection(uid);
  const [totalSnap, qrSnap, barcodeSnap] = await Promise.all([
    getCountFromServer(codesRef),
    getCountFromServer(query(codesRef, where("codeType", "==", "qr"))),
    getCountFromServer(query(codesRef, where("codeType", "==", "barcode"))),
  ]);

  return {
    total: totalSnap.data().count,
    qr: qrSnap.data().count,
    barcode: barcodeSnap.data().count,
  };
}

export default { getUserCodeCounts };
