// Low-level GitHub storage client. Uploads a file into a dedicated repository
// through the GitHub Contents API and returns an immutable, public CDN URL
// that can be encoded straight into a QR code.
//
// SECURITY NOTE: anything in a React (CRA) bundle is readable by every
// visitor, including REACT_APP_GITHUB_TOKEN. Use a *fine-grained* personal
// access token limited to ONE dedicated repository with only
// "Contents: Read and write" permission, so a leaked token can't touch
// anything else. See README ("File-to-QR storage") for the hardened setup.
import { logDevError } from "../utils/errorUtils";

const API_ROOT = "https://api.github.com";
const REQUEST_TIMEOUT_MS = 180000;
const MAX_ATTEMPTS = 3;

export class UploadError extends Error {
  constructor(message, code = "upload-failed") {
    super(message);
    this.name = "UploadError";
    this.code = code;
  }
}

export function getGithubConfig() {
  return {
    token: process.env.REACT_APP_GITHUB_TOKEN || "",
    owner: process.env.REACT_APP_GITHUB_OWNER || "",
    repo: process.env.REACT_APP_GITHUB_REPO || "",
    branch: process.env.REACT_APP_GITHUB_BRANCH || "main",
    basePath: (process.env.REACT_APP_GITHUB_UPLOAD_PATH || "uploads").replace(/^\/+|\/+$/g, ""),
    urlStyle: process.env.REACT_APP_UPLOAD_URL_STYLE === "raw" ? "raw" : "jsdelivr",
    // Recommended: a server-side proxy that holds the token (see functions-example/).
    proxyUrl: process.env.REACT_APP_UPLOAD_PROXY_URL || "",
  };
}

export function isGithubStorageConfigured() {
  const { token, owner, repo, proxyUrl } = getGithubConfig();
  return Boolean(owner && repo && (proxyUrl || token));
}

/** Identifies the target repo so cached upload records are ignored if it changes. */
export function getRepoKey() {
  const { owner, repo, branch } = getGithubConfig();
  return `${owner}/${repo}@${branch}`;
}

/**
 * Content-addressed path: identical files always map to the same path, so
 * re-uploading the same file is a no-op. Sharded by the first hash byte to
 * keep directories small.
 */
export function buildRepoPath({ hash, fileName }) {
  const { basePath } = getGithubConfig();
  return `${basePath}/${hash.slice(0, 2)}/${hash.slice(0, 20)}-${fileName}`;
}

const encodePath = (path) => path.split("/").map(encodeURIComponent).join("/");

/**
 * Public URL for an uploaded file. `ref` should be a commit SHA (immutable,
 * never stale in the CDN). jsDelivr serves correct MIME types with CORS but
 * caps files at 50 MB, so larger files fall back to raw.githubusercontent.com.
 */
export function buildPublicUrl({ owner, repo, ref, path, style = "jsdelivr", sizeBytes = 0 }) {
  const useRaw = style === "raw" || sizeBytes > 50 * 1024 * 1024;
  return useRaw
    ? `https://raw.githubusercontent.com/${owner}/${repo}/${ref}/${encodePath(path)}`
    : `https://cdn.jsdelivr.net/gh/${owner}/${repo}@${ref}/${encodePath(path)}`;
}

function headers(token, json = true) {
  return {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    ...(json ? { "Content-Type": "application/json" } : {}),
  };
}

async function request(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error.name === "AbortError") {
      throw new UploadError("The upload took too long. Please try again.", "timeout");
    }
    throw new UploadError("Network error. Check your connection and try again.", "network");
  } finally {
    clearTimeout(timer);
  }
}

function mapFailure(response) {
  if (response.status === 413) {
    return new UploadError("This file is too large to convert.", "too-large");
  }
  if (response.status === 403 && response.headers.get("x-ratelimit-remaining") === "0") {
    return new UploadError("Too many uploads right now. Please try again in a few minutes.", "rate-limited");
  }
  if (response.status === 401 || response.status === 403 || response.status === 404) {
    // Misconfiguration (bad/expired token, wrong repo). Details go to the dev console only.
    return new UploadError("File conversion is temporarily unavailable. Please try again later.", "unavailable");
  }
  return new UploadError("Could not process this file. Please try again.", "upload-failed");
}

/** Latest commit that touched `path` on the configured branch (for already-uploaded files). */
export async function getLatestCommitSha(path) {
  const { token, owner, repo, branch } = getGithubConfig();
  const url = `${API_ROOT}/repos/${owner}/${repo}/commits?path=${encodeURIComponent(path)}&sha=${encodeURIComponent(branch)}&per_page=1`;
  const response = await request(url, { headers: headers(token, false) });
  if (!response.ok) throw mapFailure(response);
  const commits = await response.json();
  return commits?.[0]?.sha || branch;
}

/**
 * Creates the file in the repo. Resolves with `{ commitSha, existed }`.
 * If the content-addressed path already exists (HTTP 422), the existing
 * file's commit is returned instead of failing.
 */
export async function putFile({ path, base64, message }) {
  const { token, owner, repo, branch, proxyUrl } = getGithubConfig();
  if (!isGithubStorageConfigured()) {
    throw new UploadError("File conversion is not set up yet.", "not-configured");
  }
  if (proxyUrl) return putFileViaProxy({ proxyUrl, path, base64, message });

  const url = `${API_ROOT}/repos/${owner}/${repo}/contents/${encodePath(path)}`;
  let lastError = null;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
    try {
      const response = await request(url, {
        method: "PUT",
        headers: headers(token),
        body: JSON.stringify({ message, content: base64, branch }),
      });

      if (response.status === 200 || response.status === 201) {
        const data = await response.json();
        return { commitSha: data?.commit?.sha || branch, existed: false };
      }

      if (response.status === 422) {
        // "sha wasn't supplied" => this exact file is already stored.
        return { commitSha: await getLatestCommitSha(path), existed: true };
      }

      logDevError("githubStorage.putFile", `HTTP ${response.status} ${await response.text().catch(() => "")}`);

      // 409 = concurrent commit on the branch, 5xx = transient: retry with backoff.
      if ((response.status === 409 || response.status >= 500) && attempt < MAX_ATTEMPTS) {
        await new Promise((resolve) => setTimeout(resolve, 600 * attempt));
        continue;
      }
      throw mapFailure(response);
    } catch (error) {
      lastError = error;
      if (!(error instanceof UploadError) || error.code === "network") {
        if (attempt < MAX_ATTEMPTS) {
          await new Promise((resolve) => setTimeout(resolve, 600 * attempt));
          continue;
        }
      }
      throw error;
    }
  }
  throw lastError || new UploadError("Could not process this file. Please try again.");
}

/** Token-free path: the server (which holds the GitHub token) does the commit. */
async function putFileViaProxy({ proxyUrl, path, base64, message }) {
  const { auth } = await import("../lib/firebase");
  const user = auth.currentUser;
  if (!user) throw new UploadError("Please sign in again to continue.", "unauthenticated");
  const idToken = await user.getIdToken();
  const response = await request(proxyUrl, {
    method: "POST",
    headers: { Authorization: `Bearer ${idToken}`, "Content-Type": "application/json" },
    body: JSON.stringify({ path, content: base64, message }),
  });
  if (!response.ok) {
    logDevError("githubStorage.putFileViaProxy", `HTTP ${response.status}`);
    throw mapFailure(response);
  }
  const data = await response.json();
  return { commitSha: data.commitSha, existed: Boolean(data.existed) };
}
