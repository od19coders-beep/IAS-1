import {
  addDoc,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  startAfter,
  updateDoc,
  where,
} from "firebase/firestore";
import { userCodeDoc, userCodesCollection } from "../lib/firestore";
import { APP_CONFIG } from "../constants/appConfig";
import { cacheCode, cacheCodes, getCachedCode, removeCachedCode } from "../lib/localDb";

/**
 * Saves a generated code (QR or barcode) to the signed-in user's library.
 * Only generation parameters and the payload are stored — never a rendered
 * image blob.
 */
export async function saveCode(uid, codeData) {
  const payload = {
    ownerUid: uid,
    name: codeData.name,
    codeType: codeData.codeType, // "qr" | "barcode"
    format: codeData.format,
    payloadType: codeData.payloadType || null,
    payload: codeData.payload,
    settings: codeData.settings || null,
    media: codeData.media || null,
    barcodeSettings: codeData.barcodeSettings || null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    lastDownloadedAt: null,
    downloadCount: 0,
    isFavorite: false,
  };

  const ref = await addDoc(userCodesCollection(uid), payload);
  // Best-effort local cache (serverTimestamp placeholders can't be stored).
  cacheCode(uid, { ...payload, id: ref.id, createdAt: Date.now(), updatedAt: Date.now() });
  return ref.id;
}

/** Instant, possibly stale copy from IndexedDB (or null). Pair with getCode() to refresh. */
export function getCodeFromCache(uid, codeId) {
  return getCachedCode(uid, codeId);
}

export async function getCode(uid, codeId) {
  const snapshot = await getDoc(userCodeDoc(uid, codeId));
  if (!snapshot.exists()) {
    removeCachedCode(uid, codeId);
    return null;
  }
  const code = { id: snapshot.id, ...snapshot.data() };
  cacheCode(uid, code);
  return code;
}

export async function deleteCode(uid, codeId) {
  await deleteDoc(userCodeDoc(uid, codeId));
  removeCachedCode(uid, codeId);
}

export async function toggleFavorite(uid, codeId, isFavorite) {
  await updateDoc(userCodeDoc(uid, codeId), {
    isFavorite,
    updatedAt: serverTimestamp(),
  });
  const cached = await getCachedCode(uid, codeId);
  if (cached) cacheCode(uid, { ...cached, isFavorite });
}

export async function renameCode(uid, codeId, name) {
  await updateDoc(userCodeDoc(uid, codeId), {
    name,
    updatedAt: serverTimestamp(),
  });
  const cached = await getCachedCode(uid, codeId);
  if (cached) cacheCode(uid, { ...cached, name });
}

/**
 * Non-essential analytics update. Failures here must never block a download.
 */
export async function recordDownload(uid, codeId) {
  try {
    const snapshot = await getDoc(userCodeDoc(uid, codeId));
    const current = snapshot.exists() ? snapshot.data().downloadCount || 0 : 0;
    await updateDoc(userCodeDoc(uid, codeId), {
      lastDownloadedAt: serverTimestamp(),
      downloadCount: current + 1,
    });
  } catch (error) {
    // Intentionally swallowed — download success must not depend on this.
  }
}

/**
 * Fetches one page of the user's codes, newest first by default, with
 * optional type filtering and cursor-based pagination. Never fetches the
 * full collection at once.
 */
export async function fetchCodesPage(
  uid,
  { codeType = null, sortDirection = "desc", cursor = null, pageSize = APP_CONFIG.codesPageSize } = {}
) {
  const constraints = [];
  if (codeType) constraints.push(where("codeType", "==", codeType));
  constraints.push(orderBy("createdAt", sortDirection));
  if (cursor) constraints.push(startAfter(cursor));
  constraints.push(limit(pageSize));

  const q = query(userCodesCollection(uid), ...constraints);
  const snapshot = await getDocs(q);
  const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  cacheCodes(uid, items);
  const lastDoc = snapshot.docs[snapshot.docs.length - 1] || null;
  return { items, lastDoc, hasMore: snapshot.docs.length === pageSize };
}

/**
 * Live subscription to the user's codes overview (used on the dashboard for
 * counts and recent items). Caller is responsible for unsubscribing.
 */
export function subscribeToRecentCodes(uid, callback, pageSize = 5) {
  const q = query(
    userCodesCollection(uid),
    orderBy("createdAt", "desc"),
    limit(pageSize)
  );
  return onSnapshot(q, (snapshot) => {
    const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    cacheCodes(uid, items);
    callback(items);
  });
}
