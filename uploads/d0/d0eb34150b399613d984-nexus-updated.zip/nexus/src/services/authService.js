import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  sendEmailVerification,
  updateProfile,
  reload,
} from "firebase/auth";
import { auth } from "../lib/firebase";
import { createUserProfile } from "./userService";

const googleProvider = new GoogleAuthProvider();

export async function signUpWithEmail({ name, email, password }) {
  const credential = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(credential.user, { displayName: name });

  try {
    await createUserProfile(credential.user, { displayName: name });
  } catch (profileError) {
    // The Auth account exists even if profile creation failed. The caller's
    // AuthContext will retry profile initialization on next load.
    // eslint-disable-next-line no-console
    console.error("[Nexus] Failed to create user profile:", profileError);
  }

  await sendEmailVerification(credential.user);
  return credential.user;
}

export async function signInWithEmail({ email, password }) {
  const credential = await signInWithEmailAndPassword(auth, email, password);
  return credential.user;
}

export async function signInWithGoogle() {
  const credential = await signInWithPopup(auth, googleProvider);
  try {
    await createUserProfile(credential.user, {
      displayName: credential.user.displayName || "Nexus User",
    });
  } catch (profileError) {
    // Profile may already exist for a returning Google user; ignore.
  }
  return credential.user;
}

export async function signOutUser() {
  await firebaseSignOut(auth);
}

export async function sendPasswordReset(email) {
  await sendPasswordResetEmail(auth, email);
}

export async function resendVerificationEmail() {
  if (!auth.currentUser) throw new Error("No signed-in user.");
  await sendEmailVerification(auth.currentUser);
}

export async function refreshEmailVerificationStatus() {
  if (!auth.currentUser) throw new Error("No signed-in user.");
  await reload(auth.currentUser);
  return auth.currentUser.emailVerified;
}
