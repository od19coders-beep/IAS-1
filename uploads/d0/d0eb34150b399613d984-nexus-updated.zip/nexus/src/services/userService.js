import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";
import { updateProfile as updateAuthProfile } from "firebase/auth";
import { db, auth } from "../lib/firebase";
import { userDoc } from "../lib/firestore";

/**
 * Creates the Firestore profile document for a newly registered user with
 * safe, non-privileged defaults. Idempotent: if a profile already exists,
 * this is a no-op.
 */
export async function createUserProfile(authUser, { displayName } = {}) {
  const ref = userDoc(authUser.uid);
  const existing = await getDoc(ref);
  if (existing.exists()) return existing.data();

  const profile = {
    uid: authUser.uid,
    displayName: displayName || authUser.displayName || "Nexus User",
    email: authUser.email,
    photoURL: authUser.photoURL || null,
    role: "user",
    accountStatus: "active",
    emailVerified: authUser.emailVerified,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    lastLoginAt: serverTimestamp(),
    preferences: { theme: "light" },
  };

  await setDoc(ref, profile);
  return profile;
}

export async function getUserProfile(uid) {
  const snapshot = await getDoc(userDoc(uid));
  return snapshot.exists() ? snapshot.data() : null;
}

export async function touchLastLogin(uid) {
  await updateDoc(userDoc(uid), {
    lastLoginAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
}

/**
 * Updates only the fields a normal user is allowed to change on their own
 * profile (enforced again server-side by Firestore Security Rules).
 */
export async function updateOwnProfile(uid, { displayName, preferences }) {
  const updates = { updatedAt: serverTimestamp() };
  if (displayName !== undefined) updates.displayName = displayName;
  if (preferences !== undefined) updates.preferences = preferences;

  if (displayName !== undefined && auth.currentUser) {
    await updateAuthProfile(auth.currentUser, { displayName });
  }

  await updateDoc(userDoc(uid), updates);
}

export default { createUserProfile, getUserProfile, touchLastLogin, updateOwnProfile };
