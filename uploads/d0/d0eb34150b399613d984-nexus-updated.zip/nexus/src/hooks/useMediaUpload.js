import { useCallback, useEffect, useRef, useState } from "react";
import { uploadForQr, validateUploadFile } from "../services/uploadService";
import { logDevError } from "../utils/errorUtils";

const IDLE = { status: "idle", file: null, record: null, error: null, previewUrl: null };

/**
 * Drives the "file -> public URL" step. `status` is one of
 * idle | working | ready | error. Uploading starts automatically on
 * selection and is intentionally invisible: callers render a skeleton while
 * `working` and the finished QR code once `ready`.
 */
export function useMediaUpload(kind) {
  const [state, setState] = useState(IDLE);
  const requestId = useRef(0);
  const objectUrl = useRef(null);

  const revokePreview = () => {
    if (objectUrl.current) {
      URL.revokeObjectURL(objectUrl.current);
      objectUrl.current = null;
    }
  };

  useEffect(() => revokePreview, []);

  const run = useCallback(
    async (file) => {
      const id = ++requestId.current;
      revokePreview();

      const problem = validateUploadFile(file, kind);
      if (problem) {
        setState({ ...IDLE, status: "error", error: problem });
        return;
      }

      const previewable = file.type.startsWith("image/") || file.type.startsWith("video/");
      const previewUrl = previewable ? URL.createObjectURL(file) : null;
      objectUrl.current = previewUrl;
      setState({ status: "working", file, record: null, error: null, previewUrl });

      try {
        const record = await uploadForQr(file, kind);
        if (id !== requestId.current) return;
        setState({ status: "ready", file, record, error: null, previewUrl });
      } catch (error) {
        logDevError("useMediaUpload", error);
        if (id !== requestId.current) return;
        setState({ status: "error", file, record: null, error: error.message, previewUrl });
      }
    },
    [kind]
  );

  const select = useCallback((file) => run(file), [run]);

  const retry = useCallback(() => {
    if (state.file) run(state.file);
  }, [run, state.file]);

  const clear = useCallback(() => {
    requestId.current += 1;
    revokePreview();
    setState(IDLE);
  }, []);

  /** Restores an already-uploaded file (e.g. from a saved draft) without re-uploading. */
  const restore = useCallback((record) => {
    if (!record?.url) return;
    requestId.current += 1;
    revokePreview();
    setState({
      status: "ready",
      file: null,
      record,
      error: null,
      previewUrl: record.type?.startsWith("image/") || record.type?.startsWith("video/") ? record.url : null,
    });
  }, []);

  return {
    ...state,
    url: state.record?.url || "",
    working: state.status === "working",
    select,
    retry,
    clear,
    restore,
  };
}

export default useMediaUpload;
