import { useCallback, useEffect, useRef, useState } from "react";
import { deleteDraft, getDraft, setDraft } from "../lib/localDb";

/**
 * Persists an in-progress generator form to IndexedDB so a refresh or an
 * accidental navigation doesn't lose the work. `ready` flips to true once the
 * stored draft (if any) has been read; `save` is debounced.
 */
export function useDraft(key, delay = 500) {
  const [ready, setReady] = useState(false);
  const [draft, setDraftState] = useState(null);
  const timer = useRef(null);

  useEffect(() => {
    let cancelled = false;
    setReady(false);
    getDraft(key).then((stored) => {
      if (cancelled) return;
      setDraftState(stored);
      setReady(true);
    });
    return () => {
      cancelled = true;
      clearTimeout(timer.current);
    };
  }, [key]);

  const save = useCallback(
    (value) => {
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setDraft(key, { ...value, savedAt: Date.now() }), delay);
    },
    [key, delay]
  );

  const clear = useCallback(() => {
    clearTimeout(timer.current);
    return deleteDraft(key);
  }, [key]);

  return { ready, draft, save, clear };
}

export default useDraft;
