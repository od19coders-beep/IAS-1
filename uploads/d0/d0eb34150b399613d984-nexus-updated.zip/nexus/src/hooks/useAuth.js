import { useAuthContext } from "../context/AuthContext";

// Thin, conventional wrapper so components import from `hooks/` per the
// project's folder conventions.
export function useAuth() {
  return useAuthContext();
}

export default useAuth;
