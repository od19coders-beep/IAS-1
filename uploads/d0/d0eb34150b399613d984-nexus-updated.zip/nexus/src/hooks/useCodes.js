import { useCallback, useEffect, useState } from "react";
import { fetchCodesPage, deleteCode, toggleFavorite } from "../services/codeService";
import { getCachedCodes } from "../lib/localDb";
import { logDevError } from "../utils/errorUtils";

/**
 * Encapsulates paginated loading of a user's saved codes so page components
 * stay focused on layout, not Firestore query details.
 */
export function useCodes(uid, { codeType = null, sortDirection = "desc" } = {}) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [cursor, setCursor] = useState(null);
  const [hasMore, setHasMore] = useState(false);
  const [offline, setOffline] = useState(false);

  const load = useCallback(
    async (reset = true) => {
      if (!uid) return;
      setError(null);
      setOffline(false);

      // First load: paint instantly from the IndexedDB cache, then refresh from Firestore.
      let hadCache = false;
      if (reset) {
        const cached = await getCachedCodes(uid, { codeType, sortDirection });
        if (cached.length > 0) {
          hadCache = true;
          setItems(cached);
        }
      }
      setLoading(!hadCache);

      try {
        const { items: page, lastDoc, hasMore: more } = await fetchCodesPage(uid, {
          codeType,
          sortDirection,
          cursor: reset ? null : cursor,
        });
        setItems((prev) => (reset ? page : [...prev, ...page]));
        setCursor(lastDoc);
        setHasMore(more);
      } catch (err) {
        logDevError("useCodes.load", err);
        if (hadCache) {
          // Keep showing the cached library; flag that it may be out of date.
          setOffline(true);
        } else {
          setError(err);
        }
      } finally {
        setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [uid, codeType, sortDirection]
  );

  useEffect(() => {
    load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uid, codeType, sortDirection]);

  const remove = useCallback(
    async (codeId) => {
      await deleteCode(uid, codeId);
      setItems((prev) => prev.filter((item) => item.id !== codeId));
    },
    [uid]
  );

  const favorite = useCallback(
    async (codeId, isFavorite) => {
      await toggleFavorite(uid, codeId, isFavorite);
      setItems((prev) =>
        prev.map((item) => (item.id === codeId ? { ...item, isFavorite } : item))
      );
    },
    [uid]
  );

  return {
    items,
    loading,
    error,
    hasMore,
    offline,
    loadMore: () => load(false),
    reload: () => load(true),
    remove,
    favorite,
  };
}

export default useCodes;
