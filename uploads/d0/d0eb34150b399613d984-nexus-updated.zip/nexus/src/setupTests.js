import "@testing-library/jest-dom";

// jsdom gaps that only matter in tests (real browsers have both):
// - `qrcode` needs TextEncoder
// - JsBarcode measures text through a canvas 2D context
import { TextEncoder, TextDecoder } from "util";

if (typeof global.TextEncoder === "undefined") {
  global.TextEncoder = TextEncoder;
  global.TextDecoder = TextDecoder;
}

HTMLCanvasElement.prototype.getContext = function getContext() {
  return {
    font: "",
    measureText: (text) => ({ width: String(text).length * 8 }),
    fillRect: () => {},
    fillText: () => {},
    drawImage: () => {},
    clearRect: () => {},
    translate: () => {},
    save: () => {},
    restore: () => {},
  };
};
