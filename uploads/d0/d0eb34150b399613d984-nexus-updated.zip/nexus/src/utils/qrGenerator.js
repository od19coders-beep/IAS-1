// QR code generation, isolated from page/component code.
// Uses the maintained `qrcode` npm package for real, scannable output and
// composites an optional center logo on top (forcing error-correction "H" so
// the covered modules can be recovered by scanners).
import QRCode from "qrcode";
import { loadImage } from "./fileUtils";

const DEFAULTS = {
  foregroundColor: "#111827",
  backgroundColor: "#FFFFFF",
  errorCorrectionLevel: "M",
  width: 512,
  margin: 4,
  logoSize: 0.22,
};

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

function resolve(settings = {}) {
  const merged = { ...DEFAULTS, ...settings };
  return {
    ...merged,
    // A logo hides modules, so the highest error correction is mandatory.
    errorCorrectionLevel: merged.logo ? "H" : merged.errorCorrectionLevel,
    logoSize: clamp(Number(merged.logoSize) || DEFAULTS.logoSize, 0.1, 0.3),
    logoBackdrop: merged.logoBackdrop !== false,
  };
}

function friendlyError(error, fallback) {
  if (/too big|amount of data|capacity/i.test(error?.message || "")) {
    return "This content is too long to fit in a QR code at the current settings. Shorten it or lower the error correction level.";
  }
  return fallback;
}

/**
 * Generate a QR code as a data URL (PNG) for live preview and canvas-based downloads.
 * @param {string} payload - validated payload string
 * @param {object} settings - { foregroundColor, backgroundColor, errorCorrectionLevel, width, margin, logo, logoSize, logoBackdrop }
 */
export async function generateQrDataUrl(payload, settings = {}) {
  if (!payload) {
    throw new Error("A payload is required to generate a QR code.");
  }
  const s = resolve(settings);

  try {
    if (!s.logo) {
      return await QRCode.toDataURL(payload, {
        errorCorrectionLevel: s.errorCorrectionLevel,
        width: s.width,
        margin: s.margin,
        color: { dark: s.foregroundColor, light: s.backgroundColor },
      });
    }

    const canvas = document.createElement("canvas");
    await QRCode.toCanvas(canvas, payload, {
      errorCorrectionLevel: "H",
      width: s.width,
      margin: s.margin,
      color: { dark: s.foregroundColor, light: s.backgroundColor },
    });
    await drawCenterLogo(canvas, s);
    return canvas.toDataURL("image/png");
  } catch (error) {
    throw new Error(friendlyError(error, "Could not generate this QR code. Check the payload and try again."));
  }
}

/**
 * Generate a valid QR code as an SVG string (logo embedded as an <image>).
 */
export async function generateQrSvgString(payload, settings = {}) {
  if (!payload) {
    throw new Error("A payload is required to generate a QR code.");
  }
  const s = resolve(settings);

  try {
    const svg = await QRCode.toString(payload, {
      type: "svg",
      errorCorrectionLevel: s.errorCorrectionLevel,
      margin: s.margin,
      color: { dark: s.foregroundColor, light: s.backgroundColor },
    });
    return s.logo ? await injectSvgLogo(svg, s) : svg;
  } catch (error) {
    throw new Error(friendlyError(error, "Could not generate this QR code as SVG."));
  }
}

async function drawCenterLogo(canvas, s) {
  const image = await loadImage(s.logo);
  const ctx = canvas.getContext("2d");
  const size = canvas.width;
  const box = size * s.logoSize;
  const pad = s.logoBackdrop ? box * 0.14 : 0;
  const plate = box + pad * 2;
  const plateX = (size - plate) / 2;

  if (s.logoBackdrop) {
    ctx.fillStyle = s.backgroundColor;
    roundedRectPath(ctx, plateX, plateX, plate, plate, plate * 0.22);
    ctx.fill();
  }

  // Fit the logo inside `box` keeping its aspect ratio.
  const ratio = Math.min(box / image.width, box / image.height);
  const w = image.width * ratio;
  const h = image.height * ratio;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(image, (size - w) / 2, (size - h) / 2, w, h);
}

function roundedRectPath(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

async function injectSvgLogo(svg, s) {
  const match = /viewBox="0 0 (\d+(?:\.\d+)?) (\d+(?:\.\d+)?)"/.exec(svg);
  if (!match) return svg;
  const size = Number(match[1]);
  const image = await loadImage(s.logo);
  const box = size * s.logoSize;
  const pad = s.logoBackdrop ? box * 0.14 : 0;
  const plate = box + pad * 2;
  const plateX = (size - plate) / 2;
  const ratio = Math.min(box / image.width, box / image.height);
  const w = image.width * ratio;
  const h = image.height * ratio;

  const backdrop = s.logoBackdrop
    ? `<rect x="${plateX}" y="${plateX}" width="${plate}" height="${plate}" rx="${plate * 0.22}" fill="${s.backgroundColor}"/>`
    : "";
  const logo = `<image x="${(size - w) / 2}" y="${(size - h) / 2}" width="${w}" height="${h}" xlink:href="${s.logo}" href="${s.logo}" preserveAspectRatio="xMidYMid meet"/>`;

  return svg
    .replace("<svg ", '<svg xmlns:xlink="http://www.w3.org/1999/xlink" ')
    .replace("</svg>", `${backdrop}${logo}</svg>`);
}

/**
 * Returns true when two hex colors are close enough to risk poor contrast /
 * scan reliability. Simple perceptual distance check, not a strict WCAG test.
 */
export function isLowContrast(hexA, hexB) {
  const a = hexToRgb(hexA);
  const b = hexToRgb(hexB);
  if (!a || !b) return false;
  const distance = Math.sqrt(
    (a.r - b.r) ** 2 + (a.g - b.g) ** 2 + (a.b - b.b) ** 2
  );
  return distance < 80; // empirically low-contrast threshold for QR modules
}

function hexToRgb(hex) {
  const match = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || "");
  if (!match) return null;
  return {
    r: parseInt(match[1], 16),
    g: parseInt(match[2], 16),
    b: parseInt(match[3], 16),
  };
}
