// Normalizes Firebase and generic errors into user-friendly messages.
// Never expose stack traces or backend internals to end users.

const AUTH_ERROR_MESSAGES = {
  "auth/email-already-in-use": "An account with this email already exists.",
  "auth/invalid-email": "Please enter a valid email address.",
  "auth/user-disabled": "This account has been disabled. Contact support.",
  "auth/user-not-found": "Incorrect email or password.",
  "auth/wrong-password": "Incorrect email or password.",
  "auth/invalid-credential": "Incorrect email or password.",
  "auth/too-many-requests": "Too many attempts. Please wait a moment and try again.",
  "auth/weak-password": "Please choose a stronger password.",
  "auth/popup-closed-by-user": "Sign-in was cancelled.",
  "auth/network-request-failed": "Network error. Check your connection and try again.",
  "auth/requires-recent-login": "Please sign in again to continue.",
};

export function getFriendlyAuthErrorMessage(error) {
  const code = error?.code || "";
  if (AUTH_ERROR_MESSAGES[code]) return AUTH_ERROR_MESSAGES[code];
  return "Something went wrong. Please try again.";
}

export function getFriendlyFirestoreErrorMessage(error) {
  const code = error?.code || "";
  if (code === "permission-denied") {
    return "You don't have permission to do that.";
  }
  if (code === "not-found") {
    return "That item could not be found. It may have been deleted.";
  }
  if (code === "unavailable") {
    return "Network issue reaching the server. Please try again.";
  }
  return "Something went wrong. Please try again.";
}

export function logDevError(context, error) {
  if (process.env.NODE_ENV !== "production") {
    // eslint-disable-next-line no-console
    console.error(`[Nexus] ${context}:`, error);
  }
}
