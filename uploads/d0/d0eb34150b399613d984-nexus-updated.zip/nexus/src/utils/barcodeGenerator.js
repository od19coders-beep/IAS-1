// Barcode generation, isolated from page/component code.
// 1D formats use the maintained JsBarcode library; 2D formats (Data Matrix,
// PDF417, Aztec) use bwip-js, which is lazy-loaded so it never weighs down
// the main bundle. All generators are async and throw on invalid input —
// they never produce a fake/successful-looking result for bad values.
import JsBarcode from "jsbarcode";
import { validateBarcodeValue } from "./validators";
import { TWO_D_SYMBOLOGIES } from "../constants/codeTypes";

const BWIP_IDS = {
  DATAMATRIX: "datamatrix",
  PDF417: "pdf417",
  AZTEC: "azteccode",
};

export const isTwoDimensional = (symbology) => TWO_D_SYMBOLOGIES.includes(symbology);

async function loadBwip() {
  const mod = await import("bwip-js");
  return mod.default || mod;
}

const stripHash = (hex) => String(hex || "").replace("#", "");

function bwipOptions(value, symbology, settings) {
  const { lineColor = "#111827", background = "#FFFFFF", width = 2, margin = 10 } = settings;
  return {
    bcid: BWIP_IDS[symbology],
    text: value.trim(),
    scale: Math.max(2, Number(width) * 2),
    barcolor: stripHash(lineColor),
    backgroundcolor: stripHash(background),
    paddingwidth: Math.round(Number(margin) / 2),
    paddingheight: Math.round(Number(margin) / 2),
  };
}

function ensureValid(value, symbology) {
  const error = validateBarcodeValue(symbology, value);
  if (error) throw new Error(error);
}

const INVALID_MESSAGE = "This value is not valid for the selected barcode format.";

/**
 * Renders a barcode and returns a PNG data URL.
 */
export async function generateBarcodePngDataUrl(value, symbology, settings = {}) {
  ensureValid(value, symbology);
  const canvas = document.createElement("canvas");

  if (isTwoDimensional(symbology)) {
    try {
      const bwip = await loadBwip();
      bwip.toCanvas(canvas, bwipOptions(value, symbology, settings));
    } catch (err) {
      throw new Error(INVALID_MESSAGE);
    }
    return canvas.toDataURL("image/png");
  }

  applyJsBarcode(canvas, value, symbology, settings);
  return canvas.toDataURL("image/png");
}

/**
 * Renders a barcode as serialized SVG markup.
 */
export async function generateBarcodeSvgString(value, symbology, settings = {}) {
  ensureValid(value, symbology);

  if (isTwoDimensional(symbology)) {
    try {
      const bwip = await loadBwip();
      return bwip.toSVG(bwipOptions(value, symbology, settings));
    } catch (err) {
      throw new Error(INVALID_MESSAGE);
    }
  }

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  applyJsBarcode(svg, value, symbology, settings);
  return new XMLSerializer().serializeToString(svg);
}

function applyJsBarcode(target, value, symbology, settings) {
  const {
    displayValue = true,
    lineColor = "#111827",
    background = "#FFFFFF",
    width = 2,
    height = 100,
    fontSize = 16,
    margin = 10,
  } = settings;

  let text = value.trim();
  if (symbology === "CODE39" || symbology === "CODABAR") text = text.toUpperCase();

  try {
    JsBarcode(target, text, {
      format: symbology,
      displayValue,
      lineColor,
      background,
      width,
      height,
      fontSize,
      margin,
    });
  } catch (err) {
    throw new Error(INVALID_MESSAGE);
  }
}
