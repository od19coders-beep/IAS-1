import { APP_CONFIG } from "../constants/appConfig";

export function isValidEmail(email) {
  if (!email) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function validatePassword(password) {
  if (!password || password.length < APP_CONFIG.minPasswordLength) {
    return `Password must be at least ${APP_CONFIG.minPasswordLength} characters.`;
  }
  return null;
}

export function validateSignUpForm({ name, email, password, confirmPassword }) {
  const errors = {};
  if (!name || !name.trim()) errors.name = "Full name is required.";
  if (!isValidEmail(email)) errors.email = "Enter a valid email address.";
  const passwordError = validatePassword(password);
  if (passwordError) errors.password = passwordError;
  if (password !== confirmPassword) {
    errors.confirmPassword = "Passwords do not match.";
  }
  return errors;
}

export function validateSignInForm({ email, password }) {
  const errors = {};
  if (!isValidEmail(email)) errors.email = "Enter a valid email address.";
  if (!password) errors.password = "Password is required.";
  return errors;
}

export function sanitizeFilename(name) {
  const base = (name || "nexus-code").trim().toLowerCase();
  const cleaned = base.replace(/[^a-z0-9-_]+/g, "-").replace(/-+/g, "-");
  return cleaned.replace(/^-|-$/g, "") || "nexus-code";
}

// --- QR payload validation ---

export function validateQrPayload(payloadType, values) {
  const errors = {};
  switch (payloadType) {
    case "url": {
      if (!values.url || !values.url.trim()) {
        errors.url = "URL is required.";
      } else if (!/^https?:\/\/.+/i.test(values.url.trim())) {
        errors.url = "URL must start with http:// or https://";
      }
      break;
    }
    case "text": {
      if (!values.text || !values.text.trim()) {
        errors.text = "Text is required.";
      } else if (values.text.length > APP_CONFIG.maxPayloadLength) {
        errors.text = "Text is too long.";
      }
      break;
    }
    case "email": {
      if (!isValidEmail(values.email)) errors.email = "Enter a valid email address.";
      break;
    }
    case "phone": {
      if (!values.phone || !/^\+?[0-9()\-.\s]{6,20}$/.test(values.phone.trim())) {
        errors.phone = "Enter a valid phone number.";
      }
      break;
    }
    case "sms": {
      if (!values.phone || !/^\+?[0-9()\-.\s]{6,20}$/.test(values.phone.trim())) {
        errors.phone = "Enter a valid phone number.";
      }
      break;
    }
    case "wifi": {
      if (!values.ssid || !values.ssid.trim()) errors.ssid = "Network name is required.";
      if (values.security !== "nopass" && !values.password) {
        errors.password = "Password is required for a secured network.";
      }
      break;
    }
    case "vcard": {
      if (!values.fullName || !values.fullName.trim()) {
        errors.fullName = "Full name is required.";
      }
      break;
    }
    case "whatsapp": {
      const digits = (values.phone || "").replace(/\D/g, "");
      if (digits.length < 7 || digits.length > 15) {
        errors.phone = "Enter the number with country code, e.g. +91 98765 43210.";
      }
      break;
    }
    case "geo": {
      const lat = parseCoordinate(values.latitude);
      const lng = parseCoordinate(values.longitude);
      if (lat === null || lat < -90 || lat > 90) {
        errors.latitude = "Latitude must be between -90 and 90.";
      }
      if (lng === null || lng < -180 || lng > 180) {
        errors.longitude = "Longitude must be between -180 and 180.";
      }
      break;
    }
    case "event": {
      if (!values.title || !values.title.trim()) errors.title = "Event title is required.";
      if (!values.start) {
        errors.start = "Start date and time is required.";
      } else if (values.end && values.end < values.start) {
        errors.end = "End must be after the start.";
      }
      break;
    }
    case "upi": {
      if (!values.vpa || !/^[\w.-]{2,256}@[a-zA-Z]{2,64}$/.test(values.vpa.trim())) {
        errors.vpa = "Enter a valid UPI ID, e.g. name@bank.";
      }
      if (!values.payee || !values.payee.trim()) errors.payee = "Payee name is required.";
      if (values.amount !== undefined && values.amount !== "") {
        const amount = Number(values.amount);
        if (!Number.isFinite(amount) || amount <= 0 || !/^\d+(\.\d{1,2})?$/.test(String(values.amount))) {
          errors.amount = "Enter a valid amount (up to 2 decimals).";
        }
      }
      break;
    }
    case "file":
    case "image":
    case "video": {
      if (!values.mediaUrl || !/^https:\/\/.+/i.test(values.mediaUrl)) {
        errors.media = "Choose a file to generate the QR code.";
      }
      break;
    }
    default:
      errors.payloadType = "Unsupported payload type.";
  }
  return errors;
}

function parseCoordinate(value) {
  if (value === undefined || value === null || String(value).trim() === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

export function buildQrPayloadString(payloadType, values) {
  switch (payloadType) {
    case "url":
      return values.url.trim();
    case "text":
      return values.text;
    case "email": {
      const params = [];
      if (values.subject) params.push(`subject=${encodeURIComponent(values.subject)}`);
      if (values.body) params.push(`body=${encodeURIComponent(values.body)}`);
      const query = params.length ? `?${params.join("&")}` : "";
      return `mailto:${values.email.trim()}${query}`;
    }
    case "phone":
      return `tel:${values.phone.trim()}`;
    case "sms": {
      const body = values.message ? `?body=${encodeURIComponent(values.message)}` : "";
      return `smsto:${values.phone.trim()}${body}`;
    }
    case "wifi": {
      const sec = values.security || "WPA";
      const hidden = values.hidden ? "H:true;" : "";
      const pass = sec === "nopass" ? "" : `P:${escapeWifi(values.password || "")};`;
      return `WIFI:T:${sec};S:${escapeWifi(values.ssid)};${pass}${hidden};`;
    }
    case "vcard": {
      const lines = [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `N:${values.lastName || ""};${values.fullName || ""};;;`,
        `FN:${values.fullName || ""}`,
      ];
      if (values.org) lines.push(`ORG:${values.org}`);
      if (values.phone) lines.push(`TEL;TYPE=CELL:${values.phone}`);
      if (values.email) lines.push(`EMAIL:${values.email}`);
      if (values.website) lines.push(`URL:${values.website}`);
      lines.push("END:VCARD");
      return lines.join("\n");
    }
    case "whatsapp": {
      const digits = values.phone.replace(/\D/g, "");
      const text = values.message ? `?text=${encodeURIComponent(values.message)}` : "";
      return `https://wa.me/${digits}${text}`;
    }
    case "geo":
      return `geo:${Number(values.latitude)},${Number(values.longitude)}`;
    case "event": {
      const lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Nexus//QR//EN",
        "BEGIN:VEVENT",
        `SUMMARY:${escapeIcs(values.title.trim())}`,
        `DTSTART:${toIcsDate(values.start)}`,
      ];
      if (values.end) lines.push(`DTEND:${toIcsDate(values.end)}`);
      if (values.location) lines.push(`LOCATION:${escapeIcs(values.location)}`);
      if (values.description) lines.push(`DESCRIPTION:${escapeIcs(values.description)}`);
      lines.push("END:VEVENT", "END:VCALENDAR");
      return lines.join("\n");
    }
    case "upi": {
      const params = [
        `pa=${values.vpa.trim()}`,
        `pn=${encodeURIComponent(values.payee.trim())}`,
      ];
      if (values.amount) params.push(`am=${Number(values.amount).toFixed(2)}`);
      params.push("cu=INR");
      if (values.note) params.push(`tn=${encodeURIComponent(values.note.trim())}`);
      return `upi://pay?${params.join("&")}`;
    }
    case "file":
    case "image":
    case "video":
      return (values.mediaUrl || "").trim();
    default:
      return "";
  }
}

// "2026-09-30T09:30" (datetime-local) -> "20260930T093000" (floating local time)
function toIcsDate(value) {
  const compact = String(value).replace(/[-:]/g, ""); // 20260930T0930
  return `${compact.slice(0, 13)}00`;
}

function escapeIcs(value) {
  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\r?\n/g, "\\n");
}

function escapeWifi(value) {
  return String(value || "").replace(/([\\;,":])/g, "\\$1");
}

// --- Barcode validation ---

export function validateBarcodeValue(symbology, value) {
  const trimmed = (value || "").trim();
  if (!trimmed) return "A value is required.";

  switch (symbology) {
    case "EAN13":
      return /^\d{12,13}$/.test(trimmed) ? null : "EAN-13 requires 12 or 13 digits.";
    case "EAN8":
      return /^\d{7,8}$/.test(trimmed) ? null : "EAN-8 requires 7 or 8 digits.";
    case "UPC":
      return /^\d{11,12}$/.test(trimmed) ? null : "UPC-A requires 11 or 12 digits.";
    case "UPCE":
      return /^(\d{6}|[01]\d{7})$/.test(trimmed)
        ? null
        : "UPC-E requires 6 digits, or 8 digits starting with 0 or 1 (with a valid check digit).";
    case "ITF14":
      return /^\d{13,14}$/.test(trimmed) ? null : "ITF-14 requires 13 or 14 digits.";
    case "ITF":
      return /^\d+$/.test(trimmed) && trimmed.length % 2 === 0
        ? null
        : "Interleaved 2 of 5 requires an even number of digits.";
    case "MSI":
      return /^\d+$/.test(trimmed) ? null : "MSI requires digits only.";
    case "CODE39":
      if (trimmed.length > 60) return "Value is too long for Code 39.";
      return /^[0-9A-Za-z\-. $/+%]+$/.test(trimmed)
        ? null
        : "Code 39 supports letters, digits and - . $ / + % space.";
    case "CODABAR":
      return /^[0-9A-Da-d\-$:/.+]+$/.test(trimmed)
        ? null
        : "Codabar supports digits and - $ : / . + (A-D as start/stop).";
    case "PHARMACODE": {
      const n = Number(trimmed);
      return /^\d+$/.test(trimmed) && n >= 3 && n <= 131070
        ? null
        : "Pharmacode requires a whole number from 3 to 131070.";
    }
    case "DATAMATRIX":
      return trimmed.length > 1500 ? "Value is too long for Data Matrix." : null;
    case "PDF417":
    case "AZTEC":
      return trimmed.length > 1000 ? "Value is too long for this format." : null;
    case "CODE128":
    default:
      if (trimmed.length > 80) return "Value is too long for CODE128.";
      return null;
  }
}
