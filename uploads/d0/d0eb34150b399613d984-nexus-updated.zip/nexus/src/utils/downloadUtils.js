import { sanitizeFilename } from "./validators";

/**
 * Triggers a browser download for a data URL (PNG) and cleans up after itself.
 */
export function downloadDataUrl(dataUrl, filename) {
  if (!dataUrl) throw new Error("Nothing to download yet.");
  const link = document.createElement("a");
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Triggers a browser download for raw SVG markup as a real .svg file,
 * using an object URL that is revoked immediately after use.
 */
export function downloadSvgString(svgString, filename) {
  if (!svgString) throw new Error("Nothing to download yet.");
  const blob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  try {
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function buildFilename(name, extension) {
  return `${sanitizeFilename(name)}.${extension}`;
}
