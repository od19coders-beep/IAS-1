import { buildFilename } from "../downloadUtils";

describe("buildFilename", () => {
  it("combines a sanitized name with the given extension", () => {
    expect(buildFilename("My Code!", "png")).toBe("my-code.png");
  });
  it("handles missing names gracefully", () => {
    expect(buildFilename("", "svg")).toBe("nexus-code.svg");
  });
});
