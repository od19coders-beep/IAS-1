import { getFriendlyAuthErrorMessage, getFriendlyFirestoreErrorMessage } from "../errorUtils";

describe("getFriendlyAuthErrorMessage", () => {
  it("maps known Firebase auth error codes to friendly text", () => {
    expect(getFriendlyAuthErrorMessage({ code: "auth/wrong-password" })).toMatch(/Incorrect email or password/);
  });
  it("falls back to a generic message for unknown codes", () => {
    expect(getFriendlyAuthErrorMessage({ code: "auth/some-unmapped-code" })).toMatch(/Something went wrong/);
  });
});

describe("getFriendlyFirestoreErrorMessage", () => {
  it("explains permission-denied errors without leaking internals", () => {
    expect(getFriendlyFirestoreErrorMessage({ code: "permission-denied" })).toMatch(/permission/);
  });
});
