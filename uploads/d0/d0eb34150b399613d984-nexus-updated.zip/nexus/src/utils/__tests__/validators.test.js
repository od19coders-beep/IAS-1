import {
  isValidEmail,
  validatePassword,
  validateSignUpForm,
  sanitizeFilename,
  validateQrPayload,
  buildQrPayloadString,
  validateBarcodeValue,
} from "../validators";

describe("isValidEmail", () => {
  it("accepts valid emails", () => {
    expect(isValidEmail("user@example.com")).toBe(true);
  });
  it("rejects invalid emails", () => {
    expect(isValidEmail("not-an-email")).toBe(false);
    expect(isValidEmail("")).toBe(false);
  });
});

describe("validatePassword", () => {
  it("rejects short passwords", () => {
    expect(validatePassword("short")).toMatch(/at least/);
  });
  it("accepts passwords meeting the minimum length", () => {
    expect(validatePassword("longenough123")).toBeNull();
  });
});

describe("validateSignUpForm", () => {
  it("flags mismatched confirm password", () => {
    const errors = validateSignUpForm({
      name: "Jane",
      email: "jane@example.com",
      password: "password123",
      confirmPassword: "different123",
    });
    expect(errors.confirmPassword).toBeDefined();
  });

  it("passes for a fully valid form", () => {
    const errors = validateSignUpForm({
      name: "Jane",
      email: "jane@example.com",
      password: "password123",
      confirmPassword: "password123",
    });
    expect(Object.keys(errors)).toHaveLength(0);
  });
});

describe("sanitizeFilename", () => {
  it("strips unsafe characters and spaces", () => {
    expect(sanitizeFilename("My Website QR!! 2024")).toBe("my-website-qr-2024");
  });
  it("falls back to a default for empty input", () => {
    expect(sanitizeFilename("")).toBe("nexus-code");
  });
});

describe("validateQrPayload", () => {
  it("requires a well-formed URL for url payloads", () => {
    expect(validateQrPayload("url", { url: "not-a-url" }).url).toBeDefined();
    expect(validateQrPayload("url", { url: "https://example.com" }).url).toBeUndefined();
  });

  it("requires a valid email for email payloads", () => {
    expect(validateQrPayload("email", { email: "bad" }).email).toBeDefined();
  });

  it("requires a password for secured wifi networks", () => {
    const errors = validateQrPayload("wifi", { ssid: "MyNetwork", security: "WPA" });
    expect(errors.password).toBeDefined();
  });

  it("does not require a password for open wifi networks", () => {
    const errors = validateQrPayload("wifi", { ssid: "MyNetwork", security: "nopass" });
    expect(errors.password).toBeUndefined();
  });
});

describe("buildQrPayloadString", () => {
  it("builds a mailto URI", () => {
    expect(buildQrPayloadString("email", { email: "a@b.com" })).toBe("mailto:a@b.com");
  });
  it("builds a tel URI", () => {
    expect(buildQrPayloadString("phone", { phone: "+15551234567" })).toBe("tel:+15551234567");
  });
});

describe("validateBarcodeValue", () => {
  it("requires a value", () => {
    expect(validateBarcodeValue("CODE128", "")).toMatch(/required/);
  });
  it("enforces EAN-13 digit length", () => {
    expect(validateBarcodeValue("EAN13", "123")).toMatch(/12 or 13 digits/);
    expect(validateBarcodeValue("EAN13", "1234567890123")).toBeNull();
  });
  it("allows arbitrary text for CODE128 within length limits", () => {
    expect(validateBarcodeValue("CODE128", "HELLO-123")).toBeNull();
  });
});

describe("extended QR payload types", () => {
  it("builds a WhatsApp deep link from a formatted number", () => {
    expect(buildQrPayloadString("whatsapp", { phone: "+91 98765 43210", message: "Hi there" })).toBe(
      "https://wa.me/919876543210?text=Hi%20there"
    );
    expect(validateQrPayload("whatsapp", { phone: "123" }).phone).toBeDefined();
  });

  it("validates and builds geo payloads", () => {
    expect(validateQrPayload("geo", { latitude: "95", longitude: "10" }).latitude).toBeDefined();
    expect(validateQrPayload("geo", { latitude: "20.2961", longitude: "85.8245" })).toEqual({});
    expect(buildQrPayloadString("geo", { latitude: "20.2961", longitude: "85.8245" })).toBe("geo:20.2961,85.8245");
  });

  it("builds an iCalendar event and rejects an end before the start", () => {
    const values = { title: "Launch, party", start: "2026-09-30T09:30", end: "2026-09-30T11:00", location: "Bhubaneswar" };
    const ics = buildQrPayloadString("event", values);
    expect(ics).toContain("SUMMARY:Launch\\, party");
    expect(ics).toContain("DTSTART:20260930T093000");
    expect(ics).toContain("DTEND:20260930T110000");
    expect(validateQrPayload("event", { ...values, end: "2026-09-30T08:00" }).end).toBeDefined();
  });

  it("builds a UPI payment link", () => {
    const values = { vpa: "shop@okbank", payee: "Sai Sweets", amount: "150", note: "Order 12" };
    expect(validateQrPayload("upi", values)).toEqual({});
    expect(buildQrPayloadString("upi", values)).toBe(
      "upi://pay?pa=shop@okbank&pn=Sai%20Sweets&am=150.00&cu=INR&tn=Order%2012"
    );
    expect(validateQrPayload("upi", { ...values, vpa: "bad" }).vpa).toBeDefined();
  });

  it("requires a converted https URL for file, image and video payloads", () => {
    ["file", "image", "video"].forEach((type) => {
      expect(validateQrPayload(type, {}).media).toBeDefined();
      expect(validateQrPayload(type, { mediaUrl: "https://cdn.jsdelivr.net/gh/o/r@abc/a.png" })).toEqual({});
      expect(buildQrPayloadString(type, { mediaUrl: " https://x.test/a " })).toBe("https://x.test/a");
    });
  });
});

describe("extended barcode validation", () => {
  it.each([
    ["CODE39", "NEXUS 123", true],
    ["CODE39", "bad*value", false],
    ["ITF14", "1234567890123", true],
    ["ITF14", "12345", false],
    ["ITF", "123456", true],
    ["ITF", "12345", false],
    ["UPCE", "012345", true],
    ["UPCE", "0123456", false],
    ["CODABAR", "A123456B", true],
    ["PHARMACODE", "1234", true],
    ["PHARMACODE", "2", false],
    ["DATAMATRIX", "hello world", true],
    ["PDF417", "x".repeat(1001), false],
  ])("%s with %p -> valid=%s", (symbology, value, valid) => {
    expect(validateBarcodeValue(symbology, value) === null).toBe(valid);
  });
});
