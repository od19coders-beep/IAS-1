import { generateBarcodeSvgString } from "../barcodeGenerator";
import { generateQrSvgString, isLowContrast } from "../qrGenerator";

jest.mock("../fileUtils", () => ({
  ...jest.requireActual("../fileUtils"),
  // Plain function (not jest.fn): CRA enables resetMocks, which would wipe a jest.fn implementation.
  loadImage: () => Promise.resolve({ width: 100, height: 50 }),
}));

describe("barcode generator", () => {
  it("renders 1D and 2D formats to SVG", async () => {
    expect(await generateBarcodeSvgString("NEXUS-001", "CODE128")).toContain("<svg");
    expect(await generateBarcodeSvgString("hello", "DATAMATRIX")).toContain("<svg");
    expect(await generateBarcodeSvgString("hello", "PDF417")).toContain("<svg");
    expect(await generateBarcodeSvgString("hello", "AZTEC")).toContain("<svg");
  });

  it("rejects invalid values instead of producing a fake code", async () => {
    await expect(generateBarcodeSvgString("123", "EAN13")).rejects.toThrow(/EAN-13/);
    await expect(generateBarcodeSvgString("5901234123458", "EAN13")).rejects.toThrow(/not valid/);
  });
});

describe("QR generator", () => {
  it("renders an SVG without a logo", async () => {
    const svg = await generateQrSvgString("https://example.com");
    expect(svg).toContain("<svg");
    expect(svg).not.toContain("<image");
  });

  it("embeds a centered logo with a backdrop and forces error correction H", async () => {
    const plain = await generateQrSvgString("https://example.com", { errorCorrectionLevel: "L" });
    const withLogo = await generateQrSvgString("https://example.com", {
      errorCorrectionLevel: "L",
      logo: "data:image/png;base64,AAAA",
      logoSize: 0.2,
    });
    expect(withLogo).toContain("<image");
    expect(withLogo).toContain("data:image/png;base64,AAAA");
    expect(withLogo).toContain("<rect");
    // H needs more modules than L, so the code itself must be denser.
    expect(withLogo.length).toBeGreaterThan(plain.length);
  });

  it("flags low contrast colors", () => {
    expect(isLowContrast("#111111", "#FFFFFF")).toBe(false);
    expect(isLowContrast("#777777", "#7a7a7a")).toBe(true);
  });
});
