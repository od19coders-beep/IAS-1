import { formatBytes, safeFileName, getExtension } from "../fileUtils";

describe("fileUtils", () => {
  it("formats byte sizes", () => {
    expect(formatBytes(512)).toBe("512 B");
    expect(formatBytes(1536)).toBe("1.5 KB");
    expect(formatBytes(25 * 1024 * 1024)).toBe("25 MB");
  });

  it("creates URL-safe names that keep the extension", () => {
    expect(safeFileName("My Holiday Video (final)!.MP4")).toBe("My-Holiday-Video-final.mp4");
    expect(safeFileName("???")).toBe("file");
    expect(getExtension("archive.tar.gz")).toBe("gz");
  });
});
