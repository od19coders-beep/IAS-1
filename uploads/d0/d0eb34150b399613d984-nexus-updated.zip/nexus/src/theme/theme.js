import { createTheme, alpha } from "@mui/material/styles";

// Claymorphism design tokens. Every surface is a soft, inflated "clay" shape:
// large radii, a light top-left highlight, a colored bottom-right shade and
// inner bevels. Inputs are pressed *into* the surface instead.
const TOKENS = {
  light: {
    background: "#E8ECF8",
    backgroundAlt: "#DDE3F4",
    paper: "#F2F4FC",
    inset: "#E4E8F6",
    textPrimary: "#1E2342",
    textSecondary: "#5A628C",
    primary: "#6C63FF",
    primaryDark: "#5146E8",
    primaryLight: "#9A93FF",
    divider: "rgba(90, 98, 140, 0.16)",
    shade: "rgba(124, 136, 189, 0.42)",
    shadeSoft: "rgba(124, 136, 189, 0.30)",
    highlight: "rgba(255, 255, 255, 0.92)",
  },
  dark: {
    background: "#161929",
    backgroundAlt: "#1C2033",
    paper: "#222742",
    inset: "#1A1E34",
    textPrimary: "#ECEEFF",
    textSecondary: "#A3AAD3",
    primary: "#8C85FF",
    primaryDark: "#6C63FF",
    primaryLight: "#B1ACFF",
    divider: "rgba(163, 170, 211, 0.14)",
    shade: "rgba(4, 6, 16, 0.65)",
    shadeSoft: "rgba(4, 6, 16, 0.45)",
    highlight: "rgba(255, 255, 255, 0.07)",
  },
};

function buildClay(t, mode) {
  const dark = mode === "dark";
  const bevelLight = dark ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.95)";
  const bevelShade = dark ? "rgba(0,0,0,0.38)" : "rgba(124,136,189,0.22)";
  return {
    raised: `12px 14px 26px ${t.shade}, -8px -8px 20px ${t.highlight}, inset 4px 4px 8px ${bevelLight}, inset -5px -6px 10px ${bevelShade}`,
    raisedSm: `7px 8px 16px ${t.shadeSoft}, -5px -5px 12px ${t.highlight}, inset 3px 3px 5px ${bevelLight}, inset -3px -4px 7px ${bevelShade}`,
    pressed: `inset 5px 6px 11px ${t.shade}, inset -5px -5px 10px ${t.highlight}`,
    button: `9px 11px 22px ${alpha(t.primary, dark ? 0.35 : 0.45)}, -5px -5px 12px ${t.highlight}, inset 4px 5px 9px rgba(255,255,255,0.38), inset -5px -7px 12px ${alpha(t.primaryDark, 0.55)}`,
    buttonPressed: `inset 6px 7px 14px ${alpha(t.primaryDark, 0.7)}, inset -4px -4px 10px rgba(255,255,255,0.22)`,
    focusRing: `0 0 0 3px ${alpha(t.primary, 0.35)}`,
    gradient: `linear-gradient(145deg, ${t.primaryLight} 0%, ${t.primary} 48%, ${t.primaryDark} 100%)`,
    page: dark
      ? `radial-gradient(1200px 600px at 10% -10%, ${alpha(t.primary, 0.18)}, transparent 60%), radial-gradient(900px 500px at 100% 0%, rgba(236,110,173,0.10), transparent 55%), ${t.background}`
      : `radial-gradient(1200px 600px at 10% -10%, ${alpha(t.primary, 0.16)}, transparent 60%), radial-gradient(900px 500px at 100% 0%, rgba(255,150,190,0.22), transparent 55%), ${t.background}`,
  };
}

export function buildTheme(mode = "light") {
  const t = TOKENS[mode] || TOKENS.light;
  const clay = buildClay(t, mode);
  const dark = mode === "dark";

  return createTheme({
    palette: {
      mode,
      primary: { main: t.primary, dark: t.primaryDark, light: t.primaryLight, contrastText: "#FFFFFF" },
      secondary: { main: dark ? "#5EE6C8" : "#14B8A6" },
      text: { primary: t.textPrimary, secondary: t.textSecondary },
      background: { default: t.background, paper: t.paper },
      divider: t.divider,
      success: { main: dark ? "#4ADE80" : "#16A34A" },
      warning: { main: dark ? "#FBBF24" : "#D97706" },
      error: { main: dark ? "#FB7185" : "#DC2626" },
    },
    // Custom, non-MUI tokens — read in components via `theme.clay` / `theme.tokens`.
    clay,
    tokens: t,
    shape: { borderRadius: 18 },
    typography: {
      fontFamily: ["Nunito", "Inter", "-apple-system", "BlinkMacSystemFont", '"Segoe UI"', "Roboto", "Arial", "sans-serif"].join(","),
      h1: { fontWeight: 800 },
      h2: { fontWeight: 800 },
      h3: { fontWeight: 800 },
      h4: { fontWeight: 800 },
      h5: { fontWeight: 700 },
      h6: { fontWeight: 700 },
      subtitle1: { fontWeight: 700 },
      subtitle2: { fontWeight: 700 },
      button: { fontWeight: 700, textTransform: "none", letterSpacing: 0.2 },
    },
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          body: {
            background: clay.page,
            backgroundAttachment: "fixed",
            minHeight: "100vh",
            transition: "background-color .3s ease",
          },
          ":focus-visible": { outline: `3px solid ${alpha(t.primary, 0.6)}`, outlineOffset: "2px" },
          "::selection": { background: alpha(t.primary, 0.3) },
          "*::-webkit-scrollbar": { width: 10, height: 10 },
          "*::-webkit-scrollbar-thumb": { background: alpha(t.textSecondary, 0.35), borderRadius: 10 },
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: { backgroundImage: "none", borderRadius: 26, boxShadow: clay.raised, border: "none" },
        },
      },
      MuiCard: {
        styleOverrides: {
          root: { borderRadius: 28, boxShadow: clay.raised, border: "none", transition: "transform .2s ease, box-shadow .2s ease" },
        },
      },
      MuiAppBar: {
        styleOverrides: {
          root: {
            borderRadius: 0,
            boxShadow: `0 10px 30px -16px ${t.shade}`,
            backgroundColor: alpha(t.background, 0.78),
            backdropFilter: "blur(16px)",
            color: t.textPrimary,
          },
        },
      },
      MuiDrawer: {
        styleOverrides: {
          paper: { borderRadius: "0 28px 28px 0", backgroundColor: t.paper },
          paperAnchorRight: { borderRadius: "28px 0 0 28px" },
        },
      },
      MuiDialog: {
        styleOverrides: { paper: { borderRadius: 32, padding: 6 } },
      },
      MuiMenu: {
        styleOverrides: { paper: { borderRadius: 22, padding: 4, boxShadow: clay.raised } },
      },
      MuiMenuItem: {
        styleOverrides: { root: { borderRadius: 14, margin: "2px 4px", fontWeight: 600 } },
      },
      MuiButton: {
        defaultProps: { disableElevation: true },
        styleOverrides: {
          root: {
            borderRadius: 18,
            padding: "10px 22px",
            transition: "transform .18s ease, box-shadow .18s ease, background .18s ease",
            "&:hover": { transform: "translateY(-2px)" },
            "&:active": { transform: "translateY(1px)" },
          },
          sizeLarge: { padding: "14px 30px", fontSize: "1rem", borderRadius: 22 },
          sizeSmall: { padding: "6px 14px", borderRadius: 14 },
          containedPrimary: {
            background: clay.gradient,
            boxShadow: clay.button,
            "&:hover": { background: clay.gradient, boxShadow: clay.button },
            "&:active": { boxShadow: clay.buttonPressed },
            "&.Mui-disabled": {
              background: t.inset,
              color: alpha(t.textSecondary, 0.6),
              boxShadow: clay.pressed,
            },
          },
          containedError: { boxShadow: clay.raisedSm },
          outlined: {
            border: "none",
            backgroundColor: t.paper,
            color: t.textPrimary,
            boxShadow: clay.raisedSm,
            "&:hover": { border: "none", backgroundColor: t.paper, boxShadow: clay.raisedSm },
            "&:active": { boxShadow: clay.pressed },
            "&.Mui-disabled": { border: "none", boxShadow: clay.pressed, backgroundColor: t.inset },
          },
          text: { "&:hover": { backgroundColor: alpha(t.primary, 0.1) } },
        },
      },
      MuiIconButton: {
        styleOverrides: {
          root: { borderRadius: 16, "&:hover": { backgroundColor: alpha(t.primary, 0.12) } },
        },
      },
      MuiTextField: { defaultProps: { variant: "filled" } },
      MuiFilledInput: {
        defaultProps: { disableUnderline: true },
        styleOverrides: {
          root: {
            borderRadius: 18,
            backgroundColor: t.inset,
            boxShadow: clay.pressed,
            transition: "box-shadow .2s ease, background-color .2s ease",
            "&:hover": { backgroundColor: t.inset },
            "&.Mui-focused": { backgroundColor: t.inset, boxShadow: `${clay.pressed}, ${clay.focusRing}` },
            "&.Mui-error": { boxShadow: `${clay.pressed}, 0 0 0 2px ${alpha(dark ? "#FB7185" : "#DC2626", 0.5)}` },
          },
          input: { "&[type=color]": { padding: 6, height: 28, cursor: "pointer" } },
        },
      },
      MuiInputLabel: { styleOverrides: { root: { fontWeight: 600 } } },
      MuiFormHelperText: { styleOverrides: { root: { marginLeft: 6 } } },
      MuiChip: {
        styleOverrides: {
          root: { borderRadius: 14, fontWeight: 700 },
          filled: { boxShadow: clay.raisedSm, backgroundColor: t.paper },
          colorSuccess: { color: "#fff" },
        },
      },
      MuiToggleButtonGroup: {
        styleOverrides: {
          root: { backgroundColor: t.inset, boxShadow: clay.pressed, borderRadius: 18, padding: 4, gap: 2 },
          grouped: {
            border: 0,
            margin: 0,
            borderRadius: "14px !important",
            color: t.textSecondary,
            fontWeight: 700,
            "&.Mui-selected": {
              backgroundColor: t.paper,
              color: t.primary,
              boxShadow: clay.raisedSm,
              "&:hover": { backgroundColor: t.paper },
            },
            "&:not(:first-of-type)": { marginLeft: 0 },
          },
        },
      },
      MuiSlider: {
        styleOverrides: {
          root: { height: 10 },
          rail: { backgroundColor: t.inset, boxShadow: clay.pressed, opacity: 1 },
          track: { border: "none", background: clay.gradient },
          thumb: {
            width: 24,
            height: 24,
            backgroundColor: t.paper,
            boxShadow: clay.raisedSm,
            "&:before": { boxShadow: "none" },
            "&:hover, &.Mui-focusVisible": { boxShadow: `${clay.raisedSm}, ${clay.focusRing}` },
          },
        },
      },
      MuiSwitch: {
        styleOverrides: {
          root: { width: 54, height: 32, padding: 4 },
          switchBase: { padding: 6, "&.Mui-checked": { transform: "translateX(22px)" } },
          thumb: { width: 20, height: 20, backgroundColor: "#fff", boxShadow: clay.raisedSm },
          track: { borderRadius: 16, backgroundColor: t.inset, boxShadow: clay.pressed, opacity: 1 },
        },
      },
      MuiListItemButton: {
        styleOverrides: {
          root: {
            borderRadius: 18,
            margin: "3px 10px",
            "&.Mui-selected": {
              backgroundColor: t.inset,
              boxShadow: clay.pressed,
              color: t.primary,
              "&:hover": { backgroundColor: t.inset },
              "& .MuiListItemIcon-root": { color: t.primary },
            },
          },
        },
      },
      MuiAlert: {
        styleOverrides: { root: { borderRadius: 20, fontWeight: 600 }, standard: { boxShadow: clay.raisedSm } },
      },
      MuiSkeleton: {
        defaultProps: { animation: "wave" },
        styleOverrides: {
          root: { backgroundColor: alpha(t.textSecondary, dark ? 0.16 : 0.13) },
          rectangular: { borderRadius: 18 },
        },
      },
      MuiBottomNavigation: {
        styleOverrides: { root: { backgroundColor: "transparent", height: 68 } },
      },
      MuiBottomNavigationAction: {
        styleOverrides: { root: { "&.Mui-selected": { color: t.primary } } },
      },
      MuiTooltip: {
        styleOverrides: { tooltip: { borderRadius: 12, fontWeight: 600 } },
      },
      MuiDivider: { styleOverrides: { root: { borderColor: t.divider } } },
    },
  });
}

// Default export kept for any code that still imports a static theme.
export default buildTheme("light");
