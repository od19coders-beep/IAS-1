import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { onAuthStateChanged, getIdTokenResult } from "firebase/auth";
import { auth } from "../lib/firebase";
import {
  signInWithEmail,
  signUpWithEmail,
  signInWithGoogle as signInWithGoogleService,
  signOutUser,
  sendPasswordReset,
  resendVerificationEmail as resendVerificationEmailService,
} from "../services/authService";
import { createUserProfile, getUserProfile, touchLastLogin } from "../services/userService";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (authUser) => {
    if (!authUser) {
      setUserProfile(null);
      setIsAdmin(false);
      return;
    }

    // Admin status is resolved from a trusted custom claim on the ID token,
    // never from a client-writable Firestore field.
    const tokenResult = await getIdTokenResult(authUser);
    setIsAdmin(Boolean(tokenResult.claims.admin));

    let profile = await getUserProfile(authUser.uid);
    if (!profile) {
      // Handles the case where Auth account creation succeeded but profile
      // creation previously failed (e.g. dropped connection).
      profile = await createUserProfile(authUser, { displayName: authUser.displayName });
    } else {
      touchLastLogin(authUser.uid).catch(() => {});
    }
    setUserProfile(profile);
  }, []);

  const refreshUserProfile = useCallback(async () => {
    if (auth.currentUser) {
      await loadProfile(auth.currentUser);
    }
  }, [loadProfile]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      setLoading(true);
      setUser(authUser);
      try {
        await loadProfile(authUser);
      } finally {
        setLoading(false);
      }
    });
    return unsubscribe;
  }, [loadProfile]);

  const signIn = useCallback(async (email, password) => {
    const authUser = await signInWithEmail({ email, password });
    return authUser;
  }, []);

  const signUp = useCallback(async ({ name, email, password }) => {
    const authUser = await signUpWithEmail({ name, email, password });
    return authUser;
  }, []);

  const signInWithGoogle = useCallback(async () => {
    const authUser = await signInWithGoogleService();
    return authUser;
  }, []);

  const signOut = useCallback(async () => {
    await signOutUser();
  }, []);

  const sendPasswordResetEmailAction = useCallback(async (email) => {
    await sendPasswordReset(email);
  }, []);

  const resendVerificationEmail = useCallback(async () => {
    await resendVerificationEmailService();
  }, []);

  const value = useMemo(
    () => ({
      user,
      userProfile,
      loading,
      isAuthenticated: Boolean(user),
      isAdmin,
      signIn,
      signUp,
      signInWithGoogle,
      signOut,
      sendPasswordReset: sendPasswordResetEmailAction,
      resendVerificationEmail,
      refreshUserProfile,
    }),
    [
      user,
      userProfile,
      loading,
      isAdmin,
      signIn,
      signUp,
      signInWithGoogle,
      signOut,
      sendPasswordResetEmailAction,
      resendVerificationEmail,
      refreshUserProfile,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuthContext() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuthContext must be used within AuthProvider");
  return ctx;
}
