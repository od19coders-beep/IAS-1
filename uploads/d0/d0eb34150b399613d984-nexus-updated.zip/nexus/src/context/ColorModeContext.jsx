import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import CssBaseline from "@mui/material/CssBaseline";
import { ThemeProvider } from "@mui/material/styles";
import { buildTheme } from "../theme/theme";
import { getSetting, setSetting } from "../lib/localDb";

const STORAGE_KEY = "nexus:color-mode";
const VALID = ["light", "dark", "system"];

const ColorModeContext = createContext(null);

// localStorage mirrors the IndexedDB value purely so the very first paint
// (before IndexedDB resolves) already uses the right theme — no flash.
const readMirror = () => {
  try {
    const value = window.localStorage.getItem(STORAGE_KEY);
    return VALID.includes(value) ? value : null;
  } catch {
    return null;
  }
};

const writeMirror = (value) => {
  try {
    window.localStorage.setItem(STORAGE_KEY, value);
  } catch {
    // ignore
  }
};

const prefersDark = () =>
  typeof window !== "undefined" &&
  typeof window.matchMedia === "function" &&
  window.matchMedia("(prefers-color-scheme: dark)").matches;

export function ColorModeProvider({ children }) {
  const [preference, setPreference] = useState(() => readMirror() || "system");
  const [systemDark, setSystemDark] = useState(prefersDark);

  // IndexedDB is the source of truth once it resolves.
  useEffect(() => {
    let cancelled = false;
    getSetting("colorMode").then((stored) => {
      if (!cancelled && VALID.includes(stored)) {
        setPreference(stored);
        writeMirror(stored);
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (typeof window.matchMedia !== "function") return undefined;
    const query = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = (event) => setSystemDark(event.matches);
    query.addEventListener?.("change", onChange);
    return () => query.removeEventListener?.("change", onChange);
  }, []);

  const mode = preference === "system" ? (systemDark ? "dark" : "light") : preference;
  const theme = useMemo(() => buildTheme(mode), [mode]);

  useEffect(() => {
    const root = document.documentElement;
    root.style.colorScheme = mode;
    root.style.background = theme.tokens.background;
    root.setAttribute("data-theme", mode);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme.tokens.background);
  }, [mode, theme]);

  const setColorMode = useCallback((next) => {
    if (!VALID.includes(next)) return;
    setPreference(next);
    writeMirror(next);
    setSetting("colorMode", next);
  }, []);

  const toggleColorMode = useCallback(() => {
    setColorMode(mode === "dark" ? "light" : "dark");
  }, [mode, setColorMode]);

  const value = useMemo(
    () => ({ mode, preference, setColorMode, toggleColorMode }),
    [mode, preference, setColorMode, toggleColorMode]
  );

  return (
    <ColorModeContext.Provider value={value}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export function useColorMode() {
  const ctx = useContext(ColorModeContext);
  if (!ctx) throw new Error("useColorMode must be used within ColorModeProvider");
  return ctx;
}
