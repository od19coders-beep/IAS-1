import React, { useState } from "react";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Drawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import MenuIcon from "@mui/icons-material/Menu";
import { useNavigate, useLocation } from "react-router-dom";
import Logo from "./Logo";
import ColorModeToggle from "./ColorModeToggle";
import { ROUTES } from "../constants/routes";

const NAV_LINKS = [
  { label: "Home", sectionId: "home" },
  { label: "Features", sectionId: "features" },
  { label: "About", sectionId: "about" },
];

export default function AppBarComponent() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavClick = (sectionId) => {
    setDrawerOpen(false);
    if (location.pathname !== ROUTES.HOME) {
      navigate(ROUTES.HOME);
      window.setTimeout(() => scrollToSection(sectionId), 100);
    } else {
      scrollToSection(sectionId);
    }
  };

  const scrollToSection = (sectionId) => {
    const el = document.getElementById(sectionId);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <MuiAppBar
      position="sticky"
      color="inherit"
      elevation={0}
    >
      <Toolbar sx={{ maxWidth: 1200, width: "100%", mx: "auto" }}>
        <Logo />
        <Box sx={{ flexGrow: 1 }} />
        <Box sx={{ display: { xs: "none", md: "flex" }, gap: 1, alignItems: "center" }}>
          {NAV_LINKS.map((link) => (
            <Button key={link.sectionId} color="inherit" onClick={() => handleNavClick(link.sectionId)}>
              {link.label}
            </Button>
          ))}
          <ColorModeToggle />
          <Button variant="contained" onClick={() => navigate(ROUTES.SIGN_IN)}>
            Sign In
          </Button>
        </Box>
        <Box sx={{ display: { xs: "flex", md: "none" }, mr: 1 }}>
          <ColorModeToggle size="small" />
        </Box>
        <IconButton
          aria-label="Open navigation menu"
          sx={{ display: { xs: "inline-flex", md: "none" } }}
          onClick={() => setDrawerOpen(true)}
        >
          <MenuIcon />
        </IconButton>
      </Toolbar>

      <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <Box sx={{ width: 260, pt: 2 }} role="presentation">
          <Box sx={{ px: 2, mb: 1 }}>
            <Logo />
          </Box>
          <List>
            {NAV_LINKS.map((link) => (
              <ListItemButton key={link.sectionId} onClick={() => handleNavClick(link.sectionId)}>
                <ListItemText primary={link.label} />
              </ListItemButton>
            ))}
            <ListItemButton
              onClick={() => {
                setDrawerOpen(false);
                navigate(ROUTES.SIGN_IN);
              }}
            >
              <ListItemText primary="Sign In" />
            </ListItemButton>
          </List>
        </Box>
      </Drawer>
    </MuiAppBar>
  );
}
