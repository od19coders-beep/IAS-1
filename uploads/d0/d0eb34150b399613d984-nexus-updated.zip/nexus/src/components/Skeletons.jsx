import React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Paper from "@mui/material/Paper";
import Skeleton from "@mui/material/Skeleton";
import Stack from "@mui/material/Stack";

// Skeleton placeholders used everywhere a spinner would otherwise appear.
// They mirror the real layout so the page doesn't jump when content arrives.

export function StatCardSkeleton() {
  return (
    <Card aria-hidden="true">
      <CardContent sx={{ display: "flex", alignItems: "center", gap: 2 }}>
        <Skeleton variant="rounded" width={48} height={48} />
        <Box sx={{ flexGrow: 1 }}>
          <Skeleton width="40%" height={32} />
          <Skeleton width="70%" />
        </Box>
      </CardContent>
    </Card>
  );
}

export function CodeCardSkeleton() {
  return (
    <Card aria-hidden="true">
      <CardContent>
        <Stack direction="row" justifyContent="space-between">
          <Skeleton variant="rounded" width={44} height={44} />
          <Skeleton variant="circular" width={28} height={28} />
        </Stack>
        <Skeleton width="75%" height={28} sx={{ mt: 1.5 }} />
        <Skeleton variant="rounded" width={90} height={26} sx={{ mt: 0.5 }} />
        <Skeleton width="50%" sx={{ mt: 1.5 }} />
      </CardContent>
    </Card>
  );
}

export function CodeGridSkeleton({ count = 6 }) {
  return (
    <Box
      aria-hidden="true"
      sx={{
        display: "grid",
        gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(3, 1fr)" },
        gap: 3,
      }}
    >
      {Array.from({ length: count }).map((_, i) => (
        <CodeCardSkeleton key={i} />
      ))}
    </Box>
  );
}

export function PreviewSkeleton({ size = 200 }) {
  return (
    <Skeleton
      variant="rounded"
      width={size}
      height={size}
      aria-hidden="true"
      sx={{ maxWidth: "100%" }}
    />
  );
}

export function DashboardSkeleton() {
  return (
    <Box aria-hidden="true">
      <Skeleton width={280} height={40} />
      <Skeleton width={220} sx={{ mb: 3 }} />
      <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", sm: "repeat(3, 1fr)" }, gap: 3, mb: 4 }}>
        <StatCardSkeleton />
        <StatCardSkeleton />
        <StatCardSkeleton />
      </Box>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ mb: 4 }}>
        <Skeleton variant="rounded" width={180} height={46} />
        <Skeleton variant="rounded" width={180} height={46} />
      </Stack>
      <Skeleton width={160} height={32} sx={{ mb: 1 }} />
      <CodeGridSkeleton count={3} />
    </Box>
  );
}

export function DetailSkeleton() {
  return (
    <Box aria-hidden="true">
      <Stack direction="row" justifyContent="space-between" sx={{ mb: 3 }}>
        <Skeleton width={260} height={40} />
        <Stack direction="row" spacing={1}>
          <Skeleton variant="circular" width={40} height={40} />
          <Skeleton variant="circular" width={40} height={40} />
        </Stack>
      </Stack>
      <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 3 }}>
        <Paper sx={{ p: 3, display: "grid", placeItems: "center", minHeight: 300 }}>
          <Skeleton variant="rounded" width={220} height={220} />
        </Paper>
        <Paper sx={{ p: 3 }}>
          <Stack spacing={2.5}>
            {[0, 1, 2].map((i) => (
              <Box key={i}>
                <Skeleton width="25%" />
                <Skeleton width={i === 1 ? "90%" : "55%"} height={28} />
              </Box>
            ))}
            <Skeleton variant="rounded" width={150} height={44} />
          </Stack>
        </Paper>
      </Box>
    </Box>
  );
}

export function TableSkeleton({ rows = 6 }) {
  return (
    <Paper aria-hidden="true" sx={{ p: 3 }}>
      <Skeleton width={200} height={32} sx={{ mb: 2 }} />
      <Stack spacing={1.5}>
        {Array.from({ length: rows }).map((_, i) => (
          <Stack key={i} direction="row" spacing={2} alignItems="center">
            <Skeleton variant="circular" width={36} height={36} />
            <Skeleton sx={{ flex: 2 }} height={28} />
            <Skeleton sx={{ flex: 1 }} height={28} />
            <Skeleton sx={{ flex: 1 }} height={28} />
          </Stack>
        ))}
      </Stack>
    </Paper>
  );
}

export function FormSkeleton() {
  return (
    <Box aria-hidden="true">
      <Skeleton width={240} height={40} />
      <Skeleton width={360} sx={{ mb: 3, maxWidth: "100%" }} />
      <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" }, gap: 3 }}>
        <Paper sx={{ p: 3 }}>
          <Stack spacing={2.5}>
            <Box sx={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 1.5 }}>
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} variant="rounded" height={68} />
              ))}
            </Box>
            <Skeleton variant="rounded" height={56} />
            <Skeleton variant="rounded" height={56} />
            <Skeleton variant="rounded" height={56} />
          </Stack>
        </Paper>
        <Stack spacing={2}>
          <Paper sx={{ p: 3, display: "grid", placeItems: "center", minHeight: 260 }}>
            <Skeleton variant="rounded" width={200} height={200} />
          </Paper>
          <Skeleton variant="rounded" height={56} />
          <Skeleton variant="rounded" height={46} />
        </Stack>
      </Box>
    </Box>
  );
}
