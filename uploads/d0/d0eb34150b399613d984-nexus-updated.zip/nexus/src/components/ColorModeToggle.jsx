import React from "react";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import LightModeIcon from "@mui/icons-material/LightModeRounded";
import DarkModeIcon from "@mui/icons-material/DarkModeRounded";
import { useColorMode } from "../context/ColorModeContext";

export default function ColorModeToggle({ size = "medium" }) {
  const { mode, toggleColorMode } = useColorMode();
  const next = mode === "dark" ? "light" : "dark";

  return (
    <Tooltip title={`Switch to ${next} mode`}>
      <IconButton
        onClick={toggleColorMode}
        size={size}
        aria-label={`Switch to ${next} mode`}
        sx={(theme) => ({
          backgroundColor: theme.palette.background.paper,
          boxShadow: theme.clay?.raisedSm,
          color: "primary.main",
          "&:hover": { backgroundColor: theme.palette.background.paper },
          "&:active": { boxShadow: theme.clay?.pressed },
        })}
      >
        {mode === "dark" ? <LightModeIcon /> : <DarkModeIcon />}
      </IconButton>
    </Tooltip>
  );
}
