import React from "react";
import Paper from "@mui/material/Paper";
import BottomNavigation from "@mui/material/BottomNavigation";
import BottomNavigationAction from "@mui/material/BottomNavigationAction";
import DashboardIcon from "@mui/icons-material/DashboardOutlined";
import QrCodeIcon from "@mui/icons-material/QrCode2";
import FolderIcon from "@mui/icons-material/FolderOutlined";
import PersonIcon from "@mui/icons-material/PersonOutlined";
import { useLocation, useNavigate } from "react-router-dom";
import { ROUTES } from "../constants/routes";

const ITEMS = [
  { label: "Overview", path: ROUTES.DASHBOARD, icon: <DashboardIcon /> },
  { label: "Create", path: ROUTES.CREATE_QR, icon: <QrCodeIcon /> },
  { label: "My Codes", path: ROUTES.MY_CODES, icon: <FolderIcon /> },
  { label: "Profile", path: ROUTES.PROFILE, icon: <PersonIcon /> },
];

export default function MobileBottomNavigation() {
  const location = useLocation();
  const navigate = useNavigate();
  const currentIndex = Math.max(
    0,
    ITEMS.findIndex((item) => location.pathname === item.path)
  );

  return (
    <Paper
      elevation={0}
      sx={{
        position: "fixed",
        bottom: 8,
        left: 12,
        right: 12,
        borderRadius: "28px",
        overflow: "hidden",
        display: { xs: "block", md: "none" },
        zIndex: (theme) => theme.zIndex.appBar,
      }}
    >
      <BottomNavigation
        showLabels
        value={currentIndex}
        onChange={(_e, newValue) => navigate(ITEMS[newValue].path)}
      >
        {ITEMS.map((item) => (
          <BottomNavigationAction key={item.path} label={item.label} icon={item.icon} />
        ))}
      </BottomNavigation>
    </Paper>
  );
}
