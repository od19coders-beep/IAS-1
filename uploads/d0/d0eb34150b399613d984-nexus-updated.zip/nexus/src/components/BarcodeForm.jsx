import React from "react";
import Stack from "@mui/material/Stack";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import ListSubheader from "@mui/material/ListSubheader";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Slider from "@mui/material/Slider";
import { BARCODE_SYMBOLOGIES } from "../constants/codeTypes";

const LINEAR = BARCODE_SYMBOLOGIES.filter((s) => s.group === "1D");
const MATRIX = BARCODE_SYMBOLOGIES.filter((s) => s.group === "2D");

export default function BarcodeForm({
  symbology,
  onSymbologyChange,
  value,
  onValueChange,
  error,
  settings,
  onSettingsChange,
}) {
  const setSetting = (key, val) => onSettingsChange({ ...settings, [key]: val });
  const selected = BARCODE_SYMBOLOGIES.find((s) => s.value === symbology);
  const is2D = selected?.group === "2D";

  return (
    <Stack spacing={3}>
      <TextField
        select
        label="Barcode format"
        value={symbology}
        onChange={(e) => onSymbologyChange(e.target.value)}
        fullWidth
      >
        <ListSubheader>Linear (1D)</ListSubheader>
        {LINEAR.map((option) => (
          <MenuItem key={option.value} value={option.value}>
            {option.label}
          </MenuItem>
        ))}
        <ListSubheader>Matrix &amp; stacked (2D)</ListSubheader>
        {MATRIX.map((option) => (
          <MenuItem key={option.value} value={option.value}>
            {option.label}
          </MenuItem>
        ))}
      </TextField>

      <TextField
        label="Value"
        value={value}
        onChange={(e) => onValueChange(e.target.value)}
        error={Boolean(error)}
        helperText={error || `${selected?.hint || ""}${selected?.example ? ` — e.g. ${selected.example}` : ""}`}
        placeholder={selected?.example}
        multiline={is2D}
        minRows={is2D ? 2 : undefined}
        fullWidth
        required
      />

      {!is2D && (
        <FormControlLabel
          control={
            <Switch
              checked={settings.displayValue}
              onChange={(e) => setSetting("displayValue", e.target.checked)}
            />
          }
          label="Show human-readable value"
        />
      )}

      <Stack direction="row" spacing={2}>
        <TextField
          label={is2D ? "Module color" : "Bar color"}
          type="color"
          value={settings.lineColor}
          onChange={(e) => setSetting("lineColor", e.target.value)}
          sx={{ width: 150 }}
        />
        <TextField
          label="Background"
          type="color"
          value={settings.background}
          onChange={(e) => setSetting("background", e.target.value)}
          sx={{ width: 150 }}
        />
      </Stack>

      <Box>
        <Typography variant="body2" color="text.secondary" gutterBottom>
          {is2D ? "Scale" : "Bar width"}: {settings.width}
        </Typography>
        <Slider
          value={settings.width}
          min={1}
          max={4}
          step={1}
          onChange={(_e, v) => setSetting("width", v)}
          aria-label="Barcode bar width"
        />
      </Box>
      {!is2D && (
        <Box>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Height: {settings.height}px
          </Typography>
          <Slider
            value={settings.height}
            min={40}
            max={200}
            step={10}
            onChange={(_e, v) => setSetting("height", v)}
            aria-label="Barcode height in pixels"
          />
        </Box>
      )}
      <Box>
        <Typography variant="body2" color="text.secondary" gutterBottom>
          Margin: {settings.margin}
        </Typography>
        <Slider
          value={settings.margin}
          min={0}
          max={30}
          step={5}
          onChange={(_e, v) => setSetting("margin", v)}
          aria-label="Barcode margin"
        />
      </Box>
    </Stack>
  );
}
