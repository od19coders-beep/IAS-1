import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Alert from "@mui/material/Alert";
import { generateQrDataUrl } from "../utils/qrGenerator";
import { generateBarcodePngDataUrl } from "../utils/barcodeGenerator";
import { logDevError } from "../utils/errorUtils";
import { PreviewSkeleton } from "./Skeletons";

/**
 * Renders a live preview of a QR code or barcode from the current payload
 * and settings. Regenerates whenever inputs change. While generating — or
 * while the parent is still preparing the payload (`pending`, e.g. a file
 * being converted) — a skeleton is shown instead of a spinner.
 */
export default function CodePreview({ codeType, payload, symbology, settings = {}, pending = false, emptyMessage }) {
  const [dataUrl, setDataUrl] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function generate() {
      if (!payload) {
        setDataUrl(null);
        setError(null);
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const url =
          codeType === "barcode"
            ? await generateBarcodePngDataUrl(payload, symbology, settings)
            : await generateQrDataUrl(payload, settings);
        if (!cancelled) setDataUrl(url);
      } catch (err) {
        logDevError("CodePreview.generate", err);
        if (!cancelled) {
          setError(err.message || "Could not generate a preview.");
          setDataUrl(null);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    generate();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [codeType, payload, symbology, JSON.stringify(settings)]);

  const showSkeleton = pending || loading;

  return (
    <Box
      aria-busy={showSkeleton ? "true" : undefined}
      sx={(theme) => ({
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        minHeight: 260,
        borderRadius: "32px",
        p: 3,
        backgroundColor: theme.palette.background.paper,
        boxShadow: theme.clay?.raised,
      })}
    >
      {showSkeleton && <PreviewSkeleton size={210} />}
      {!showSkeleton && error && (
        <Alert severity="error" sx={{ width: "100%" }}>
          {error}
        </Alert>
      )}
      {!showSkeleton && !error && dataUrl && (
        <Box
          component="img"
          src={dataUrl}
          alt="Generated code preview"
          sx={{ maxWidth: "100%", maxHeight: 300, borderRadius: "18px", boxShadow: (t) => t.clay?.raisedSm, bgcolor: "#fff" }}
        />
      )}
      {!showSkeleton && !error && !dataUrl && (
        <Box color="text.secondary" sx={{ textAlign: "center", maxWidth: 260 }}>
          {emptyMessage || "Fill in the form to see a live preview."}
        </Box>
      )}
    </Box>
  );
}
