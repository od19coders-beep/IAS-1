import React from "react";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import ImageIcon from "@mui/icons-material/ImageRounded";
import VideoIcon from "@mui/icons-material/VideocamRounded";
import FileIcon from "@mui/icons-material/InsertDriveFileRounded";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../constants/routes";

export default function HeroSection() {
  const navigate = useNavigate();

  return (
    <Box id="home" sx={{ py: { xs: 8, md: 12 } }}>
      <Container maxWidth="lg">
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", md: "1.1fr 0.9fr" },
            gap: 6,
            alignItems: "center",
          }}
        >
          <Box>
            <Typography variant="h2" sx={{ fontSize: { xs: "2.2rem", md: "3rem" }, mb: 2 }}>
              Turn anything into a QR Code &amp; Barcode.
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400, mb: 4 }}>
              Links, payments, Wi-Fi — even files, images and videos. Add your logo,
              pick from 14 barcode formats, and keep everything in your own library.
            </Typography>
            <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
              <Button
                size="large"
                variant="contained"
                onClick={() => navigate(ROUTES.SIGN_IN)}
              >
                Get Started
              </Button>
              <Button size="large" variant="outlined" onClick={() => navigate(ROUTES.SIGN_IN)}>
                Sign In
              </Button>
            </Stack>
          </Box>

          <Box sx={{ position: "relative", display: "flex", justifyContent: "center", alignItems: "center", minHeight: 320 }}>
            <Box
              sx={(theme) => ({
                width: { xs: 230, sm: 280 },
                height: { xs: 230, sm: 280 },
                borderRadius: "64px",
                display: "grid",
                placeItems: "center",
                backgroundColor: theme.palette.background.paper,
                boxShadow: theme.clay?.raised,
                transform: "rotate(-4deg)",
              })}
            >
              <QrCode2Icon sx={{ fontSize: { xs: 130, sm: 170 }, color: "primary.main" }} aria-hidden="true" />
            </Box>
            {[
              { Icon: ImageIcon, top: 0, right: { xs: 0, sm: 24 }, rotate: 8 },
              { Icon: VideoIcon, bottom: 8, left: { xs: 0, sm: 16 }, rotate: -10 },
              { Icon: FileIcon, bottom: 0, right: { xs: 12, sm: 48 }, rotate: 6 },
            ].map(({ Icon, rotate, ...pos }, i) => (
              <Box
                key={i}
                aria-hidden="true"
                sx={(theme) => ({
                  position: "absolute",
                  ...pos,
                  width: 76,
                  height: 76,
                  borderRadius: "26px",
                  display: "grid",
                  placeItems: "center",
                  color: "primary.main",
                  backgroundColor: theme.palette.background.paper,
                  boxShadow: theme.clay?.raisedSm,
                  transform: `rotate(${rotate}deg)`,
                })}
              >
                <Icon fontSize="large" />
              </Box>
            ))}
          </Box>
        </Box>
      </Container>
    </Box>
  );
}
