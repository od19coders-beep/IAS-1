import React, { useState } from "react";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import DownloadIcon from "@mui/icons-material/Download";
import { useSnackbar } from "../context/SnackbarContext";

/**
 * Generic download menu. The caller supplies async handlers for each format
 * so this component has no knowledge of QR vs barcode specifics.
 */
export default function DownloadMenu({ onDownloadPng, onDownloadSvg, disabled }) {
  const [anchorEl, setAnchorEl] = useState(null);
  const { showError, showSuccess } = useSnackbar();

  const handleDownload = async (handler, label) => {
    setAnchorEl(null);
    try {
      await handler();
      showSuccess(`${label} downloaded.`);
    } catch (error) {
      showError(error.message || "Download failed. Please try again.");
    }
  };

  return (
    <>
      <Button
        variant="contained"
        startIcon={<DownloadIcon />}
        disabled={disabled}
        onClick={(e) => setAnchorEl(e.currentTarget)}
        aria-haspopup="true"
      >
        Download
      </Button>
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}>
        <MenuItem onClick={() => handleDownload(onDownloadPng, "PNG")}>
          Download PNG
        </MenuItem>
        {onDownloadSvg && (
          <MenuItem onClick={() => handleDownload(onDownloadSvg, "SVG")}>
            Download SVG
          </MenuItem>
        )}
      </Menu>
    </>
  );
}
