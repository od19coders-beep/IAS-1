import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import EmptyState from "../EmptyState";

describe("EmptyState", () => {
  it("renders title and description", () => {
    render(<EmptyState title="No codes yet" description="Create your first code." />);
    expect(screen.getByText("No codes yet")).toBeInTheDocument();
    expect(screen.getByText("Create your first code.")).toBeInTheDocument();
  });

  it("invokes onAction when the action button is clicked", () => {
    const onAction = jest.fn();
    render(<EmptyState title="Empty" actionLabel="Create QR Code" onAction={onAction} />);
    fireEvent.click(screen.getByRole("button", { name: "Create QR Code" }));
    expect(onAction).toHaveBeenCalledTimes(1);
  });

  it("does not render an action button when none is provided", () => {
    render(<EmptyState title="Empty" />);
    expect(screen.queryByRole("button")).not.toBeInTheDocument();
  });
});
