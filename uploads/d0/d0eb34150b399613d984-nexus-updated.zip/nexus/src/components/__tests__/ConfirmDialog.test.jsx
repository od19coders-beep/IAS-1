import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import ConfirmDialog from "../ConfirmDialog";

describe("ConfirmDialog", () => {
  it("renders the title and description when open", () => {
    render(
      <ConfirmDialog
        open
        title="Delete this code?"
        description="This can't be undone."
        onConfirm={() => {}}
        onClose={() => {}}
      />
    );
    expect(screen.getByText("Delete this code?")).toBeInTheDocument();
    expect(screen.getByText("This can't be undone.")).toBeInTheDocument();
  });

  it("calls onConfirm when the confirm button is clicked", () => {
    const onConfirm = jest.fn();
    render(
      <ConfirmDialog
        open
        title="Delete?"
        description="Sure?"
        confirmLabel="Delete"
        onConfirm={onConfirm}
        onClose={() => {}}
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    expect(onConfirm).toHaveBeenCalledTimes(1);
  });

  it("calls onClose when Cancel is clicked", () => {
    const onClose = jest.fn();
    render(
      <ConfirmDialog
        open
        title="Delete?"
        description="Sure?"
        onConfirm={() => {}}
        onClose={onClose}
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
