import React from "react";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Divider from "@mui/material/Divider";
import DashboardIcon from "@mui/icons-material/DashboardOutlined";
import QrCodeIcon from "@mui/icons-material/QrCode2";
import BarcodeIcon from "@mui/icons-material/ViewWeekOutlined";
import FolderIcon from "@mui/icons-material/FolderOutlined";
import PersonIcon from "@mui/icons-material/PersonOutlined";
import SettingsIcon from "@mui/icons-material/SettingsOutlined";
import LogoutIcon from "@mui/icons-material/LogoutOutlined";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettingsOutlined";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { ROUTES } from "../constants/routes";
import Logo from "./Logo";

const NAV_ITEMS = [
  { label: "Overview", path: ROUTES.DASHBOARD, icon: <DashboardIcon /> },
  { label: "Create QR Code", path: ROUTES.CREATE_QR, icon: <QrCodeIcon /> },
  { label: "Create Barcode", path: ROUTES.CREATE_BARCODE, icon: <BarcodeIcon /> },
  { label: "My Codes", path: ROUTES.MY_CODES, icon: <FolderIcon /> },
  { label: "Profile", path: ROUTES.PROFILE, icon: <PersonIcon /> },
  { label: "Settings", path: ROUTES.SETTINGS, icon: <SettingsIcon /> },
];

export default function DashboardSidebar({ onNavigate }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { isAdmin, signOut } = useAuth();
  const { showSuccess } = useSnackbar();

  const go = (path) => {
    navigate(path);
    onNavigate?.();
  };

  const handleSignOut = async () => {
    await signOut();
    showSuccess("Signed out successfully.");
    navigate(ROUTES.SIGN_IN);
  };

  return (
    <Box sx={{ width: { xs: 260, md: "100%" }, height: "100%", display: "flex", flexDirection: "column" }}>
      <Box sx={{ p: 2 }}>
        <Logo />
      </Box>
      <Divider />
      <List sx={{ flexGrow: 1 }}>
        {NAV_ITEMS.map((item) => (
          <ListItemButton
            key={item.path}
            selected={location.pathname === item.path}
            onClick={() => go(item.path)}
          >
            <ListItemIcon>{item.icon}</ListItemIcon>
            <ListItemText primary={item.label} />
          </ListItemButton>
        ))}
        {isAdmin && (
          <>
            <Divider sx={{ my: 1 }} />
            <ListItemButton
              selected={location.pathname.startsWith(ROUTES.ADMIN)}
              onClick={() => go(ROUTES.ADMIN)}
            >
              <ListItemIcon>
                <AdminPanelSettingsIcon />
              </ListItemIcon>
              <ListItemText primary="Admin" />
            </ListItemButton>
          </>
        )}
      </List>
      <Divider />
      <List>
        <ListItemButton onClick={handleSignOut}>
          <ListItemIcon>
            <LogoutIcon />
          </ListItemIcon>
          <ListItemText primary="Sign Out" />
        </ListItemButton>
      </List>
    </Box>
  );
}
