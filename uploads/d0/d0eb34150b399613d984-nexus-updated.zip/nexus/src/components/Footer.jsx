import React from "react";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import Link from "@mui/material/Link";
import { Link as RouterLink } from "react-router-dom";
import Logo from "./Logo";
import { ROUTES } from "../constants/routes";
import { currentYear } from "../utils/dateUtils";

export default function Footer() {
  return (
    <Box component="footer" sx={(theme) => ({ py: 5, mt: 4, backgroundColor: theme.tokens?.backgroundAlt, borderRadius: "40px 40px 0 0", boxShadow: theme.clay?.pressed })}>
      <Container maxWidth="lg">
        <Stack
          direction={{ xs: "column", sm: "row" }}
          justifyContent="space-between"
          alignItems={{ xs: "flex-start", sm: "center" }}
          spacing={3}
        >
          <Box>
            <Logo />
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1, maxWidth: 320 }}>
              A simple platform to create, customize, and manage QR codes and
              barcodes.
            </Typography>
          </Box>
          <Stack direction="row" spacing={3}>
            <Link component={RouterLink} to={ROUTES.HOME} underline="hover" color="text.secondary">
              Home
            </Link>
            <Link component={RouterLink} to={ROUTES.SIGN_IN} underline="hover" color="text.secondary">
              Sign In
            </Link>
            <Link component={RouterLink} to={ROUTES.SIGN_UP} underline="hover" color="text.secondary">
              Create Account
            </Link>
          </Stack>
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 4 }}>
          © {currentYear()} Nexus. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
}
