import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";

export default function EmptyState({ icon, title, description, actionLabel, onAction }) {
  return (
    <Box
      sx={{
        textAlign: "center",
        py: 6,
        px: 2,
        border: "1px dashed",
        borderColor: "divider",
        borderRadius: 2,
      }}
    >
      {icon && (
        <Box sx={{ mb: 1, color: "text.secondary" }} aria-hidden="true">
          {icon}
        </Box>
      )}
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>
      {description && (
        <Typography color="text.secondary" sx={{ mb: 2, maxWidth: 420, mx: "auto" }}>
          {description}
        </Typography>
      )}
      {actionLabel && onAction && (
        <Button variant="contained" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </Box>
  );
}
