import React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Slider from "@mui/material/Slider";
import Divider from "@mui/material/Divider";
import { QR_PAYLOAD_TYPES as T, QR_ERROR_CORRECTION_LEVELS, isMediaPayloadType } from "../constants/codeTypes";
import PayloadTypePicker from "./PayloadTypePicker";
import MediaPicker from "./MediaPicker";
import LogoUploader from "./LogoUploader";

/**
 * Renders the appropriate fields for the selected QR payload type. Purely
 * controlled — all state lives in the parent page.
 */
export default function QRCodeForm({
  payloadType,
  onPayloadTypeChange,
  values,
  onValuesChange,
  errors = {},
  settings,
  onSettingsChange,
  media,
}) {
  const setValue = (key, value) => onValuesChange({ ...values, [key]: value });
  const setSetting = (key, value) => onSettingsChange({ ...settings, [key]: value });

  const field = (key, label, extra = {}) => (
    <TextField
      label={label}
      value={values[key] || ""}
      onChange={(e) => setValue(key, e.target.value)}
      error={Boolean(errors[key])}
      helperText={errors[key]}
      fullWidth
      {...extra}
    />
  );

  return (
    <Stack spacing={3}>
      <PayloadTypePicker value={payloadType} onChange={onPayloadTypeChange} />

      <Divider />

      {payloadType === T.URL &&
        field("url", "Website URL", { placeholder: "https://example.com", required: true })}

      {payloadType === T.TEXT &&
        field("text", "Text", { multiline: true, minRows: 3, required: true })}

      {payloadType === T.EMAIL && (
        <Stack spacing={2}>
          {field("email", "Email address", { required: true })}
          {field("subject", "Subject (optional)")}
          {field("body", "Body (optional)", { multiline: true, minRows: 2 })}
        </Stack>
      )}

      {(payloadType === T.PHONE || payloadType === T.SMS) && (
        <Stack spacing={2}>
          {field("phone", "Phone number", { placeholder: "+91 98765 43210", required: true })}
          {payloadType === T.SMS && field("message", "Message (optional)", { multiline: true, minRows: 2 })}
        </Stack>
      )}

      {payloadType === T.WHATSAPP && (
        <Stack spacing={2}>
          {field("phone", "WhatsApp number (with country code)", { placeholder: "+91 98765 43210", required: true })}
          {field("message", "Pre-filled message (optional)", { multiline: true, minRows: 2 })}
        </Stack>
      )}

      {payloadType === T.WIFI && (
        <Stack spacing={2}>
          {field("ssid", "Network name (SSID)", { required: true })}
          <TextField
            select
            label="Security"
            value={values.security || "WPA"}
            onChange={(e) => setValue("security", e.target.value)}
            fullWidth
          >
            <MenuItem value="WPA">WPA/WPA2/WPA3</MenuItem>
            <MenuItem value="WEP">WEP</MenuItem>
            <MenuItem value="nopass">None (open network)</MenuItem>
          </TextField>
          {values.security !== "nopass" && field("password", "Password", { type: "password", required: true })}
          <FormControlLabel
            control={<Switch checked={Boolean(values.hidden)} onChange={(e) => setValue("hidden", e.target.checked)} />}
            label="Hidden network"
          />
        </Stack>
      )}

      {payloadType === T.VCARD && (
        <Stack spacing={2}>
          {field("fullName", "Full name", { required: true })}
          {field("org", "Organization (optional)")}
          {field("phone", "Phone (optional)")}
          {field("email", "Email (optional)")}
          {field("website", "Website (optional)")}
        </Stack>
      )}

      {payloadType === T.GEO && (
        <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
          {field("latitude", "Latitude", { placeholder: "20.2961", required: true, inputProps: { inputMode: "decimal" } })}
          {field("longitude", "Longitude", { placeholder: "85.8245", required: true, inputProps: { inputMode: "decimal" } })}
        </Stack>
      )}

      {payloadType === T.EVENT && (
        <Stack spacing={2}>
          {field("title", "Event title", { required: true })}
          <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
            {field("start", "Starts", { type: "datetime-local", required: true, InputLabelProps: { shrink: true } })}
            {field("end", "Ends (optional)", { type: "datetime-local", InputLabelProps: { shrink: true } })}
          </Stack>
          {field("location", "Location (optional)")}
          {field("description", "Description (optional)", { multiline: true, minRows: 2 })}
        </Stack>
      )}

      {payloadType === T.UPI && (
        <Stack spacing={2}>
          {field("vpa", "UPI ID", { placeholder: "name@bank", required: true })}
          {field("payee", "Payee name", { required: true })}
          {field("amount", "Amount in ₹ (optional)", { inputProps: { inputMode: "decimal" } })}
          {field("note", "Note (optional)")}
        </Stack>
      )}

      {isMediaPayloadType(payloadType) && (
        <MediaPicker kind={payloadType} media={media} error={errors.media} />
      )}

      <Box>
        <Typography variant="subtitle2" gutterBottom>
          Customization
        </Typography>
        <Stack spacing={2.5}>
          <Stack direction="row" spacing={2}>
            <TextField
              label="Foreground"
              type="color"
              value={settings.foregroundColor}
              onChange={(e) => setSetting("foregroundColor", e.target.value)}
              sx={{ width: 150 }}
            />
            <TextField
              label="Background"
              type="color"
              value={settings.backgroundColor}
              onChange={(e) => setSetting("backgroundColor", e.target.value)}
              sx={{ width: 150 }}
            />
          </Stack>
          <TextField
            select
            label="Error correction level"
            value={settings.logo ? "H" : settings.errorCorrectionLevel}
            onChange={(e) => setSetting("errorCorrectionLevel", e.target.value)}
            disabled={Boolean(settings.logo)}
            helperText={settings.logo ? "Locked to H while a center logo is used." : undefined}
            sx={{ maxWidth: 280 }}
          >
            {QR_ERROR_CORRECTION_LEVELS.map((level) => (
              <MenuItem key={level.value} value={level.value}>
                {level.label}
              </MenuItem>
            ))}
          </TextField>
          <Box>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Size: {settings.width}px
            </Typography>
            <Slider
              value={settings.width}
              min={128}
              max={1024}
              step={64}
              onChange={(_e, value) => setSetting("width", value)}
              aria-label="QR code size in pixels"
            />
          </Box>
          <Box>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Margin: {settings.margin}
            </Typography>
            <Slider
              value={settings.margin}
              min={0}
              max={10}
              step={1}
              onChange={(_e, value) => setSetting("margin", value)}
              aria-label="QR code margin"
            />
          </Box>
        </Stack>
      </Box>

      <Box>
        <Typography variant="subtitle2" gutterBottom>
          Center logo
        </Typography>
        <LogoUploader settings={settings} onChange={onSettingsChange} />
      </Box>
    </Stack>
  );
}
