import React, { useState } from "react";
import Box from "@mui/material/Box";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Drawer from "@mui/material/Drawer";
import MenuIcon from "@mui/icons-material/Menu";
import { Outlet, useLocation } from "react-router-dom";
import DashboardSidebar from "./DashboardSidebar";
import MobileBottomNavigation from "./MobileBottomNavigation";
import UserMenu from "./UserMenu";
import ColorModeToggle from "./ColorModeToggle";

const PAGE_TITLES = {
  "/dashboard": "Overview",
  "/dashboard/create/qr": "Create QR Code",
  "/dashboard/create/barcode": "Create Barcode",
  "/dashboard/codes": "My Codes",
  "/dashboard/profile": "Profile",
  "/dashboard/settings": "Settings",
};

export default function DashboardLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const title = PAGE_TITLES[location.pathname] || "Dashboard";

  return (
    <Box sx={{ display: "flex", minHeight: "100vh" }}>
      <Box
        component="nav"
        sx={{ width: { md: 264 }, flexShrink: { md: 0 }, display: { xs: "none", md: "block" } }}
      >
        <Box
          sx={(theme) => ({
            width: 244,
            height: "calc(100vh - 32px)",
            position: "sticky",
            top: 16,
            ml: 2,
            borderRadius: "32px",
            overflow: "hidden",
            backgroundColor: theme.palette.background.paper,
            boxShadow: theme.clay?.raised,
          })}
        >
          <DashboardSidebar />
        </Box>
      </Box>

      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        ModalProps={{ keepMounted: true }}
        sx={{ display: { xs: "block", md: "none" } }}
      >
        <DashboardSidebar onNavigate={() => setMobileOpen(false)} />
      </Drawer>

      <Box sx={{ flexGrow: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <AppBar
          position="sticky"
          color="inherit"
          elevation={0}
        >
          <Toolbar>
            <IconButton
              aria-label="Open dashboard menu"
              sx={{ display: { xs: "inline-flex", md: "none" }, mr: 1 }}
              onClick={() => setMobileOpen(true)}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" component="h1" sx={{ flexGrow: 1, fontSize: "1.1rem" }}>
              {title}
            </Typography>
            <Box sx={{ mr: 1.5 }}>
              <ColorModeToggle />
            </Box>
            <UserMenu />
          </Toolbar>
        </AppBar>

        <Box
          component="main"
          sx={{
            flexGrow: 1,
            p: { xs: 2, md: 3 },
            pb: { xs: 9, md: 3 },
            maxWidth: 1200,
            width: "100%",
            mx: "auto",
          }}
        >
          <Outlet />
        </Box>

        <MobileBottomNavigation />
      </Box>
    </Box>
  );
}
