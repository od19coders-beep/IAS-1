import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import { Link as RouterLink } from "react-router-dom";
import { ROUTES } from "../constants/routes";

export default function Logo({ size = "medium" }) {
  const fontSize = size === "large" ? "1.5rem" : "1.15rem";
  return (
    <Box
      component={RouterLink}
      to={ROUTES.HOME}
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 1,
        textDecoration: "none",
        color: "text.primary",
      }}
      aria-label="Nexus home"
    >
      <QrCode2Icon color="primary" fontSize={size === "large" ? "large" : "medium"} />
      <Typography sx={{ fontWeight: 700, fontSize }}>Nexus</Typography>
    </Box>
  );
}
