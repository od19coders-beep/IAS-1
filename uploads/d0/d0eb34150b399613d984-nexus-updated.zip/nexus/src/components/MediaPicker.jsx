import React, { useRef, useState } from "react";
import Alert from "@mui/material/Alert";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import CloudUploadIcon from "@mui/icons-material/CloudUploadRounded";
import InsertDriveFileIcon from "@mui/icons-material/InsertDriveFileRounded";
import CheckCircleIcon from "@mui/icons-material/CheckCircleRounded";
import { APP_CONFIG } from "../constants/appConfig";
import { formatBytes } from "../utils/fileUtils";

const COPY = {
  file: { accept: undefined, title: "Drop any file here", hint: "PDF, documents, archives, audio…" },
  image: { accept: "image/*", title: "Drop an image here", hint: "PNG, JPG, GIF, WebP, SVG" },
  video: { accept: "video/*", title: "Drop a video here", hint: "MP4, WebM, MOV" },
};

/**
 * Drag-and-drop / click file chooser for file, image and video QR codes.
 * It deliberately says nothing about uploading: conversion happens silently
 * after selection, and the preview panel shows a skeleton meanwhile.
 */
export default function MediaPicker({ kind = "file", media, error }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const copy = COPY[kind] || COPY.file;

  const name = media.file?.name || media.record?.name;
  const size = media.file?.size ?? media.record?.size;
  const hasFile = Boolean(name);

  const choose = (file) => {
    if (file) media.select(file);
  };

  const onDrop = (event) => {
    event.preventDefault();
    setDragging(false);
    choose(event.dataTransfer.files?.[0]);
  };

  return (
    <Stack spacing={2}>
      <input
        ref={inputRef}
        type="file"
        hidden
        accept={copy.accept}
        onChange={(e) => {
          choose(e.target.files?.[0]);
          e.target.value = "";
        }}
      />

      {!hasFile && (
        <Box
          role="button"
          tabIndex={0}
          aria-label={copy.title}
          onClick={() => inputRef.current?.click()}
          onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && inputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          sx={(theme) => ({
            cursor: "pointer",
            textAlign: "center",
            px: 3,
            py: 5,
            borderRadius: "26px",
            color: "text.secondary",
            backgroundColor: theme.tokens?.inset,
            boxShadow: dragging ? `${theme.clay?.pressed}, ${theme.clay?.focusRing}` : theme.clay?.pressed,
            transition: "box-shadow .2s ease",
          })}
        >
          <CloudUploadIcon sx={{ fontSize: 44, color: "primary.main" }} />
          <Typography variant="subtitle1" color="text.primary">
            {copy.title}
          </Typography>
          <Typography variant="body2">
            or click to browse · {copy.hint} · up to {APP_CONFIG.maxUploadMb} MB
          </Typography>
        </Box>
      )}

      {hasFile && (
        <Box
          sx={(theme) => ({
            display: "flex",
            alignItems: "center",
            gap: 2,
            p: 1.5,
            borderRadius: "24px",
            backgroundColor: theme.palette.background.paper,
            boxShadow: theme.clay?.raisedSm,
          })}
        >
          <Box
            sx={(theme) => ({
              width: 64,
              height: 64,
              flexShrink: 0,
              borderRadius: "18px",
              overflow: "hidden",
              display: "grid",
              placeItems: "center",
              backgroundColor: theme.tokens?.inset,
              boxShadow: theme.clay?.pressed,
              color: "primary.main",
            })}
          >
            {media.previewUrl && (media.file?.type || media.record?.type || "").startsWith("image/") && (
              <Box component="img" src={media.previewUrl} alt="" sx={{ width: "100%", height: "100%", objectFit: "cover" }} />
            )}
            {media.previewUrl && (media.file?.type || media.record?.type || "").startsWith("video/") && (
              <Box component="video" src={media.previewUrl} muted preload="metadata" sx={{ width: "100%", height: "100%", objectFit: "cover" }} />
            )}
            {!media.previewUrl && <InsertDriveFileIcon />}
          </Box>
          <Box sx={{ minWidth: 0, flexGrow: 1 }}>
            <Typography noWrap sx={{ fontWeight: 700 }} title={name}>
              {name}
            </Typography>
            <Stack direction="row" spacing={1} alignItems="center">
              <Typography variant="body2" color="text.secondary">
                {formatBytes(size)}
              </Typography>
              {media.status === "ready" && (
                <CheckCircleIcon fontSize="small" color="success" titleAccess="Ready" />
              )}
            </Stack>
          </Box>
          <Stack direction="row" spacing={1}>
            <Button size="small" variant="outlined" onClick={() => inputRef.current?.click()}>
              Replace
            </Button>
            <Button size="small" color="inherit" onClick={media.clear}>
              Remove
            </Button>
          </Stack>
        </Box>
      )}

      {(media.status === "error" || error) && (
        <Alert
          severity="error"
          action={
            media.status === "error" && media.file ? (
              <Button color="inherit" size="small" onClick={media.retry}>
                Retry
              </Button>
            ) : undefined
          }
        >
          {media.error || error}
        </Alert>
      )}
    </Stack>
  );
}
