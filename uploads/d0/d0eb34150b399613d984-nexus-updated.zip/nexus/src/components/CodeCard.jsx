import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import StarIcon from "@mui/icons-material/Star";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import ViewWeekOutlinedIcon from "@mui/icons-material/ViewWeekOutlined";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../constants/routes";
import { QR_PAYLOAD_LABELS } from "../constants/codeTypes";
import { PAYLOAD_ICONS } from "./PayloadTypePicker";
import { formatDate } from "../utils/dateUtils";

function describeType(code) {
  if (code.codeType === "barcode") return code.format || "Barcode";
  return QR_PAYLOAD_LABELS[code.payloadType] ? `QR · ${QR_PAYLOAD_LABELS[code.payloadType]}` : "QR Code";
}

export default function CodeCard({ code, onToggleFavorite, onDelete }) {
  const navigate = useNavigate();
  const TypeIcon =
    code.codeType === "barcode" ? ViewWeekOutlinedIcon : PAYLOAD_ICONS[code.payloadType] || QrCode2Icon;

  return (
    <Card sx={{ "&:hover": { transform: "translateY(-3px)" } }}>
      <CardContent>
        <Box sx={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <Box
            sx={(theme) => ({
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 48,
              height: 48,
              borderRadius: "16px",
              backgroundColor: theme.tokens?.inset,
              boxShadow: theme.clay?.pressed,
              color: "primary.main",
              flexShrink: 0,
            })}
            aria-hidden="true"
          >
            <TypeIcon />
          </Box>
          <IconButton
            aria-label={code.isFavorite ? "Remove from favorites" : "Add to favorites"}
            onClick={() => onToggleFavorite(code.id, !code.isFavorite)}
            size="small"
          >
            {code.isFavorite ? <StarIcon color="warning" /> : <StarBorderIcon />}
          </IconButton>
        </Box>

        <Typography
          variant="subtitle1"
          sx={{ mt: 1.5, cursor: "pointer" }}
          noWrap
          onClick={() => navigate(ROUTES.codeDetails(code.id))}
        >
          {code.name}
        </Typography>
        <Chip size="small" label={describeType(code)} sx={{ mt: 0.5 }} />
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          Created {formatDate(code.createdAt)}
        </Typography>
      </CardContent>
      <CardActions sx={{ justifyContent: "space-between", px: 2, pb: 2 }}>
        <Typography
          variant="body2"
          color="primary"
          sx={{ cursor: "pointer", fontWeight: 700 }}
          onClick={() => navigate(ROUTES.codeDetails(code.id))}
        >
          View details
        </Typography>
        <IconButton aria-label={`Delete ${code.name}`} onClick={() => onDelete(code)} size="small">
          <DeleteOutlineIcon fontSize="small" />
        </IconButton>
      </CardActions>
    </Card>
  );
}
