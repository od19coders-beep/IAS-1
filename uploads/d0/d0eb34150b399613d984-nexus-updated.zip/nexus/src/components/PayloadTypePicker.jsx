import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import LinkIcon from "@mui/icons-material/LinkRounded";
import TextIcon from "@mui/icons-material/NotesRounded";
import EmailIcon from "@mui/icons-material/EmailRounded";
import PhoneIcon from "@mui/icons-material/PhoneRounded";
import SmsIcon from "@mui/icons-material/SmsRounded";
import WhatsAppIcon from "@mui/icons-material/WhatsApp";
import WifiIcon from "@mui/icons-material/WifiRounded";
import ContactIcon from "@mui/icons-material/ContactsRounded";
import LocationIcon from "@mui/icons-material/PlaceRounded";
import EventIcon from "@mui/icons-material/EventRounded";
import UpiIcon from "@mui/icons-material/CurrencyRupeeRounded";
import FileIcon from "@mui/icons-material/InsertDriveFileRounded";
import ImageIcon from "@mui/icons-material/ImageRounded";
import VideoIcon from "@mui/icons-material/VideocamRounded";
import { QR_PAYLOAD_GROUPS, QR_PAYLOAD_LABELS, QR_PAYLOAD_TYPES as T } from "../constants/codeTypes";

export const PAYLOAD_ICONS = {
  [T.URL]: LinkIcon,
  [T.TEXT]: TextIcon,
  [T.EMAIL]: EmailIcon,
  [T.PHONE]: PhoneIcon,
  [T.SMS]: SmsIcon,
  [T.WHATSAPP]: WhatsAppIcon,
  [T.WIFI]: WifiIcon,
  [T.VCARD]: ContactIcon,
  [T.GEO]: LocationIcon,
  [T.EVENT]: EventIcon,
  [T.UPI]: UpiIcon,
  [T.FILE]: FileIcon,
  [T.IMAGE]: ImageIcon,
  [T.VIDEO]: VideoIcon,
};

/**
 * Clay tile grid for choosing what the QR code contains. Each tile is a
 * real radio-style button (aria-pressed) so it's keyboard and screen-reader friendly.
 */
export default function PayloadTypePicker({ value, onChange }) {
  return (
    <Stack spacing={2} role="group" aria-label="QR code content type">
      {QR_PAYLOAD_GROUPS.map((group) => (
        <Box key={group.label}>
          <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 700, letterSpacing: 0.6, textTransform: "uppercase" }}>
            {group.label}
          </Typography>
          <Box
            sx={{
              mt: 1,
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(92px, 1fr))",
              gap: 1.5,
            }}
          >
            {group.types.map((type) => {
              const Icon = PAYLOAD_ICONS[type];
              const selected = value === type;
              return (
                <Box
                  key={type}
                  component="button"
                  type="button"
                  aria-pressed={selected}
                  onClick={() => onChange(type)}
                  sx={(theme) => ({
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 0.75,
                    px: 1,
                    py: 1.5,
                    border: 0,
                    cursor: "pointer",
                    font: "inherit",
                    fontSize: "0.78rem",
                    fontWeight: 700,
                    textAlign: "center",
                    borderRadius: "20px",
                    color: selected ? theme.palette.primary.main : theme.palette.text.secondary,
                    backgroundColor: selected ? theme.tokens?.inset : theme.palette.background.paper,
                    boxShadow: selected ? theme.clay?.pressed : theme.clay?.raisedSm,
                    transition: "transform .18s ease, box-shadow .18s ease, color .18s ease",
                    "&:hover": { transform: selected ? "none" : "translateY(-2px)" },
                    "&:active": { boxShadow: theme.clay?.pressed },
                  })}
                >
                  <Icon fontSize="medium" />
                  <span>{QR_PAYLOAD_LABELS[type]}</span>
                </Box>
              );
            })}
          </Box>
        </Box>
      ))}
    </Stack>
  );
}
