import React, { useRef, useState } from "react";
import Alert from "@mui/material/Alert";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Slider from "@mui/material/Slider";
import Stack from "@mui/material/Stack";
import Switch from "@mui/material/Switch";
import Typography from "@mui/material/Typography";
import AddPhotoIcon from "@mui/icons-material/AddPhotoAlternateRounded";
import { APP_CONFIG } from "../constants/appConfig";
import { imageFileToLogoDataUrl } from "../utils/fileUtils";

/**
 * Lets the user place an image in the middle of the QR code. The image is
 * downscaled to a small PNG so it can be stored with the saved code, and the
 * generator automatically switches to the highest error correction.
 */
export default function LogoUploader({ settings, onChange }) {
  const inputRef = useRef(null);
  const [error, setError] = useState(null);

  const handleFile = async (file) => {
    if (!file) return;
    setError(null);
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file.");
      return;
    }
    if (file.size > APP_CONFIG.maxLogoBytes) {
      setError("Logo must be smaller than 2 MB.");
      return;
    }
    try {
      const logo = await imageFileToLogoDataUrl(file);
      onChange({ ...settings, logo, errorCorrectionLevel: "H" });
    } catch (err) {
      setError(err.message || "That image could not be used.");
    }
  };

  const removeLogo = () => onChange({ ...settings, logo: null });
  const logoSizePercent = Math.round((settings.logoSize ?? 0.22) * 100);

  return (
    <Stack spacing={2}>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        hidden
        onChange={(e) => {
          handleFile(e.target.files?.[0]);
          e.target.value = "";
        }}
      />

      <Stack direction="row" spacing={2} alignItems="center">
        <Box
          sx={(theme) => ({
            width: 64,
            height: 64,
            borderRadius: "20px",
            display: "grid",
            placeItems: "center",
            overflow: "hidden",
            color: "text.secondary",
            backgroundColor: theme.tokens?.inset,
            boxShadow: theme.clay?.pressed,
          })}
        >
          {settings.logo ? (
            <Box component="img" src={settings.logo} alt="Logo preview" sx={{ maxWidth: "80%", maxHeight: "80%" }} />
          ) : (
            <AddPhotoIcon />
          )}
        </Box>
        <Stack direction="row" spacing={1}>
          <Button variant="outlined" size="small" onClick={() => inputRef.current?.click()}>
            {settings.logo ? "Change logo" : "Add center logo"}
          </Button>
          {settings.logo && (
            <Button size="small" color="inherit" onClick={removeLogo}>
              Remove
            </Button>
          )}
        </Stack>
      </Stack>

      {error && <Alert severity="error">{error}</Alert>}

      {settings.logo && (
        <>
          <Box>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Logo size: {logoSizePercent}% of the code
            </Typography>
            <Slider
              value={logoSizePercent}
              min={10}
              max={30}
              step={1}
              onChange={(_e, v) => onChange({ ...settings, logoSize: v / 100 })}
              aria-label="Logo size"
            />
          </Box>
          <FormControlLabel
            control={
              <Switch
                checked={settings.logoBackdrop !== false}
                onChange={(e) => onChange({ ...settings, logoBackdrop: e.target.checked })}
              />
            }
            label="Clear area behind the logo"
          />
          <Typography variant="caption" color="text.secondary">
            Error correction is set to H automatically so the code still scans with a logo. Test-scan
            before printing.
          </Typography>
        </>
      )}
    </Stack>
  );
}
