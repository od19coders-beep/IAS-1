import React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

export default function StatCard({ label, value, icon }) {
  return (
    <Card>
      <CardContent sx={{ display: "flex", alignItems: "center", gap: 2 }}>
        {icon && (
          <Box
            sx={(theme) => ({
              width: 52,
              height: 52,
              borderRadius: "18px",
              backgroundColor: theme.tokens?.inset,
              boxShadow: theme.clay?.pressed,
              color: "primary.main",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            })}
            aria-hidden="true"
          >
            {icon}
          </Box>
        )}
        <Box>
          <Typography variant="h5" component="p">
            {value}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {label}
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
}
