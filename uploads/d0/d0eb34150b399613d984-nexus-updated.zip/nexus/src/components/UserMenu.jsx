import React, { useState } from "react";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import PersonIcon from "@mui/icons-material/Person";
import SettingsIcon from "@mui/icons-material/Settings";
import LogoutIcon from "@mui/icons-material/Logout";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { ROUTES } from "../constants/routes";
import { getFriendlyAuthErrorMessage, logDevError } from "../utils/errorUtils";

export default function UserMenu() {
  const [anchorEl, setAnchorEl] = useState(null);
  const { userProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useSnackbar();

  const initials = (userProfile?.displayName || "U")
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const handleSignOut = async () => {
    setAnchorEl(null);
    try {
      await signOut();
      showSuccess("Signed out successfully.");
      navigate(ROUTES.SIGN_IN);
    } catch (error) {
      logDevError("UserMenu.signOut", error);
      showError(getFriendlyAuthErrorMessage(error));
    }
  };

  return (
    <>
      <IconButton
        onClick={(e) => setAnchorEl(e.currentTarget)}
        aria-label="Open account menu"
        aria-controls={anchorEl ? "user-menu" : undefined}
        aria-haspopup="true"
      >
        <Avatar sx={{ width: 32, height: 32, bgcolor: "primary.main", fontSize: 14 }}>
          {initials}
        </Avatar>
      </IconButton>
      <Menu id="user-menu" anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}>
        <MenuItem
          onClick={() => {
            setAnchorEl(null);
            navigate(ROUTES.PROFILE);
          }}
        >
          <ListItemIcon>
            <PersonIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Profile</ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            setAnchorEl(null);
            navigate(ROUTES.SETTINGS);
          }}
        >
          <ListItemIcon>
            <SettingsIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Settings</ListItemText>
        </MenuItem>
        <MenuItem onClick={handleSignOut}>
          <ListItemIcon>
            <LogoutIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Sign Out</ListItemText>
        </MenuItem>
      </Menu>
    </>
  );
}
