import React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Skeleton from "@mui/material/Skeleton";

/**
 * Button with a skeleton shimmer instead of a spinner while `loading`.
 * The label keeps its space (hidden) so the button never changes size.
 */
export default function LoadingButton({ loading, disabled, children, startIcon, sx, ...rest }) {
  return (
    <Button
      disabled={loading || disabled}
      aria-busy={loading ? "true" : undefined}
      sx={[{ position: "relative" }, ...(Array.isArray(sx) ? sx : [sx])]}
      {...rest}
    >
      <Box
        component="span"
        sx={{
          display: "inline-flex",
          alignItems: "center",
          gap: 1,
          visibility: loading ? "hidden" : "visible",
        }}
      >
        {startIcon}
        {children}
      </Box>
      {loading && (
        <Skeleton
          aria-hidden="true"
          variant="rounded"
          animation="wave"
          sx={{ position: "absolute", top: "28%", bottom: "28%", left: "16%", right: "16%", borderRadius: 10 }}
        />
      )}
    </Button>
  );
}
