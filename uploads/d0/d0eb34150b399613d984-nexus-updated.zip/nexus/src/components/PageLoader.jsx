import React from "react";
import Box from "@mui/material/Box";
import Skeleton from "@mui/material/Skeleton";
import Stack from "@mui/material/Stack";
import {
  CodeGridSkeleton,
  DashboardSkeleton,
  DetailSkeleton,
  FormSkeleton,
  TableSkeleton,
} from "./Skeletons";

const visuallyHidden = {
  position: "absolute",
  width: 1,
  height: 1,
  overflow: "hidden",
  clip: "rect(0 0 0 0)",
  whiteSpace: "nowrap",
};

function GenericSkeleton() {
  return (
    <Stack spacing={2} aria-hidden="true">
      <Skeleton width={260} height={42} />
      <Skeleton width="60%" />
      <Skeleton variant="rounded" height={180} />
      <Skeleton variant="rounded" height={120} />
    </Stack>
  );
}

const VARIANTS = {
  page: GenericSkeleton,
  dashboard: DashboardSkeleton,
  grid: () => <CodeGridSkeleton count={6} />,
  detail: DetailSkeleton,
  table: TableSkeleton,
  form: FormSkeleton,
};

/**
 * Skeleton-based replacement for the old spinner loader. The `label` is kept
 * for assistive technology only; sighted users see the layout shimmer.
 */
export default function PageLoader({ label = "Loading…", variant = "page" }) {
  const Variant = VARIANTS[variant] || GenericSkeleton;
  return (
    <Box role="status" aria-live="polite" aria-busy="true" sx={{ width: "100%", py: 2, position: "relative" }}>
      <Box component="span" sx={visuallyHidden}>
        {label}
      </Box>
      <Variant />
    </Box>
  );
}
