const toInt = (value, fallback) => {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
};

export const APP_CONFIG = {
  name: "Nexus",
  description: "QR Code & Barcode Generator",
  minPasswordLength: 8,
  resendVerificationCooldownSeconds: 60,
  codesPageSize: 12,
  maxPayloadLength: 4000,
  maxCodeNameLength: 120,
  // Largest file (in MB) that can be turned into a QR code. GitHub's contents
  // API accepts up to 100 MB; jsDelivr (default CDN) serves up to 50 MB.
  maxUploadMb: Math.min(toInt(process.env.REACT_APP_MAX_UPLOAD_MB, 25), 100),
  maxLogoBytes: 2 * 1024 * 1024,
};

export default APP_CONFIG;
