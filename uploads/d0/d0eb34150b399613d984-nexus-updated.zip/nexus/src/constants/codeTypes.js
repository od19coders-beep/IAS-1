export const CODE_TYPES = {
  QR: "qr",
  BARCODE: "barcode",
};

export const QR_PAYLOAD_TYPES = {
  URL: "url",
  TEXT: "text",
  EMAIL: "email",
  PHONE: "phone",
  SMS: "sms",
  WHATSAPP: "whatsapp",
  WIFI: "wifi",
  VCARD: "vcard",
  GEO: "geo",
  EVENT: "event",
  UPI: "upi",
  FILE: "file",
  IMAGE: "image",
  VIDEO: "video",
};

/** Payload types whose content is an uploaded file that becomes a public URL. */
export const QR_MEDIA_TYPES = [
  QR_PAYLOAD_TYPES.FILE,
  QR_PAYLOAD_TYPES.IMAGE,
  QR_PAYLOAD_TYPES.VIDEO,
];

export const isMediaPayloadType = (type) => QR_MEDIA_TYPES.includes(type);

export const QR_PAYLOAD_LABELS = {
  [QR_PAYLOAD_TYPES.URL]: "Website URL",
  [QR_PAYLOAD_TYPES.TEXT]: "Plain text",
  [QR_PAYLOAD_TYPES.EMAIL]: "Email",
  [QR_PAYLOAD_TYPES.PHONE]: "Phone number",
  [QR_PAYLOAD_TYPES.SMS]: "SMS",
  [QR_PAYLOAD_TYPES.WHATSAPP]: "WhatsApp",
  [QR_PAYLOAD_TYPES.WIFI]: "Wi-Fi network",
  [QR_PAYLOAD_TYPES.VCARD]: "Contact (vCard)",
  [QR_PAYLOAD_TYPES.GEO]: "Location",
  [QR_PAYLOAD_TYPES.EVENT]: "Calendar event",
  [QR_PAYLOAD_TYPES.UPI]: "UPI payment",
  [QR_PAYLOAD_TYPES.FILE]: "Any file",
  [QR_PAYLOAD_TYPES.IMAGE]: "Image",
  [QR_PAYLOAD_TYPES.VIDEO]: "Video",
};

/** Grouping used by the type picker. */
export const QR_PAYLOAD_GROUPS = [
  { label: "Links & text", types: [QR_PAYLOAD_TYPES.URL, QR_PAYLOAD_TYPES.TEXT] },
  {
    label: "Contact & messaging",
    types: [
      QR_PAYLOAD_TYPES.VCARD,
      QR_PAYLOAD_TYPES.EMAIL,
      QR_PAYLOAD_TYPES.PHONE,
      QR_PAYLOAD_TYPES.SMS,
      QR_PAYLOAD_TYPES.WHATSAPP,
    ],
  },
  {
    label: "Utilities",
    types: [
      QR_PAYLOAD_TYPES.WIFI,
      QR_PAYLOAD_TYPES.GEO,
      QR_PAYLOAD_TYPES.EVENT,
      QR_PAYLOAD_TYPES.UPI,
    ],
  },
  {
    label: "Files & media",
    types: [QR_PAYLOAD_TYPES.FILE, QR_PAYLOAD_TYPES.IMAGE, QR_PAYLOAD_TYPES.VIDEO],
  },
];

export const QR_ERROR_CORRECTION_LEVELS = [
  { value: "L", label: "L — 7% recovery" },
  { value: "M", label: "M — 15% recovery" },
  { value: "Q", label: "Q — 25% recovery" },
  { value: "H", label: "H — 30% recovery" },
];

/**
 * Barcode symbologies. `group` splits linear (1D) from matrix/stacked (2D)
 * formats. 2D formats are rendered by bwip-js (lazy-loaded); the rest by
 * JsBarcode.
 */
export const BARCODE_SYMBOLOGIES = [
  { value: "CODE128", label: "Code 128", group: "1D", hint: "Any text, up to 80 characters", example: "NEXUS-2026-001" },
  { value: "CODE39", label: "Code 39", group: "1D", hint: "Letters, digits and - . $ / + % space", example: "NEXUS 123" },
  { value: "EAN13", label: "EAN-13", group: "1D", hint: "12 or 13 digits (retail products)", example: "5901234123457" },
  { value: "EAN8", label: "EAN-8", group: "1D", hint: "7 or 8 digits", example: "96385074" },
  { value: "UPC", label: "UPC-A", group: "1D", hint: "11 or 12 digits (North American retail)", example: "042100005264" },
  { value: "UPCE", label: "UPC-E", group: "1D", hint: "6 digits, or 8 starting with 0/1 (compressed UPC)", example: "012345" },
  { value: "ITF14", label: "ITF-14", group: "1D", hint: "13 or 14 digits (shipping cartons)", example: "1234567890123" },
  { value: "ITF", label: "Interleaved 2 of 5", group: "1D", hint: "An even number of digits", example: "123456" },
  { value: "MSI", label: "MSI Plessey", group: "1D", hint: "Digits only", example: "1234567" },
  { value: "CODABAR", label: "Codabar", group: "1D", hint: "Digits and - $ : / . + (optional A-D start/stop)", example: "A123456B" },
  { value: "PHARMACODE", label: "Pharmacode", group: "1D", hint: "A whole number from 3 to 131070", example: "1234" },
  { value: "DATAMATRIX", label: "Data Matrix", group: "2D", hint: "Any text, up to 1500 characters", example: "Nexus 2D" },
  { value: "PDF417", label: "PDF417", group: "2D", hint: "Any text, up to 1000 characters", example: "Boarding pass 42" },
  { value: "AZTEC", label: "Aztec Code", group: "2D", hint: "Any text, up to 1000 characters", example: "Ticket 1042" },
];

export const TWO_D_SYMBOLOGIES = BARCODE_SYMBOLOGIES.filter((s) => s.group === "2D").map(
  (s) => s.value
);

export default CODE_TYPES;
