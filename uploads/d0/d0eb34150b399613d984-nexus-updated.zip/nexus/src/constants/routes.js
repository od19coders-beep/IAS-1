export const ROUTES = {
  HOME: "/",
  SIGN_IN: "/auth/sign-in",
  SIGN_UP: "/auth/sign-up",
  FORGOT_PASSWORD: "/auth/forget-password",
  VERIFY_EMAIL: "/auth/verify-email",

  DASHBOARD: "/dashboard",
  CREATE_QR: "/dashboard/create/qr",
  CREATE_BARCODE: "/dashboard/create/barcode",
  MY_CODES: "/dashboard/codes",
  CODE_DETAILS: "/dashboard/codes/:codeId",
  codeDetails: (codeId) => `/dashboard/codes/${codeId}`,
  PROFILE: "/dashboard/profile",
  SETTINGS: "/dashboard/settings",

  ADMIN: "/admin",
  ADMIN_USERS: "/admin/users",
  ADMIN_CODES: "/admin/codes",
};

export default ROUTES;
