import React, { Suspense, lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { ROUTES } from "./constants/routes";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminRoute from "./components/AdminRoute";
import DashboardLayout from "./components/DashboardLayout";
import PageLoader from "./components/PageLoader";

// Public pages load eagerly (landing page is the first paint).
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import SignIn from "./auth/SignIn";
import SignUp from "./auth/SignUp";
import ForgetPassword from "./auth/ForgetPassword";
import VerifyEmail from "./auth/VerifyEmail";

// Protected/admin route modules are lazy-loaded to keep the public bundle small.
const Dashboard = lazy(() => import("./pages/Dashboard"));
const CreateQR = lazy(() => import("./pages/CreateQR"));
const CreateBarcode = lazy(() => import("./pages/CreateBarcode"));
const MyCodes = lazy(() => import("./pages/MyCodes"));
const CodeDetails = lazy(() => import("./pages/CodeDetails"));
const Profile = lazy(() => import("./pages/Profile"));
const Settings = lazy(() => import("./pages/Settings"));
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"));
const AdminUsers = lazy(() => import("./pages/admin/AdminUsers"));
const AdminCodes = lazy(() => import("./pages/admin/AdminCodes"));

export default function App() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* Public routes */}
        <Route path={ROUTES.HOME} element={<Home />} />
        <Route path={ROUTES.SIGN_IN} element={<SignIn />} />
        <Route path={ROUTES.SIGN_UP} element={<SignUp />} />
        <Route path={ROUTES.FORGOT_PASSWORD} element={<ForgetPassword />} />

        {/* Authenticated-but-not-necessarily-verified route */}
        <Route element={<ProtectedRoute />}>
          <Route path={ROUTES.VERIFY_EMAIL} element={<VerifyEmail />} />
        </Route>

        {/* Protected dashboard routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<DashboardLayout />}>
            <Route path={ROUTES.DASHBOARD} element={<Dashboard />} />
            <Route path={ROUTES.CREATE_QR} element={<CreateQR />} />
            <Route path={ROUTES.CREATE_BARCODE} element={<CreateBarcode />} />
            <Route path={ROUTES.MY_CODES} element={<MyCodes />} />
            <Route path={ROUTES.CODE_DETAILS} element={<CodeDetails />} />
            <Route path={ROUTES.PROFILE} element={<Profile />} />
            <Route path={ROUTES.SETTINGS} element={<Settings />} />

            {/* Admin routes, nested so they share the dashboard chrome */}
            <Route element={<AdminRoute />}>
              <Route path={ROUTES.ADMIN} element={<AdminDashboard />} />
              <Route path={ROUTES.ADMIN_USERS} element={<AdminUsers />} />
              <Route path={ROUTES.ADMIN_CODES} element={<AdminCodes />} />
            </Route>
          </Route>
        </Route>

        {/* Fallback */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
