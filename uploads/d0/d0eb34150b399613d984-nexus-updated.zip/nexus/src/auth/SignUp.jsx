import React, { useState } from "react";
import Stack from "@mui/material/Stack";
import TextField from "@mui/material/TextField";
import Link from "@mui/material/Link";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import Button from "@mui/material/Button";
import GoogleIcon from "@mui/icons-material/Google";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import AuthLayout from "./AuthLayout";
import LoadingButton from "../components/LoadingButton";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { ROUTES } from "../constants/routes";
import { validateSignUpForm } from "../utils/validators";
import { getFriendlyAuthErrorMessage, logDevError } from "../utils/errorUtils";

export default function SignUp() {
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const { signUp, signInWithGoogle } = useAuth();
  const { showError, showSuccess } = useSnackbar();
  const navigate = useNavigate();

  const setField = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateSignUpForm(form);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setLoading(true);
    try {
      await signUp({ name: form.name.trim(), email: form.email.trim(), password: form.password });
      showSuccess("Account created. Check your email to verify your address.");
      navigate(ROUTES.VERIFY_EMAIL, { replace: true });
    } catch (error) {
      logDevError("SignUp.handleSubmit", error);
      showError(getFriendlyAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    try {
      await signInWithGoogle();
      showSuccess("Welcome to Nexus!");
      navigate(ROUTES.DASHBOARD, { replace: true });
    } catch (error) {
      logDevError("SignUp.handleGoogle", error);
      showError(getFriendlyAuthErrorMessage(error));
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <AuthLayout title="Create your account" subtitle="Start generating QR codes and barcodes for free">
      <Box component="form" onSubmit={handleSubmit} noValidate>
        <Stack spacing={2.5}>
          <TextField
            label="Full name"
            value={form.name}
            onChange={(e) => setField("name", e.target.value)}
            error={Boolean(errors.name)}
            helperText={errors.name}
            autoComplete="name"
            required
            fullWidth
          />
          <TextField
            label="Email"
            type="email"
            value={form.email}
            onChange={(e) => setField("email", e.target.value)}
            error={Boolean(errors.email)}
            helperText={errors.email}
            autoComplete="email"
            required
            fullWidth
          />
          <TextField
            label="Password"
            type="password"
            value={form.password}
            onChange={(e) => setField("password", e.target.value)}
            error={Boolean(errors.password)}
            helperText={errors.password || "At least 8 characters."}
            autoComplete="new-password"
            required
            fullWidth
          />
          <TextField
            label="Confirm password"
            type="password"
            value={form.confirmPassword}
            onChange={(e) => setField("confirmPassword", e.target.value)}
            error={Boolean(errors.confirmPassword)}
            helperText={errors.confirmPassword}
            autoComplete="new-password"
            required
            fullWidth
          />
          <LoadingButton type="submit" variant="contained" size="large" loading={loading} fullWidth>
            Create Account
          </LoadingButton>
          <Divider>or</Divider>
          <Button
            variant="outlined"
            size="large"
            startIcon={<GoogleIcon />}
            onClick={handleGoogle}
            disabled={googleLoading}
            fullWidth
          >
            Continue with Google
          </Button>
          <Box sx={{ textAlign: "center", fontSize: "0.9rem" }}>
            Already have an account?{" "}
            <Link component={RouterLink} to={ROUTES.SIGN_IN}>
              Sign in
            </Link>
          </Box>
        </Stack>
      </Box>
    </AuthLayout>
  );
}
