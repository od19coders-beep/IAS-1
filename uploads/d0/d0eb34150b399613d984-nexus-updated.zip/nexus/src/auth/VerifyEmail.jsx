import React, { useCallback, useEffect, useState } from "react";
import Stack from "@mui/material/Stack";
import Alert from "@mui/material/Alert";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import AuthLayout from "./AuthLayout";
import LoadingButton from "../components/LoadingButton";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { ROUTES } from "../constants/routes";
import { APP_CONFIG } from "../constants/appConfig";
import { refreshEmailVerificationStatus } from "../services/authService";
import { logDevError } from "../utils/errorUtils";

export default function VerifyEmail() {
  const { user, resendVerificationEmail, refreshUserProfile } = useAuth();
  const { showSuccess, showError } = useSnackbar();
  const navigate = useNavigate();
  const [cooldown, setCooldown] = useState(0);
  const [checking, setChecking] = useState(false);
  const [resending, setResending] = useState(false);

  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const timer = setInterval(() => setCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleResend = useCallback(async () => {
    setResending(true);
    try {
      await resendVerificationEmail();
      showSuccess("Verification email sent.");
      setCooldown(APP_CONFIG.resendVerificationCooldownSeconds);
    } catch (error) {
      logDevError("VerifyEmail.handleResend", error);
      showError("Could not send verification email. Please try again shortly.");
    } finally {
      setResending(false);
    }
  }, [resendVerificationEmail, showError, showSuccess]);

  const handleCheckStatus = useCallback(async () => {
    setChecking(true);
    try {
      const verified = await refreshEmailVerificationStatus();
      if (verified) {
        await refreshUserProfile();
        showSuccess("Email verified!");
        navigate(ROUTES.DASHBOARD, { replace: true });
      } else {
        showError("Not verified yet. Check your inbox for the link.");
      }
    } catch (error) {
      logDevError("VerifyEmail.handleCheckStatus", error);
      showError("Could not check verification status.");
    } finally {
      setChecking(false);
    }
  }, [navigate, refreshUserProfile, showError, showSuccess]);

  return (
    <AuthLayout title="Verify your email" subtitle={user?.email}>
      <Stack spacing={2.5}>
        <Alert severity="info">
          We sent a verification link to your email address. Click it, then
          come back and confirm below.
        </Alert>
        <LoadingButton
          variant="contained"
          size="large"
          onClick={handleCheckStatus}
          loading={checking}
          fullWidth
        >
          I've Verified — Refresh Status
        </LoadingButton>
        <LoadingButton
          variant="outlined"
          size="large"
          onClick={handleResend}
          loading={resending}
          disabled={cooldown > 0}
          fullWidth
        >
          {cooldown > 0 ? `Resend available in ${cooldown}s` : "Resend Verification Email"}
        </LoadingButton>
        <Box sx={{ textAlign: "center", fontSize: "0.9rem" }}>
          <Link component={RouterLink} to={ROUTES.SIGN_IN}>
            Back to Sign In
          </Link>
        </Box>
      </Stack>
    </AuthLayout>
  );
}
