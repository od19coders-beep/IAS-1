import React, { useState } from "react";
import Stack from "@mui/material/Stack";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import Link from "@mui/material/Link";
import Divider from "@mui/material/Divider";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import GoogleIcon from "@mui/icons-material/Google";
import { Link as RouterLink, useLocation, useNavigate } from "react-router-dom";
import AuthLayout from "./AuthLayout";
import LoadingButton from "../components/LoadingButton";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { ROUTES } from "../constants/routes";
import { validateSignInForm } from "../utils/validators";
import { getFriendlyAuthErrorMessage, logDevError } from "../utils/errorUtils";

export default function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const { signIn, signInWithGoogle, isAdmin } = useAuth();
  const { showError, showSuccess } = useSnackbar();
  const navigate = useNavigate();
  const location = useLocation();
  const redirectTo = location.state?.from?.pathname;

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateSignInForm({ email, password });
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setLoading(true);
    try {
      await signIn(email.trim(), password);
      showSuccess("Welcome back!");
      navigate(redirectTo || ROUTES.DASHBOARD, { replace: true });
    } catch (error) {
      logDevError("SignIn.handleSubmit", error);
      showError(getFriendlyAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    try {
      await signInWithGoogle();
      showSuccess("Welcome!");
      navigate(redirectTo || ROUTES.DASHBOARD, { replace: true });
    } catch (error) {
      logDevError("SignIn.handleGoogle", error);
      showError(getFriendlyAuthErrorMessage(error));
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <AuthLayout title="Sign in to Nexus" subtitle="Access your QR codes and barcodes">
      <Box component="form" onSubmit={handleSubmit} noValidate>
        <Stack spacing={2.5}>
          <TextField
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            error={Boolean(errors.email)}
            helperText={errors.email}
            autoComplete="email"
            required
            fullWidth
          />
          <TextField
            label="Password"
            type={showPassword ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            error={Boolean(errors.password)}
            helperText={errors.password}
            autoComplete="current-password"
            required
            fullWidth
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    onClick={() => setShowPassword((v) => !v)}
                    edge="end"
                  >
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <Box sx={{ textAlign: "right" }}>
            <Link component={RouterLink} to={ROUTES.FORGOT_PASSWORD} variant="body2">
              Forgot password?
            </Link>
          </Box>
          <LoadingButton type="submit" variant="contained" size="large" loading={loading} fullWidth>
            Sign In
          </LoadingButton>
          <Divider>or</Divider>
          <Button
            variant="outlined"
            size="large"
            startIcon={<GoogleIcon />}
            onClick={handleGoogle}
            disabled={googleLoading}
            fullWidth
          >
            Continue with Google
          </Button>
          <Box sx={{ textAlign: "center", fontSize: "0.9rem" }}>
            Don&apos;t have an account?{" "}
            <Link component={RouterLink} to={ROUTES.SIGN_UP}>
              Create one
            </Link>
          </Box>
        </Stack>
      </Box>
    </AuthLayout>
  );
}
