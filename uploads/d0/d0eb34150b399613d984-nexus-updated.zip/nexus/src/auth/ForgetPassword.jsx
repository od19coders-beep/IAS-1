import React, { useState } from "react";
import Stack from "@mui/material/Stack";
import TextField from "@mui/material/TextField";
import Link from "@mui/material/Link";
import Box from "@mui/material/Box";
import Alert from "@mui/material/Alert";
import { Link as RouterLink } from "react-router-dom";
import AuthLayout from "./AuthLayout";
import LoadingButton from "../components/LoadingButton";
import { useAuth } from "../hooks/useAuth";
import { ROUTES } from "../constants/routes";
import { isValidEmail } from "../utils/validators";
import { logDevError } from "../utils/errorUtils";

export default function ForgetPassword() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const { sendPasswordReset } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isValidEmail(email)) {
      setError("Enter a valid email address.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      await sendPasswordReset(email.trim());
    } catch (err) {
      // Intentionally do not reveal whether the account exists — Firebase
      // itself does not distinguish this in the reset flow either.
      logDevError("ForgetPassword.handleSubmit", err);
    } finally {
      setLoading(false);
      setSent(true);
    }
  };

  return (
    <AuthLayout title="Reset your password" subtitle="We'll email you a reset link">
      {sent ? (
        <Stack spacing={2}>
          <Alert severity="success">
            If an account exists for that email, a password reset link is on its way.
          </Alert>
          <Link component={RouterLink} to={ROUTES.SIGN_IN}>
            Back to Sign In
          </Link>
        </Stack>
      ) : (
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <Stack spacing={2.5}>
            <TextField
              label="Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              error={Boolean(error)}
              helperText={error}
              autoComplete="email"
              required
              fullWidth
            />
            <LoadingButton type="submit" variant="contained" size="large" loading={loading} fullWidth>
              Send Reset Link
            </LoadingButton>
            <Box sx={{ textAlign: "center", fontSize: "0.9rem" }}>
              <Link component={RouterLink} to={ROUTES.SIGN_IN}>
                Back to Sign In
              </Link>
            </Box>
          </Stack>
        </Box>
      )}
    </AuthLayout>
  );
}
