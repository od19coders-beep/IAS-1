import React from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Container from "@mui/material/Container";
import Logo from "../components/Logo";
import ColorModeToggle from "../components/ColorModeToggle";

export default function AuthLayout({ title, subtitle, children }) {
  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        py: 6,
        px: 2,
      }}
    >
      <Box sx={{ position: "fixed", top: 16, right: 16 }}>
        <ColorModeToggle />
      </Box>
      <Container maxWidth="xs">
        <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
          <Logo size="large" />
        </Box>
        <Paper sx={{ p: { xs: 3, sm: 4 } }}>
          <Box sx={{ mb: 3 }}>
            <Box component="h1" sx={{ fontSize: "1.4rem", fontWeight: 700, m: 0 }}>
              {title}
            </Box>
            {subtitle && (
              <Box sx={{ color: "text.secondary", mt: 0.5, fontSize: "0.95rem" }}>
                {subtitle}
              </Box>
            )}
          </Box>
          {children}
        </Paper>
      </Container>
    </Box>
  );
}
