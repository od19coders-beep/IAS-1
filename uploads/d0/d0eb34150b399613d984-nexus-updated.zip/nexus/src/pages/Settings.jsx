import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import Chip from "@mui/material/Chip";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Divider from "@mui/material/Divider";
import Button from "@mui/material/Button";
import Alert from "@mui/material/Alert";
import LightModeIcon from "@mui/icons-material/LightModeRounded";
import DarkModeIcon from "@mui/icons-material/DarkModeRounded";
import SettingsBrightnessIcon from "@mui/icons-material/SettingsBrightnessRounded";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { useColorMode } from "../context/ColorModeContext";
import { updateOwnProfile } from "../services/userService";
import { isGithubStorageConfigured } from "../services/uploadService";
import { clearLocalData, estimateLocalUsage } from "../lib/localDb";
import { formatBytes } from "../utils/fileUtils";
import { ROUTES } from "../constants/routes";
import { logDevError } from "../utils/errorUtils";

export default function Settings() {
  const { user, userProfile, refreshUserProfile, signOut } = useAuth();
  const { showSuccess, showError } = useSnackbar();
  const { preference, setColorMode } = useColorMode();
  const navigate = useNavigate();
  const [usage, setUsage] = useState(null);
  const [clearing, setClearing] = useState(false);

  useEffect(() => {
    estimateLocalUsage().then(setUsage);
  }, []);

  const handleThemeChange = async (_e, value) => {
    if (!value) return;
    // Applies instantly and is stored in IndexedDB; the profile copy is best-effort.
    setColorMode(value);
    try {
      await updateOwnProfile(user.uid, { preferences: { ...userProfile?.preferences, theme: value } });
      await refreshUserProfile();
    } catch (error) {
      logDevError("Settings.handleThemeChange", error);
    }
  };

  const handleClearLocal = async () => {
    setClearing(true);
    try {
      await clearLocalData();
      setUsage(await estimateLocalUsage());
      showSuccess("Local cache cleared.");
    } catch (error) {
      logDevError("Settings.clearLocal", error);
      showError("Could not clear the local cache.");
    } finally {
      setClearing(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate(ROUTES.SIGN_IN);
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Settings
      </Typography>

      <Paper sx={{ p: 3, maxWidth: 520 }}>
        <Stack spacing={3}>
          <Box>
            <Typography variant="subtitle2" gutterBottom>
              Appearance
            </Typography>
            <ToggleButtonGroup value={preference} exclusive onChange={handleThemeChange} size="small" aria-label="Color mode">
              <ToggleButton value="light" aria-label="Light mode">
                <LightModeIcon fontSize="small" sx={{ mr: 0.75 }} /> Light
              </ToggleButton>
              <ToggleButton value="dark" aria-label="Dark mode">
                <DarkModeIcon fontSize="small" sx={{ mr: 0.75 }} /> Dark
              </ToggleButton>
              <ToggleButton value="system" aria-label="Match system">
                <SettingsBrightnessIcon fontSize="small" sx={{ mr: 0.75 }} /> System
              </ToggleButton>
            </ToggleButtonGroup>
          </Box>

          <Divider />

          <Box>
            <Typography variant="subtitle2" gutterBottom>
              On this device
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
              Your library, unsaved drafts and file history are cached in this browser so Nexus opens
              instantly and works offline. {usage !== null && `Using about ${formatBytes(usage)}.`}
            </Typography>
            <Button variant="outlined" size="small" onClick={handleClearLocal} disabled={clearing}>
              Clear local cache
            </Button>
          </Box>

          <Divider />

          <Box>
            <Typography variant="subtitle2" gutterBottom>
              File, image & video QR codes
            </Typography>
            {isGithubStorageConfigured() ? (
              <Chip label="Ready" color="success" size="small" />
            ) : (
              <Chip label="Not configured" color="warning" size="small" />
            )}
          </Box>

          <Divider />

          <Box>
            <Typography variant="subtitle2" gutterBottom>
              Email verification
            </Typography>
            {user?.emailVerified ? (
              <Chip label="Verified" color="success" size="small" />
            ) : (
              <Stack spacing={1} alignItems="flex-start">
                <Chip label="Not verified" color="warning" size="small" />
                <Button size="small" onClick={() => navigate(ROUTES.VERIFY_EMAIL)}>
                  Verify now
                </Button>
              </Stack>
            )}
          </Box>

          <Divider />

          <Box>
            <Button variant="outlined" color="inherit" onClick={handleSignOut}>
              Sign Out
            </Button>
          </Box>

          <Divider />

          <Box>
            <Typography variant="subtitle2" gutterBottom color="error">
              Delete account
            </Typography>
            <Alert severity="info">
              Account deletion isn't available in this version — it requires a
              secure, documented backend workflow to remove associated data
              safely. Contact support if you'd like your account removed.
            </Alert>
          </Box>
        </Stack>
      </Paper>
    </Box>
  );
}
