import React from "react";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import ViewWeekOutlinedIcon from "@mui/icons-material/ViewWeekOutlined";
import DownloadIcon from "@mui/icons-material/Download";
import TuneIcon from "@mui/icons-material/Tune";
import BoltIcon from "@mui/icons-material/Bolt";
import UploadFileIcon from "@mui/icons-material/UploadFileRounded";
import AddPhotoIcon from "@mui/icons-material/AddPhotoAlternateRounded";
import DarkModeIcon from "@mui/icons-material/DarkModeRounded";
import FolderIcon from "@mui/icons-material/FolderOutlined";
import AppBarComponent from "../components/AppBar";
import HeroSection from "../components/HeroSection";
import Footer from "../components/Footer";

const FEATURES = [
  { icon: <QrCode2Icon />, title: "14 QR code types", description: "URLs, text, contacts, Wi-Fi, WhatsApp, location, calendar events, UPI payments and more." },
  { icon: <UploadFileIcon />, title: "Files, images & videos", description: "Pick a file and get a scannable QR code for it — large files work too." },
  { icon: <AddPhotoIcon />, title: "Your logo in the center", description: "Place a logo in the middle of any QR code without losing scannability." },
  { icon: <ViewWeekOutlinedIcon />, title: "14 barcode formats", description: "Code 128, EAN, UPC, ITF-14, Codabar, plus Data Matrix, PDF417 and Aztec." },
  { icon: <DownloadIcon />, title: "High-quality downloads", description: "Export crisp PNG or SVG, ready for print or web." },
  { icon: <TuneIcon />, title: "Easy customization", description: "Adjust colors, size, margin and error correction to fit your brand." },
  { icon: <FolderIcon />, title: "Personal library", description: "Save, search and revisit every code — available instantly, even offline." },
  { icon: <DarkModeIcon />, title: "Light & dark mode", description: "A soft clay interface that follows your system or your choice." },
  { icon: <BoltIcon />, title: "Fast & private", description: "Codes are generated instantly in your browser as you type." },
];

export default function Home() {
  return (
    <Box>
      <AppBarComponent />
      <HeroSection />

      <Box id="features" sx={{ py: { xs: 8, md: 10 } }}>
        <Container maxWidth="lg">
          <Typography variant="h4" align="center" sx={{ mb: 1 }}>
            Everything you need to generate codes
          </Typography>
          <Typography align="center" color="text.secondary" sx={{ mb: 6 }}>
            A focused, professional toolset for QR codes and barcodes.
          </Typography>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(3, 1fr)" },
              gap: 4,
            }}
          >
            {FEATURES.map((feature) => (
              <Card key={feature.title}>
                <CardContent>
                  <Box
                    sx={(theme) => ({
                      width: 52,
                      height: 52,
                      borderRadius: "18px",
                      backgroundColor: theme.tokens?.inset,
                      boxShadow: theme.clay?.pressed,
                      color: "primary.main",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      mb: 2,
                    })}
                    aria-hidden="true"
                  >
                    {feature.icon}
                  </Box>
                  <Typography variant="h6" gutterBottom>
                    {feature.title}
                  </Typography>
                  <Typography color="text.secondary">{feature.description}</Typography>
                </CardContent>
              </Card>
            ))}
          </Box>
        </Container>
      </Box>

      <Box id="about" sx={{ py: { xs: 8, md: 10 } }}>
        <Container maxWidth="md">
          <Typography variant="h4" align="center" sx={{ mb: 2 }}>
            About Nexus
          </Typography>
          <Typography align="center" color="text.secondary">
            Nexus is a simple platform to create, customize, and manage QR
            codes and barcodes. Sign up, generate a code in seconds, and keep
            a personal library of everything you've made — all from one
            dashboard.
          </Typography>
        </Container>
      </Box>

      <Footer />
    </Box>
  );
}
