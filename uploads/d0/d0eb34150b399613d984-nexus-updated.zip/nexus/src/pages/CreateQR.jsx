import React, { useEffect, useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import TextField from "@mui/material/TextField";
import Stack from "@mui/material/Stack";
import Alert from "@mui/material/Alert";
import Button from "@mui/material/Button";
import { useSearchParams } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { useMediaUpload } from "../hooks/useMediaUpload";
import { useDraft } from "../hooks/useDraft";
import QRCodeForm from "../components/QRCodeForm";
import CodePreview from "../components/CodePreview";
import DownloadMenu from "../components/DownloadMenu";
import LoadingButton from "../components/LoadingButton";
import PageLoader from "../components/PageLoader";
import { QR_PAYLOAD_TYPES, isMediaPayloadType } from "../constants/codeTypes";
import { validateQrPayload, buildQrPayloadString } from "../utils/validators";
import { generateQrDataUrl, generateQrSvgString, isLowContrast } from "../utils/qrGenerator";
import { downloadDataUrl, downloadSvgString, buildFilename } from "../utils/downloadUtils";
import { saveCode } from "../services/codeService";
import { isGithubStorageConfigured } from "../services/uploadService";
import { logDevError } from "../utils/errorUtils";

const DEFAULT_SETTINGS = {
  foregroundColor: "#111827",
  backgroundColor: "#FFFFFF",
  errorCorrectionLevel: "M",
  width: 512,
  margin: 4,
  logo: null,
  logoSize: 0.22,
  logoBackdrop: true,
};

const DRAFT_KEY = "create-qr";

export default function CreateQR() {
  const { user } = useAuth();
  const { showSuccess, showError } = useSnackbar();
  const [searchParams] = useSearchParams();
  const requestedType = searchParams.get("type");

  const [payloadType, setPayloadType] = useState(QR_PAYLOAD_TYPES.URL);
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const isMedia = isMediaPayloadType(payloadType);
  const media = useMediaUpload(payloadType);
  const { ready: draftReady, draft, save: saveDraft, clear: clearDraft } = useDraft(DRAFT_KEY);

  // Restore the last unsaved form from IndexedDB (a deep link like ?type=file wins).
  useEffect(() => {
    if (!draftReady || hydrated) return;
    if (draft) {
      setPayloadType(draft.payloadType || QR_PAYLOAD_TYPES.URL);
      setValues(draft.values || {});
      setSettings({ ...DEFAULT_SETTINGS, ...(draft.settings || {}) });
      setName(draft.name || "");
      if (draft.media?.url) media.restore(draft.media);
    }
    if (requestedType && Object.values(QR_PAYLOAD_TYPES).includes(requestedType) && requestedType !== draft?.payloadType) {
      setPayloadType(requestedType);
      setValues({});
      media.clear();
    }
    setHydrated(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draftReady]);

  // Auto-save the draft (never the Wi-Fi password).
  useEffect(() => {
    if (!hydrated) return;
    const { password, ...safeValues } = values;
    saveDraft({
      payloadType,
      values: safeValues,
      settings,
      name,
      media: media.status === "ready" ? media.record : null,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, payloadType, values, settings, name, media.status, media.record]);

  const payloadErrors = useMemo(
    () => (isMedia ? {} : validateQrPayload(payloadType, values)),
    [isMedia, payloadType, values]
  );

  const payloadString = useMemo(() => {
    if (isMedia) return media.url || "";
    if (Object.keys(payloadErrors).length > 0) return "";
    try {
      return buildQrPayloadString(payloadType, values);
    } catch {
      return "";
    }
  }, [isMedia, media.url, payloadType, values, payloadErrors]);

  const lowContrast = isLowContrast(settings.foregroundColor, settings.backgroundColor);
  const uploadsUnavailable = isMedia && !isGithubStorageConfigured();

  const handlePayloadTypeChange = (type) => {
    if (type === payloadType) return;
    setPayloadType(type);
    setValues({});
    setErrors({});
    media.clear();
  };

  const ensureValidForAction = () => {
    if (isMedia) {
      if (!payloadString) {
        setErrors({ media: "Choose a file to generate the QR code." });
        return false;
      }
      return true;
    }
    const validationErrors = validateQrPayload(payloadType, values);
    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  };

  const handleDownloadPng = async () => {
    if (!ensureValidForAction()) throw new Error("Please fix the highlighted fields first.");
    const dataUrl = await generateQrDataUrl(payloadString, settings);
    downloadDataUrl(dataUrl, buildFilename(name || "nexus-qr", "png"));
  };

  const handleDownloadSvg = async () => {
    if (!ensureValidForAction()) throw new Error("Please fix the highlighted fields first.");
    const svg = await generateQrSvgString(payloadString, settings);
    downloadSvgString(svg, buildFilename(name || "nexus-qr", "svg"));
  };

  const handleSave = async () => {
    if (!ensureValidForAction()) return;
    if (!name.trim()) {
      showError("Please give this code a name before saving.");
      return;
    }
    setSaving(true);
    try {
      await saveCode(user.uid, {
        name: name.trim(),
        codeType: "qr",
        format: "QR",
        payloadType,
        payload: payloadString,
        settings,
        media: isMedia && media.record
          ? { name: media.record.name, size: media.record.size, type: media.record.type }
          : null,
      });
      showSuccess("Saved to My Codes.");
    } catch (error) {
      logDevError("CreateQR.handleSave", error);
      showError("Could not save this code. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    await clearDraft();
    setPayloadType(QR_PAYLOAD_TYPES.URL);
    setValues({});
    setErrors({});
    setSettings(DEFAULT_SETTINGS);
    setName("");
    media.clear();
  };

  if (!hydrated) return <PageLoader label="Preparing the generator…" variant="form" />;

  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" sx={{ mb: 3 }} spacing={2}>
        <Box>
          <Typography variant="h5" gutterBottom>
            Create a QR Code
          </Typography>
          <Typography color="text.secondary">
            Pick what the code contains — a link, contact, payment, or even a file, image or video.
          </Typography>
        </Box>
        <Button size="small" color="inherit" onClick={handleReset}>
          Start over
        </Button>
      </Stack>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", md: "1.1fr 0.9fr" },
          gap: 3,
          alignItems: "start",
        }}
      >
        <Paper sx={{ p: { xs: 2.5, sm: 3.5 } }}>
          <QRCodeForm
            payloadType={payloadType}
            onPayloadTypeChange={handlePayloadTypeChange}
            values={values}
            onValuesChange={setValues}
            errors={errors}
            settings={settings}
            onSettingsChange={setSettings}
            media={media}
          />
        </Paper>

        <Stack spacing={2.5} sx={{ position: { md: "sticky" }, top: { md: 88 } }}>
          <CodePreview
            codeType="qr"
            payload={payloadString}
            settings={settings}
            pending={isMedia && media.working}
            emptyMessage={isMedia ? "Choose a file and your QR code will appear here." : undefined}
          />
          {uploadsUnavailable && (
            <Alert severity="info">
              File, image and video QR codes need file conversion to be set up. See the README
              (“File-to-QR storage”).
            </Alert>
          )}
          {lowContrast && (
            <Alert severity="warning">
              Foreground and background colors are very similar — this code may not scan reliably.
            </Alert>
          )}
          <TextField
            label="Code name"
            placeholder="e.g. My Website QR"
            value={name}
            onChange={(e) => setName(e.target.value)}
            fullWidth
          />
          <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
            <DownloadMenu
              onDownloadPng={handleDownloadPng}
              onDownloadSvg={handleDownloadSvg}
              disabled={!payloadString}
            />
            <LoadingButton
              variant="outlined"
              loading={saving}
              disabled={!payloadString}
              onClick={handleSave}
              fullWidth
            >
              Save to My Codes
            </LoadingButton>
          </Stack>
        </Stack>
      </Box>
    </Box>
  );
}
