import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import IconButton from "@mui/material/IconButton";
import Divider from "@mui/material/Divider";
import Alert from "@mui/material/Alert";
import Button from "@mui/material/Button";
import OpenInNewIcon from "@mui/icons-material/OpenInNewRounded";
import StarIcon from "@mui/icons-material/Star";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { getCode, getCodeFromCache, deleteCode, toggleFavorite, recordDownload } from "../services/codeService";
import CodePreview from "../components/CodePreview";
import DownloadMenu from "../components/DownloadMenu";
import ConfirmDialog from "../components/ConfirmDialog";
import PageLoader from "../components/PageLoader";
import ErrorState from "../components/ErrorState";
import { formatDateTime } from "../utils/dateUtils";
import { formatBytes } from "../utils/fileUtils";
import { QR_PAYLOAD_LABELS, isMediaPayloadType } from "../constants/codeTypes";
import { generateQrDataUrl, generateQrSvgString } from "../utils/qrGenerator";
import { generateBarcodePngDataUrl, generateBarcodeSvgString } from "../utils/barcodeGenerator";
import { downloadDataUrl, downloadSvgString, buildFilename } from "../utils/downloadUtils";
import { ROUTES } from "../constants/routes";
import { logDevError } from "../utils/errorUtils";

export default function CodeDetails() {
  const { codeId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useSnackbar();

  const [code, setCode] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setError(null);

    // Paint instantly from IndexedDB if we have it, then refresh from Firestore.
    let hadCache = false;
    getCodeFromCache(user.uid, codeId).then((cached) => {
      if (cancelled || !cached) return;
      hadCache = true;
      setCode((current) => current || cached);
      setLoading(false);
    });
    setLoading(true);

    getCode(user.uid, codeId)
      .then((data) => {
        if (!cancelled) setCode(data);
      })
      .catch((err) => {
        logDevError("CodeDetails.load", err);
        if (!cancelled && !hadCache) setError(err);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user, codeId]);

  const handleToggleFavorite = async () => {
    try {
      await toggleFavorite(user.uid, codeId, !code.isFavorite);
      setCode((prev) => ({ ...prev, isFavorite: !prev.isFavorite }));
    } catch (err) {
      showError("Could not update favorite status.");
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await deleteCode(user.uid, codeId);
      showSuccess("Code deleted.");
      navigate(ROUTES.MY_CODES, { replace: true });
    } catch (err) {
      showError("Could not delete this code.");
    } finally {
      setDeleting(false);
    }
  };

  const handleDownloadPng = async () => {
    let dataUrl;
    if (code.codeType === "barcode") {
      dataUrl = await generateBarcodePngDataUrl(code.payload, code.format, code.barcodeSettings || {});
    } else {
      dataUrl = await generateQrDataUrl(code.payload, code.settings || {});
    }
    downloadDataUrl(dataUrl, buildFilename(code.name, "png"));
    recordDownload(user.uid, codeId);
  };

  const handleDownloadSvg = async () => {
    let svg;
    if (code.codeType === "barcode") {
      svg = await generateBarcodeSvgString(code.payload, code.format, code.barcodeSettings || {});
    } else {
      svg = await generateQrSvgString(code.payload, code.settings || {});
    }
    downloadSvgString(svg, buildFilename(code.name, "svg"));
    recordDownload(user.uid, codeId);
  };

  if (loading) return <PageLoader label="Loading code…" variant="detail" />;
  if (error) return <ErrorState message="Could not load this code." />;
  if (!code) {
    return (
      <Alert severity="warning">
        This code could not be found. It may have been deleted.
      </Alert>
    );
  }

  return (
    <Box>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <Typography variant="h5">{code.name}</Typography>
        <Stack direction="row" spacing={1}>
          <IconButton
            aria-label={code.isFavorite ? "Remove from favorites" : "Add to favorites"}
            onClick={handleToggleFavorite}
          >
            {code.isFavorite ? <StarIcon color="warning" /> : <StarBorderIcon />}
          </IconButton>
          <IconButton aria-label="Delete this code" onClick={() => setConfirmOpen(true)}>
            <DeleteOutlineIcon />
          </IconButton>
        </Stack>
      </Stack>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" },
          gap: 3,
        }}
      >
        <CodePreview
          codeType={code.codeType}
          payload={code.payload}
          symbology={code.format}
          settings={code.codeType === "barcode" ? code.barcodeSettings || {} : code.settings || {}}
        />

        <Paper sx={{ p: 3 }}>
          <Stack spacing={2}>
            <Box>
              <Typography variant="body2" color="text.secondary">
                Type
              </Typography>
              <Chip
                size="small"
                label={
                  code.codeType === "barcode"
                    ? code.format
                    : `QR · ${QR_PAYLOAD_LABELS[code.payloadType] || "Code"}`
                }
                sx={{ mt: 0.5 }}
              />
            </Box>
            <Divider />
            {code.media && (
              <>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Source file
                  </Typography>
                  <Typography sx={{ wordBreak: "break-word" }}>
                    {code.media.name} · {formatBytes(code.media.size)}
                  </Typography>
                </Box>
                <Divider />
              </>
            )}
            <Box>
              <Typography variant="body2" color="text.secondary">
                {isMediaPayloadType(code.payloadType) ? "Link in QR code" : "Payload"}
              </Typography>
              <Typography sx={{ wordBreak: "break-word" }}>{code.payload}</Typography>
              {isMediaPayloadType(code.payloadType) && (
                <Button
                  size="small"
                  sx={{ mt: 1 }}
                  endIcon={<OpenInNewIcon />}
                  href={code.payload}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open file
                </Button>
              )}
            </Box>
            <Divider />
            <Box>
              <Typography variant="body2" color="text.secondary">
                Created
              </Typography>
              <Typography>{formatDateTime(code.createdAt)}</Typography>
            </Box>
            {code.downloadCount > 0 && (
              <>
                <Divider />
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Downloads
                  </Typography>
                  <Typography>{code.downloadCount}</Typography>
                </Box>
              </>
            )}
            <Divider />
            <DownloadMenu onDownloadPng={handleDownloadPng} onDownloadSvg={handleDownloadSvg} />
          </Stack>
        </Paper>
      </Box>

      <ConfirmDialog
        open={confirmOpen}
        title="Delete this code?"
        description={`"${code.name}" will be permanently deleted. This can't be undone.`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onClose={() => setConfirmOpen(false)}
      />
    </Box>
  );
}
