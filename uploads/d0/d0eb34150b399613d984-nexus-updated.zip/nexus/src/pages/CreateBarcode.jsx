import React, { useEffect, useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import TextField from "@mui/material/TextField";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import { useDraft } from "../hooks/useDraft";
import PageLoader from "../components/PageLoader";
import BarcodeForm from "../components/BarcodeForm";
import CodePreview from "../components/CodePreview";
import DownloadMenu from "../components/DownloadMenu";
import LoadingButton from "../components/LoadingButton";
import { validateBarcodeValue } from "../utils/validators";
import { generateBarcodePngDataUrl, generateBarcodeSvgString } from "../utils/barcodeGenerator";
import { downloadDataUrl, downloadSvgString, buildFilename } from "../utils/downloadUtils";
import { saveCode } from "../services/codeService";
import { logDevError } from "../utils/errorUtils";

const DEFAULT_SETTINGS = {
  displayValue: true,
  lineColor: "#111827",
  background: "#FFFFFF",
  width: 2,
  height: 100,
  fontSize: 16,
  margin: 10,
};

const DRAFT_KEY = "create-barcode";

export default function CreateBarcode() {
  const { user } = useAuth();
  const { showSuccess, showError } = useSnackbar();

  const [symbology, setSymbology] = useState("CODE128");
  const [value, setValue] = useState("");
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const { ready: draftReady, draft, save: saveDraft, clear: clearDraft } = useDraft(DRAFT_KEY);

  // Restore the last unsaved form from IndexedDB.
  useEffect(() => {
    if (!draftReady || hydrated) return;
    if (draft) {
      setSymbology(draft.symbology || "CODE128");
      setValue(draft.value || "");
      setSettings({ ...DEFAULT_SETTINGS, ...(draft.settings || {}) });
      setName(draft.name || "");
    }
    setHydrated(true);
  }, [draftReady, draft, hydrated]);

  useEffect(() => {
    if (hydrated) saveDraft({ symbology, value, settings, name });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, symbology, value, settings, name]);

  const handleReset = async () => {
    await clearDraft();
    setSymbology("CODE128");
    setValue("");
    setSettings(DEFAULT_SETTINGS);
    setName("");
  };

  const validationError = useMemo(() => validateBarcodeValue(symbology, value), [symbology, value]);
  const isValid = value.trim().length > 0 && !validationError;

  const handleDownloadPng = async () => {
    if (!isValid) throw new Error(validationError || "Enter a valid value first.");
    const dataUrl = await generateBarcodePngDataUrl(value, symbology, settings);
    downloadDataUrl(dataUrl, buildFilename(name || "nexus-barcode", "png"));
  };

  const handleDownloadSvg = async () => {
    if (!isValid) throw new Error(validationError || "Enter a valid value first.");
    const svg = await generateBarcodeSvgString(value, symbology, settings);
    downloadSvgString(svg, buildFilename(name || "nexus-barcode", "svg"));
  };

  const handleSave = async () => {
    if (!isValid) {
      showError(validationError || "Enter a valid value first.");
      return;
    }
    if (!name.trim()) {
      showError("Please give this code a name before saving.");
      return;
    }
    setSaving(true);
    try {
      await saveCode(user.uid, {
        name: name.trim(),
        codeType: "barcode",
        format: symbology,
        payload: value.trim(),
        barcodeSettings: settings,
      });
      showSuccess("Saved to My Codes.");
    } catch (error) {
      logDevError("CreateBarcode.handleSave", error);
      showError("Could not save this code. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (!hydrated) return <PageLoader label="Preparing the generator…" variant="form" />;

  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start" sx={{ mb: 3 }} spacing={2}>
        <Box>
          <Typography variant="h5" gutterBottom>
            Create a Barcode
          </Typography>
          <Typography color="text.secondary">
            14 formats — product, logistics and 2D codes. Enter a value, then customize and download.
          </Typography>
        </Box>
        <Button size="small" color="inherit" onClick={handleReset}>
          Start over
        </Button>
      </Stack>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" },
          gap: 3,
          alignItems: "start",
        }}
      >
        <Paper sx={{ p: { xs: 2.5, sm: 3.5 } }}>
          <BarcodeForm
            symbology={symbology}
            onSymbologyChange={(v) => {
              setSymbology(v);
              setValue("");
            }}
            value={value}
            onValueChange={setValue}
            error={value ? validationError : null}
            settings={settings}
            onSettingsChange={setSettings}
          />
        </Paper>

        <Stack spacing={2.5} sx={{ position: { md: "sticky" }, top: { md: 88 } }}>
          <CodePreview
            codeType="barcode"
            payload={isValid ? value.trim() : ""}
            symbology={symbology}
            settings={settings}
          />
          <TextField
            label="Code name"
            placeholder="e.g. My Product Barcode"
            value={name}
            onChange={(e) => setName(e.target.value)}
            fullWidth
          />
          <Stack direction={{ xs: "column", sm: "row" }} spacing={2}>
            <DownloadMenu
              onDownloadPng={handleDownloadPng}
              onDownloadSvg={handleDownloadSvg}
              disabled={!isValid}
            />
            <LoadingButton
              variant="outlined"
              loading={saving}
              disabled={!isValid}
              onClick={handleSave}
              fullWidth
            >
              Save to My Codes
            </LoadingButton>
          </Stack>
        </Stack>
      </Box>
    </Box>
  );
}
