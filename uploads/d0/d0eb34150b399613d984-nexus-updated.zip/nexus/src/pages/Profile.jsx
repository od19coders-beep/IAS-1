import React, { useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import TextField from "@mui/material/TextField";
import Stack from "@mui/material/Stack";
import Avatar from "@mui/material/Avatar";
import { useAuth } from "../hooks/useAuth";
import { useSnackbar } from "../context/SnackbarContext";
import LoadingButton from "../components/LoadingButton";
import { updateOwnProfile } from "../services/userService";
import { formatDate } from "../utils/dateUtils";
import { logDevError } from "../utils/errorUtils";

export default function Profile() {
  const { user, userProfile, refreshUserProfile } = useAuth();
  const { showSuccess, showError } = useSnackbar();
  const [displayName, setDisplayName] = useState(userProfile?.displayName || "");
  const [saving, setSaving] = useState(false);

  const initials = (displayName || "U")
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const handleSave = async (e) => {
    e.preventDefault();
    if (!displayName.trim()) {
      showError("Display name cannot be empty.");
      return;
    }
    setSaving(true);
    try {
      await updateOwnProfile(user.uid, { displayName: displayName.trim() });
      await refreshUserProfile();
      showSuccess("Profile updated.");
    } catch (error) {
      logDevError("Profile.handleSave", error);
      showError("Could not update your profile. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Profile
      </Typography>
      <Paper sx={{ p: 3, maxWidth: 480 }}>
        <Stack spacing={3}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Avatar sx={{ width: 56, height: 56, bgcolor: "primary.main" }}>{initials}</Avatar>
            <Box>
              <Typography variant="subtitle1">{userProfile?.displayName}</Typography>
              <Typography variant="body2" color="text.secondary">
                Member since {formatDate(userProfile?.createdAt)}
              </Typography>
            </Box>
          </Box>

          <Box component="form" onSubmit={handleSave}>
            <Stack spacing={2.5}>
              <TextField
                label="Display name"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                fullWidth
                required
              />
              <TextField
                label="Email"
                value={user?.email || ""}
                fullWidth
                disabled
                helperText="Email changes require a secure re-authentication flow and aren't available here yet."
              />
              <LoadingButton type="submit" variant="contained" loading={saving} sx={{ alignSelf: "flex-start" }}>
                Save Changes
              </LoadingButton>
            </Stack>
          </Box>
        </Stack>
      </Paper>
    </Box>
  );
}
