import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableBody from "@mui/material/TableBody";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import Paper from "@mui/material/Paper";
import Chip from "@mui/material/Chip";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";
import Alert from "@mui/material/Alert";
import { fetchUsersPage, setUserAccountStatus } from "../../services/adminService";
import PageLoader from "../../components/PageLoader";
import ErrorState from "../../components/ErrorState";
import ConfirmDialog from "../../components/ConfirmDialog";
import { useSnackbar } from "../../context/SnackbarContext";
import { useDebounce } from "../../hooks/useDebounce";
import { formatDate } from "../../utils/dateUtils";
import { logDevError } from "../../utils/errorUtils";

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [hasMore, setHasMore] = useState(false);
  const [cursor, setCursor] = useState(null);
  const [search, setSearch] = useState("");
  const [pendingStatusChange, setPendingStatusChange] = useState(null);
  const [updating, setUpdating] = useState(false);
  const debouncedSearch = useDebounce(search, 300);
  const { showSuccess, showError } = useSnackbar();

  const load = (reset = true) => {
    setLoading(true);
    setError(null);
    fetchUsersPage({ cursor: reset ? null : cursor })
      .then(({ items, lastDoc, hasMore: more }) => {
        setUsers((prev) => (reset ? items : [...prev, ...items]));
        setCursor(lastDoc);
        setHasMore(more);
      })
      .catch((err) => {
        logDevError("AdminUsers.load", err);
        setError(err);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => load(true), []); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = users.filter((u) => {
    if (!debouncedSearch.trim()) return true;
    const term = debouncedSearch.trim().toLowerCase();
    return (
      u.displayName?.toLowerCase().includes(term) || u.email?.toLowerCase().includes(term)
    );
  });

  const handleConfirmStatusChange = async () => {
    if (!pendingStatusChange) return;
    setUpdating(true);
    try {
      await setUserAccountStatus(pendingStatusChange.uid, pendingStatusChange.newStatus);
      setUsers((prev) =>
        prev.map((u) =>
          u.id === pendingStatusChange.uid ? { ...u, accountStatus: pendingStatusChange.newStatus } : u
        )
      );
      showSuccess("Account status updated.");
      setPendingStatusChange(null);
    } catch (err) {
      logDevError("AdminUsers.setStatus", err);
      showError(
        "Could not update account status. This requires the setUserAccountStatus Cloud Function to be deployed."
      );
    } finally {
      setUpdating(false);
    }
  };

  if (loading && users.length === 0) return <PageLoader label="Loading users…" variant="table" />;
  if (error) return <ErrorState message="Could not load users." onRetry={() => load(true)} />;

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        User Management
      </Typography>

      <Alert severity="info" sx={{ mb: 2 }}>
        Suspend/restore actions call a trusted Cloud Function
        (<code>setUserAccountStatus</code>) — deploy it from{" "}
        <code>/functions-example</code> for this to work in production.
      </Alert>

      <TextField
        placeholder="Search by name or email…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        size="small"
        sx={{ mb: 2, minWidth: 280 }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon fontSize="small" />
            </InputAdornment>
          ),
        }}
      />

      <TableContainer component={Paper}>
        <Table size="small" sx={{ minWidth: 560 }}>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Joined</TableCell>
              <TableCell align="right">Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filtered.map((u) => (
              <TableRow key={u.id}>
                <TableCell>{u.displayName}</TableCell>
                <TableCell>{u.email}</TableCell>
                <TableCell>
                  <Chip
                    size="small"
                    label={u.accountStatus}
                    color={u.accountStatus === "active" ? "success" : "warning"}
                  />
                </TableCell>
                <TableCell>{formatDate(u.createdAt)}</TableCell>
                <TableCell align="right">
                  <Button
                    size="small"
                    onClick={() =>
                      setPendingStatusChange({
                        uid: u.id,
                        name: u.displayName,
                        newStatus: u.accountStatus === "active" ? "suspended" : "active",
                      })
                    }
                  >
                    {u.accountStatus === "active" ? "Suspend" : "Restore"}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {hasMore && !search && (
        <Box sx={{ textAlign: "center", mt: 2 }}>
          <Button variant="outlined" onClick={() => load(false)} disabled={loading}>
            Load more
          </Button>
        </Box>
      )}

      <ConfirmDialog
        open={Boolean(pendingStatusChange)}
        title={`${pendingStatusChange?.newStatus === "suspended" ? "Suspend" : "Restore"} this account?`}
        description={`This will ${pendingStatusChange?.newStatus === "suspended" ? "suspend" : "restore"} ${pendingStatusChange?.name}'s account.`}
        confirmLabel={pendingStatusChange?.newStatus === "suspended" ? "Suspend" : "Restore"}
        confirmColor={pendingStatusChange?.newStatus === "suspended" ? "error" : "primary"}
        loading={updating}
        onConfirm={handleConfirmStatusChange}
        onClose={() => setPendingStatusChange(null)}
      />
    </Box>
  );
}
