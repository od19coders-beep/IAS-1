import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import PeopleIcon from "@mui/icons-material/PeopleOutline";
import PersonIcon from "@mui/icons-material/PersonOutline";
import FolderIcon from "@mui/icons-material/FolderOutlined";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import ViewWeekOutlinedIcon from "@mui/icons-material/ViewWeekOutlined";
import StatCard from "../../components/StatCard";
import PageLoader from "../../components/PageLoader";
import ErrorState from "../../components/ErrorState";
import { getPlatformStats } from "../../services/adminService";
import { logDevError } from "../../utils/errorUtils";

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = () => {
    setLoading(true);
    setError(null);
    getPlatformStats()
      .then(setStats)
      .catch((err) => {
        logDevError("AdminDashboard.load", err);
        setError(err);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  if (loading) return <PageLoader label="Loading platform stats…" variant="dashboard" />;
  if (error) return <ErrorState message="Could not load platform statistics." onRetry={load} />;

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Admin Dashboard
      </Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>
        Platform-level summary. Individual code payloads are never shown here.
      </Typography>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(5, 1fr)" },
          gap: 2,
        }}
      >
        <StatCard label="Total users" value={stats.totalUsers} icon={<PeopleIcon />} />
        <StatCard label="Active users" value={stats.activeUsers} icon={<PersonIcon />} />
        <StatCard label="Total saved codes" value={stats.totalCodes} icon={<FolderIcon />} />
        <StatCard label="QR codes" value={stats.qrCodes} icon={<QrCode2Icon />} />
        <StatCard label="Barcodes" value={stats.barcodes} icon={<ViewWeekOutlinedIcon />} />
      </Box>
    </Box>
  );
}
