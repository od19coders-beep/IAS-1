import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Alert from "@mui/material/Alert";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import ViewWeekOutlinedIcon from "@mui/icons-material/ViewWeekOutlined";
import FolderIcon from "@mui/icons-material/FolderOutlined";
import StatCard from "../../components/StatCard";
import PageLoader from "../../components/PageLoader";
import ErrorState from "../../components/ErrorState";
import { getPlatformStats } from "../../services/adminService";
import { logDevError } from "../../utils/errorUtils";

export default function AdminCodes() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = () => {
    setLoading(true);
    setError(null);
    getPlatformStats()
      .then(setStats)
      .catch((err) => {
        logDevError("AdminCodes.load", err);
        setError(err);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  if (loading) return <PageLoader label="Loading code statistics…" variant="dashboard" />;
  if (error) return <ErrorState message="Could not load code statistics." onRetry={load} />;

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Code Statistics
      </Typography>
      <Alert severity="info" sx={{ mb: 3 }}>
        Aggregate counts only. Individual users' payloads are private and are
        not shown here.
      </Alert>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "repeat(3, 1fr)" },
          gap: 2,
        }}
      >
        <StatCard label="Total saved codes" value={stats.totalCodes} icon={<FolderIcon />} />
        <StatCard label="QR codes" value={stats.qrCodes} icon={<QrCode2Icon />} />
        <StatCard label="Barcodes" value={stats.barcodes} icon={<ViewWeekOutlinedIcon />} />
      </Box>
    </Box>
  );
}
