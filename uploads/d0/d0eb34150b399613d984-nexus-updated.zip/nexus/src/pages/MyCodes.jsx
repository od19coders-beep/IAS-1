import React, { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import FolderIcon from "@mui/icons-material/FolderOutlined";
import { useAuth } from "../hooks/useAuth";
import { useCodes } from "../hooks/useCodes";
import { useDebounce } from "../hooks/useDebounce";
import { useSnackbar } from "../context/SnackbarContext";
import CodeCard from "../components/CodeCard";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { CodeGridSkeleton } from "../components/Skeletons";
import Alert from "@mui/material/Alert";
import ConfirmDialog from "../components/ConfirmDialog";
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../constants/routes";

export default function MyCodes() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useSnackbar();

  const [typeFilter, setTypeFilter] = useState("all");
  const [sortDirection, setSortDirection] = useState("desc");
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search, 300);
  const [pendingDelete, setPendingDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const { items, loading, error, hasMore, offline, loadMore, reload, remove, favorite } = useCodes(user?.uid, {
    codeType: typeFilter === "all" ? null : typeFilter,
    sortDirection,
  });

  const filtered = useMemo(() => {
    if (!debouncedSearch.trim()) return items;
    const term = debouncedSearch.trim().toLowerCase();
    return items.filter((item) => item.name?.toLowerCase().includes(term));
  }, [items, debouncedSearch]);

  const handleDelete = async () => {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await remove(pendingDelete.id);
      showSuccess("Code deleted.");
      setPendingDelete(null);
    } catch (err) {
      showError("Could not delete this code.");
    } finally {
      setDeleting(false);
    }
  };

  const handleFavorite = async (codeId, isFavorite) => {
    try {
      await favorite(codeId, isFavorite);
    } catch (err) {
      showError("Could not update favorite status.");
    }
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        My Codes
      </Typography>

      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={2}
        sx={{ mb: 3 }}
        alignItems={{ sm: "center" }}
      >
        <TextField
          placeholder="Search by name…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          size="small"
          hiddenLabel
          sx={{ minWidth: 240 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
        />
        <ToggleButtonGroup
          value={typeFilter}
          exclusive
          size="small"
          onChange={(_e, v) => v && setTypeFilter(v)}
          aria-label="Filter by code type"
        >
          <ToggleButton value="all">All</ToggleButton>
          <ToggleButton value="qr">QR</ToggleButton>
          <ToggleButton value="barcode">Barcode</ToggleButton>
        </ToggleButtonGroup>
        <ToggleButtonGroup
          value={sortDirection}
          exclusive
          size="small"
          onChange={(_e, v) => v && setSortDirection(v)}
          aria-label="Sort order"
        >
          <ToggleButton value="desc">Newest</ToggleButton>
          <ToggleButton value="asc">Oldest</ToggleButton>
        </ToggleButtonGroup>
      </Stack>

      {offline && (
        <Alert severity="info" sx={{ mb: 2 }}>
          You're viewing your saved library from this device. It will refresh when you're back online.
        </Alert>
      )}
      {loading && items.length === 0 && <CodeGridSkeleton count={6} />}
      {error && <ErrorState message="Could not load your codes." onRetry={reload} />}

      {!loading && !error && filtered.length === 0 && (
        <EmptyState
          icon={<FolderIcon sx={{ fontSize: 40 }} />}
          title={search ? "No matching codes" : "No codes yet"}
          description={
            search
              ? "Try a different search term."
              : "Create your first QR code or barcode to see it here."
          }
          actionLabel={search ? undefined : "Create QR Code"}
          onAction={search ? undefined : () => navigate(ROUTES.CREATE_QR)}
        />
      )}

      {filtered.length > 0 && (
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(3, 1fr)" },
            gap: 3,
          }}
        >
          {filtered.map((code) => (
            <CodeCard
              key={code.id}
              code={code}
              onToggleFavorite={handleFavorite}
              onDelete={setPendingDelete}
            />
          ))}
        </Box>
      )}

      {hasMore && !search && (
        <Box sx={{ textAlign: "center", mt: 3 }}>
          <Button variant="outlined" onClick={loadMore} disabled={loading}>
            Load more
          </Button>
        </Box>
      )}

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete this code?"
        description={`"${pendingDelete?.name}" will be permanently deleted. This can't be undone.`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onClose={() => setPendingDelete(null)}
      />
    </Box>
  );
}
