import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import ViewWeekOutlinedIcon from "@mui/icons-material/ViewWeekOutlined";
import UploadFileIcon from "@mui/icons-material/UploadFileRounded";
import FolderIcon from "@mui/icons-material/FolderOutlined";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { getUserCodeCounts } from "../services/analyticsService";
import { subscribeToRecentCodes } from "../services/codeService";
import StatCard from "../components/StatCard";
import CodeCard from "../components/CodeCard";
import EmptyState from "../components/EmptyState";
import PageLoader from "../components/PageLoader";
import ErrorState from "../components/ErrorState";
import { toggleFavorite, deleteCode } from "../services/codeService";
import ConfirmDialog from "../components/ConfirmDialog";
import { useSnackbar } from "../context/SnackbarContext";
import { ROUTES } from "../constants/routes";
import { logDevError } from "../utils/errorUtils";

export default function Dashboard() {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useSnackbar();

  const [counts, setCounts] = useState(null);
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pendingDelete, setPendingDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!user) return undefined;
    let cancelled = false;
    setLoading(true);
    setError(null);

    getUserCodeCounts(user.uid)
      .then((data) => {
        if (!cancelled) setCounts(data);
      })
      .catch((err) => {
        logDevError("Dashboard.getUserCodeCounts", err);
        if (!cancelled) setError(err);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    const unsubscribe = subscribeToRecentCodes(user.uid, setRecent, 5);
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, [user]);

  const handleToggleFavorite = async (codeId, isFavorite) => {
    try {
      await toggleFavorite(user.uid, codeId, isFavorite);
    } catch (err) {
      showError("Could not update favorite status.");
    }
  };

  const handleDelete = async () => {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await deleteCode(user.uid, pendingDelete.id);
      showSuccess("Code deleted.");
      setPendingDelete(null);
    } catch (err) {
      showError("Could not delete this code.");
    } finally {
      setDeleting(false);
    }
  };

  if (loading) return <PageLoader label="Loading your dashboard…" variant="dashboard" />;
  if (error) return <ErrorState message="Could not load your dashboard." onRetry={() => window.location.reload()} />;

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Welcome back{userProfile?.displayName ? `, ${userProfile.displayName}` : ""}!
      </Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>
        Here's what's happening with your codes.
      </Typography>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "repeat(3, 1fr)" },
          gap: 3,
          mb: 4,
        }}
      >
        <StatCard label="Total saved codes" value={counts?.total ?? 0} icon={<FolderIcon />} />
        <StatCard label="QR codes" value={counts?.qr ?? 0} icon={<QrCode2Icon />} />
        <StatCard label="Barcodes" value={counts?.barcode ?? 0} icon={<ViewWeekOutlinedIcon />} />
      </Box>

      <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ mb: 4 }}>
        <Button variant="contained" startIcon={<QrCode2Icon />} onClick={() => navigate(ROUTES.CREATE_QR)}>
          Create QR Code
        </Button>
        <Button variant="outlined" startIcon={<ViewWeekOutlinedIcon />} onClick={() => navigate(ROUTES.CREATE_BARCODE)}>
          Create Barcode
        </Button>
        <Button variant="outlined" startIcon={<UploadFileIcon />} onClick={() => navigate(`${ROUTES.CREATE_QR}?type=file`)}>
          File to QR
        </Button>
      </Stack>

      <Typography variant="h6" gutterBottom>
        Recent codes
      </Typography>
      {recent.length === 0 ? (
        <EmptyState
          icon={<FolderIcon sx={{ fontSize: 40 }} />}
          title="No codes yet"
          description="Create your first QR code or barcode to see it here."
          actionLabel="Create QR Code"
          onAction={() => navigate(ROUTES.CREATE_QR)}
        />
      ) : (
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", md: "repeat(3, 1fr)" },
            gap: 2,
          }}
        >
          {recent.map((code) => (
            <CodeCard
              key={code.id}
              code={code}
              onToggleFavorite={handleToggleFavorite}
              onDelete={setPendingDelete}
            />
          ))}
        </Box>
      )}

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete this code?"
        description={`"${pendingDelete?.name}" will be permanently deleted. This can't be undone.`}
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={handleDelete}
        onClose={() => setPendingDelete(null)}
      />
    </Box>
  );
}
