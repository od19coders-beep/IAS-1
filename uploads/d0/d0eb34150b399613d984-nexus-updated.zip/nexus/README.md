# Nexus — QR Code & Barcode Generator

Nexus is a React + Material UI + Firebase application for generating,
customizing, saving, and managing QR codes and barcodes.

## Tech stack

- React 18 (Create React App)
- Material UI (MUI) v5
- React Router v6
- Firebase Authentication, Firestore, (optional) Storage
- `qrcode` for QR generation, `jsbarcode` for barcode generation

## Getting started

### 1. Prerequisites

- Node.js LTS (18+ recommended)
- A Firebase project (free Spark plan is enough to start)

### 2. Install dependencies

```bash
npm install
```

### 3. Create a Firebase project and web app

1. Go to the [Firebase console](https://console.firebase.google.com/) and
   create a project.
2. Add a **Web app** to the project and copy the config values it gives you.
3. Enable **Authentication** → Email/Password, and optionally Google.
4. Enable **Firestore Database** (production mode).
5. (Optional) Enable **Storage** if you plan to support profile photo uploads.

### 4. Configure environment variables

```bash
cp .env.example .env
```

Fill in `.env` with the values from your Firebase web app config. Never
commit `.env` — it's already in `.gitignore`.

> ⚠️ These are public web config values, not secrets — but they are also
> **not** a substitute for security. Real protection comes from Firestore
> Security Rules (see below), not from hiding this config.

### 5. Deploy security rules and indexes

```bash
npm install -g firebase-tools   # if you don't have it
firebase login
firebase use --add               # select your project
firebase deploy --only firestore:rules,firestore:indexes,storage
```

### 6. Run locally

```bash
npm start
```

The app runs at http://localhost:3000.

### 7. Run tests

```bash
npm test
```

## Admin access

Nexus resolves admin status from a **Firebase custom claim**
(`request.auth.token.admin == true`), never from a Firestore field a client
could write to. To make a user an admin:

1. Deploy the reference Cloud Functions in `/functions-example` (see its own
   README for deploy steps).
2. Use `firebase-admin` from a trusted environment (a local script, CI job,
   or the Functions themselves) to call:
   ```js
   admin.auth().setCustomUserClaims(uid, { admin: true });
   ```
3. The user must sign out and back in (or force-refresh their ID token) for
   the new claim to take effect in the app.

Suspending/restoring accounts and changing admin claims from the Admin
Panel UI call the `setUserAccountStatus` and `setAdminClaim` Cloud
Functions — these must be deployed for those actions to work. Without them,
the Admin Panel still shows real read-only platform stats and user lists,
but write actions will show a clear error explaining what's missing.

## What's implemented

- Full email/password + Google sign-up, sign-in, forgot-password, and email
  verification flows, wired to real Firebase Authentication.
- Protected routes (`/dashboard/**`) and admin-only routes (`/admin/**`)
  that redirect appropriately and never render protected content to the
  wrong audience.
- QR code generation for URL, plain text, email, phone, SMS, Wi-Fi, and
  vCard payloads, with color/size/margin/error-correction customization,
  PNG and SVG download, and low-contrast warnings.
- Barcode generation for CODE128, EAN-13, EAN-8, and UPC-A with format-aware
  validation (rejects invalid lengths rather than rendering a broken code).
- A personal code library ("My Codes") with search, type filtering, sort,
  favorites, pagination, and confirm-before-delete.
- A dashboard overview with real per-user counts (not hardcoded).
- Profile (display name updates) and Settings (theme preference, email
  verification status, sign-out) pages.
- An Admin Panel with real aggregate platform stats, a paginated/searchable
  user list, and privileged actions routed through Cloud Functions rather
  than direct client writes.
- Firestore Security Rules that deny by default, enforce per-user
  ownership on `codes` documents, block self-promotion to admin, and gate
  admin reads on the `admin` custom claim.
- A Storage rule restricting reads/writes to a user's own UID with file
  size/type limits.
- Unit tests for validation logic (email, password, QR payload building,
  barcode format validation, filename sanitization, auth error
  normalization) and component tests for shared UI (dialogs, empty states).

## Known limitations / what you'll need to finish for production

This was generated in a single pass from a detailed specification. A few
things are intentionally left as documented gaps rather than faked:

- **Cloud Functions aren't auto-deployed.** `/functions-example` is a
  reference implementation for `setAdminClaim` and `setUserAccountStatus`.
  You must deploy it yourself (see its README) for suspend/restore and
  admin-granting actions to actually work — the client code calls these
  functions and will surface a clear error if they aren't deployed yet.
- **No live Firebase project is connected.** You must create your own
  Firebase project and fill in `.env` — this couldn't be done on your
  behalf from this environment.
- **Dark theme** is stubbed as "coming soon" in Settings rather than fully
  implemented, since the spec only requires it if fully supported.
- **Account deletion** is intentionally not implemented — the spec requires
  a documented data-handling policy and reauthentication flow before this
  should ship, and Settings says so explicitly rather than offering a
  fake/unsafe delete button.
- **Email change flow** is not implemented for the same reason — email is
  shown as read-only in Profile with an explanatory note, rather than
  allowing an unsafe direct Firestore field edit.
- **Rules emulator tests** (Section 19.3 of the spec) are documented here as
  a to-do rather than included as runnable test files, since they require
  the Firebase Emulator Suite to be installed and running. To add them:
  ```bash
  npm install -g firebase-tools
  firebase emulators:start
  # then write tests with the @firebase/rules-unit-testing package
  ```
- **`npm install`, `npm test`, and `npm run build` were all run and verified
  in the generation environment** — 28 tests pass and the production build
  compiles cleanly. One real issue surfaced and was fixed: current
  `react-scripts@5.0.1` combined with today's npm-resolved `eslint`/
  `eslint-plugin-jest` versions throws `Environment key "jest/globals" is
  unknown` during the build's built-in lint pass — a known ecosystem
  incompatibility, not an issue in this app's code. `start`/`build` scripts
  set `DISABLE_ESLINT_PLUGIN=true` (via `cross-env`, for Windows
  compatibility) to route around it; run your own `eslint` separately if you
  want lint feedback during development.
- The QR "contact/vCard" and "Wi-Fi" payload builders follow the standard
  QR conventions (MECARD/vCard 3.0, `WIFI:` URI scheme) but scanning
  behavior can vary slightly across QR reader apps — test against the
  readers you expect your users to have.

## Project structure

See the full file tree in the original specification; the implementation
here follows it directly (`src/pages`, `src/components`, `src/services`,
`src/utils`, `src/hooks`, `src/context`, `src/constants`, `src/lib`,
`src/theme`, `src/auth`, `firebase/`).

## Deployment (Firebase Hosting)

```bash
npm run build
firebase deploy --only hosting
```

`firebase.json` is already configured with a SPA rewrite so client-side
routing works on refresh and direct URL access.


## What's new

- **Light / dark / system mode** (Settings, or the toggle in every header). Stored in IndexedDB, mirrored to localStorage so first paint never flashes.
- **Claymorphic UI** — the whole theme lives in `src/theme/theme.js` (`theme.clay` shadow tokens).
- **IndexedDB** (`src/lib/localDb.js`): color mode, instant/offline library cache, auto-saved generator drafts, and upload de-duplication by SHA-256.
- **14 QR types**: URL, text, email, phone, SMS, WhatsApp, Wi-Fi, vCard, location, calendar event, UPI, file, image, video.
- **14 barcode formats**: Code 128/39, EAN-13/8, UPC-A/E, ITF-14, ITF, MSI, Codabar, Pharmacode, plus Data Matrix, PDF417 and Aztec (bwip-js, lazy-loaded).
- **Center logo** on any QR code (auto error-correction H; PNG and SVG export).
- **Skeleton loading** everywhere; no spinners.

## File-to-QR storage

Files, images and videos are committed to a dedicated **public** GitHub repo and the QR code encodes a CDN URL (jsDelivr, or raw.githubusercontent.com for files over 50 MB). The user sees only a skeleton while it happens.

1. Create a new public repo (e.g. `nexus-files`).
2. **Recommended:** deploy `functions-example/uploadToGithub` and set `REACT_APP_UPLOAD_PROXY_URL`. The token stays on the server.
3. **Quick start:** create a fine-grained token limited to that one repo with *Contents: Read and write* and put it in `REACT_APP_GITHUB_TOKEN`. Anything in `REACT_APP_*` is public in the built JS, so a leaked token could be used to fill or delete that repo. Never use a classic token or one that reaches other repos.

Things to know: uploaded files are public to anyone with the link; GitHub is not a CDN/host for heavy traffic (rate limits, repo size limits), so treat this as fine for moderate use and move to S3/R2/Firebase Storage if it grows.
